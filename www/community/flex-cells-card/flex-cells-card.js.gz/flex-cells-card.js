globalThis.FCC_LOCALES = {"de":{"editor":{"appearance":"Aussehen & Stil (Zelle)","appearance_row":"Aussehen & Stil (Zeile)","card_title":"Flex Cells card konfigurieren","columns_count":"Spalten","text_size_global":"Textgröße (Standard)","card_padding":"Kartenabstand","cell_padding_top":"Zellenabstand - oben","cell_padding_right":"Zellenabstand - rechts","cell_padding_bottom":"Zellenabstand - unten","cell_padding_left":"Zellenabstand - links","widths_label":"Spaltenbreite (px/%/rem/auto), z. B. \"80px, auto, 25%, 12rem\"","hide_cols_label":"Spalten, die unterhalb des Breakpoints ausgeblendet werden (z. B. 1,4)","sort_cols_label":"Spalten zum Sortieren der Zeilen (z. B. 5,2,3)","sort_desc_label":"Sortierung umkehren","sort_hide_separators_label":"Separatoren beim Sortieren ausblenden","sort_hint_grouped":"Wenn du einen Separator einfügst, teilt er deine Zeilen in Gruppen. Jede Gruppe wird separat sortiert.","breakpoint":"Breakpoint (px)","overflow_x":"Horizontaler Scroll (overflow-x)","header_from_first":"Erste Zeile als Kopfzeile verwenden","zebra":"Zebrastreifen","zebra_skip_separators":"Separatoren auslassen","row":"Zeile","header_suffix":" - Kopfzeile","tab_first":"Spalte 1","merge_all_columns":"Alle Spalten zusammenfuehren","copy":"Konfiguration kopieren","paste":"Konfiguration einfügen","clipboard_empty":"Zwischenablage leer","copy_paste_section":"Kopieren & Einfügen (Zeile & Zelle)","copy_row_group":"Zeilenaktionen","copy_cell_group":"Zellenaktionen","copy_row":"Zeile kopieren","paste_row":"Zeile einfügen","copy_row_appearance":"Zeilenstil kopieren","paste_row_appearance":"Zeilenstil einfügen","copy_row_rules":"Zeilenregeln kopieren","paste_row_rules":"Zeilenregeln einfügen","copy_cell":"Zelle kopieren","paste_cell":"Zelle einfügen","copy_cell_appearance":"Zellenstil kopieren","paste_cell_appearance":"Zellenstil einfügen","copy_cell_rules":"Zellenregeln kopieren","paste_cell_rules":"Zellenregeln einfügen","copy_cell_actions":"Tap/Hold-Aktionen kopieren","paste_cell_actions":"Tap/Hold-Aktionen einfügen","copy_multi_cell_group":"Mehrzellen-Aktionen","paste_cell_column":"Zelle in gesamte Spalte einfügen","paste_cell_row":"Zelle in gesamte Zeile einfügen","paste_cell_appearance_column":"Zellenstil in gesamte Spalte einfügen","paste_cell_appearance_row":"Zellenstil in gesamte Zeile einfügen","paste_cell_rules_column":"Zellenregeln in gesamte Spalte einfügen","paste_cell_rules_row":"Zellenregeln in gesamte Zeile einfügen","paste_cell_actions_column":"Tap/Hold-Aktionen in gesamte Spalte einfügen","paste_cell_actions_row":"Tap/Hold-Aktionen in gesamte Zeile einfügen","clipboard_row_label":"Zwischenablage (Zeile)","clipboard_cell_label":"Zwischenablage (Zelle)","clipboard_scope_full":"Vollständig","clipboard_scope_appearance":"Aussehen","clipboard_scope_rules":"Dynamische Regeln","clipboard_scope_actions":"Tap/Hold-Aktionen","align":"Ausrichtung","unit_from_entity":"Einheit der Entität verwenden","precision":"Genauigkeit","show_control":"Steuerelement anzeigen","show_value_on_right":"Wert rechts anzeigen","attr_edit_title":"Attribut bearbeiten (Service)","attr_edit_enable":"Bearbeitung dieses Attributs aktivieren","attr_edit_hint":"Liest den Attributwert und ruft den Service mit {entity_id, [Feld]: Wert} auf. Steuerungstyp explizit wählen.","attr_edit_service":"Service (domain.service)","attr_edit_service_field":"Service-Feld","attr_edit_control_type":"Steuerungstyp","attr_edit_control_slider":"Slider","attr_edit_control_color":"Farbschieber (Hue)","attr_edit_control_color_sat":"Farbschieber (Sättigung)","attr_edit_control_switch":"Schalter","attr_edit_min":"Min (Slider/Zahl)","attr_edit_max":"Max (Slider/Zahl)","attr_edit_step":"Schritt","attr_edit_checked":"Wert für \"an\"","attr_edit_unchecked":"Wert für \"aus\"","attr_edit_color_hint":"Regler setzt Hue und ruft den Service mit hs_color=[hue,sat] auf. Leere Pfade nutzen hs_color aus dem Entity.","attr_edit_color_sat_hint":"Sättigungsregler; übernimmt Hue aus dem Entity und sendet hs_color=[hue,sat]. Leere Pfade nutzen hs_color aus dem Entity.","attr_edit_color_hue_path":"Hue-Attributpfad (optional)","attr_edit_color_sat_path":"Sättigungs-Attributpfad (optional)","attr_edit_color_sat_fallback":"Fallback-Sättigung (0-100)","press":"Drücken","entity_display_label":"Entitaetsdarstellung","entity_display_option_value":"Entitaets-/Metadatenwert","entity_display_option_icon":"Entitaetssymbol","entity_display_option_icon_value":"Symbol und Wert","background_color":"Hintergrundfarbe","content_color":"Inhaltsfarbe","text_color":"Textfarbe","text_size":"Textgröße","text_transform":"Textumwandlung","letter_spacing":"Buchstabenabstand","icon_color":"Iconfarbe","icon_size":"Icongröße","add_row":"Zeile hinzufügen","add_separator":"Separator hinzufuegen","custom_template":"Eigenes Template","custom_template_hint":"Nutze beliebiges HTML und den Tag <fcc row=\"3\" col=\"2\" /> um eine Tabellenzelle einzufügen, oder <fcc row=\"3\" /> um die vollständige Zeile einzufügen. Wenn Sie globales CSS verwenden möchten, gehen Sie wie folgt vor: <style>...</style><fcc />.","delete_row":"Zeile löschen","separator_title":"Separator","separator_appearance":"Separator Darstellung","separator_color":"Separatorfarbe","separator_background":"Separator-Hintergrundfarbe","separator_color_picker":"Farbauswahl","separator_style":"Linienstil","separator_style_solid":"Durchgezogen","separator_style_dashed":"Gestrichelt","separator_style_dotted":"Gepunktet","separator_thickness":"Linienstaerke (px)","separator_length":"Laenge / Breite","separator_align":"Ausrichtung","separator_align_full":"Volle Breite","separator_align_center":"Zentriert","separator_align_left":"Links","separator_align_right":"Rechts","separator_opacity":"Deckkraft","separator_margin_top":"Oberer Abstand (px)","separator_margin_bottom":"Unterer Abstand (px)","separator_zero_hint":"Wenn du die Dicke auf Null setzt, bleibt der Separator unsichtbar, trennt aber weiterhin Zeilengruppen, die beim Sortieren berücksichtigt werden.","column":"Spalte","drag_to_reorder":"Zum Umordnen ziehen","move_left":"nach links schieben","move_right":"nach rechts schieben","up":"Nach oben","down":"Nach unten","toggle":"Ein-/ausklappen","delete_column":"Spalte löschen","cell_type":"Zellentyp","entity_label":"Entität","string_label":"Text","icon_label":"Icon","tap_action":"Tippen-Aktion","hold_action":"Aktion bei Halten","double_tap_action":"Doppeltippen-Aktion","advanced":"Tippen & Halten Aktionen (Zelle)","custom_css":"Benutzerdefiniertes CSS","actions_hint":"Wenn eine Aktion gesetzt ist, wird das Standard-\"more-info\" für die Entität deaktiviert.","scale_title":"Skalieren","scale_in_min":"Eingabe min","scale_in_max":"Eingabe max","scale_out_min":"Ausgabe min","scale_out_max":"Ausgabe max","scale_hint":"Numerischen Wert von einem Bereich in einen anderen abbilden (z. B. 0-255 → 0-100).","dynamic_title":"Dynamische Regeln (Zelle): Farb- & Inhalts-Übersteuerung","dynamic_row_title":"Dynamische Regeln (Zeile): Farben und Zeilenausblenden","dynamic_hint":"Regeln von oben nach unten prüfen, die letzte Übereinstimmung gewinnt.","datetime_format":"Datums-/Zeitformat & Textüberschreibung","available_tokens":"Verfügbare Tokens: RAW, YYYY, YY, MM, M, DD, D, HH, H, hh, h, mm, m, ss, s, MMMM, REL (verstrichene Zeit), REL_SHORT (kompakte Zeit), [Literale in Klammern]","value":"Wert"},"placeholder":{"entity":"Entität auswählen","string":"Anzuzeigender Text","icon":"mdi:icon-name","datetime_format":"z. B. H:mm:ss, YYYY-MM-DD H:mm, REL [vor], REL_SHORT [vor] oder [eigener Text]","attribute_path":"Metadatenpfad (z. B. a.b[0].c)"},"dynamic":{"operator":"Operator","match":"Bedingungslogik","match_all":"Alle Bedingungen (UND)","match_any":"Beliebige Bedingung (ODER)","add_rule":"Regel hinzufügen","add_condition":"Bedingung hinzufügen","delete_rule":"Löschen","delete_condition":"Bedingung löschen","op_between":"zwischen","op_contains":"enthält","op_not_contains":"enthält nicht","min":"Min","max":"Max","bg":"Hintergrundfarbe","fg":"Inhaltsfarbe","overwrite_label":"Inhalt überschreiben","overwrite_hide":"Ausblenden","overwrite_text":"Mit Text überschreiben","overwrite_icon":"Mit Icon überschreiben","overwrite_entity_metadata":"Mit Entitaet/Metadaten ueberschreiben","visibility_label":"Sichtbarkeit","visibility_visible":"Sichtbar","visibility_hidden":"Versteckt","text":"Text","icon_optional_text":"Optionaler Text","icon_color":"Icon-Farbe"},"align":{"left":"links","center":"zentriert","right":"rechts"},"precision":{"two":"zwei Dezimalstellen","one":"eine Dezimalstelle","int":"Ganzzahl"},"style":{"bold":"fett","italic":"kursiv","underline":"unterstrichen","strike":"durchgestrichen"},"card":{"no_rows":"Keine Zeilen zum Anzeigen."}},"en":{"editor":{"appearance":"Appearance & Style (cell)","appearance_row":"Appearance & Style (row)","card_title":"Flex Cells card configuration","columns_count":"Columns","text_size_global":"Text size (default)","card_padding":"Card padding","cell_padding_top":"Cell padding - top","cell_padding_right":"Cell padding - right","cell_padding_bottom":"Cell padding - bottom","cell_padding_left":"Cell padding - left","widths_label":"Column widths (px/%/rem/auto), e.g. \"80px, auto, 25%, 12rem\"","hide_cols_label":"Columns to hide below breakpoint (e.g. 1,4)","sort_cols_label":"Sort rows by columns (e.g. \"5,2,3\")","sort_desc_label":"Reverse sort","sort_hide_separators_label":"Hide separators when sorting is enabled","sort_hint_grouped":"If you add a separator it splits your rows into groups. Each group is sorted independently.","breakpoint":"Breakpoint (px)","overflow_x":"Horizontal scroll (overflow-x)","header_from_first":"Use first row as header","zebra":"Zebra stripes","zebra_skip_separators":"Skip separators in zebra pattern","row":"Row","header_suffix":" - header","tab_first":"Column 1","merge_all_columns":"Merge all columns","copy":"Copy configuration","paste":"Paste configuration","clipboard_empty":"Clipboard empty","copy_paste_section":"Copy & Paste configuration (row & cell)","copy_row_group":"Row operations","copy_cell_group":"Cell operations","copy_row":"Copy row","paste_row":"Paste row","copy_row_appearance":"Copy row appearance","paste_row_appearance":"Paste row appearance","copy_row_rules":"Copy row dynamic rules","paste_row_rules":"Paste row dynamic rules","copy_cell":"Copy cell","paste_cell":"Paste cell","copy_cell_appearance":"Copy cell appearance","paste_cell_appearance":"Paste cell appearance","copy_cell_rules":"Copy cell dynamic rules","paste_cell_rules":"Paste cell dynamic rules","copy_cell_actions":"Copy tap/hold actions","paste_cell_actions":"Paste tap/hold actions","copy_multi_cell_group":"Multi-cell operations","paste_cell_column":"Paste cell into entire column","paste_cell_row":"Paste cell into entire row","paste_cell_appearance_column":"Paste cell appearance into entire column","paste_cell_appearance_row":"Paste cell appearance into entire row","paste_cell_rules_column":"Paste cell dynamic rules into entire column","paste_cell_rules_row":"Paste cell dynamic rules into entire row","paste_cell_actions_column":"Paste tap/hold actions into entire column","paste_cell_actions_row":"Paste tap/hold actions into entire row","clipboard_row_label":"Row clipboard","clipboard_cell_label":"Cell clipboard","clipboard_scope_full":"Full","clipboard_scope_appearance":"Appearance","clipboard_scope_rules":"Dynamic rules","clipboard_scope_actions":"Tap/Hold actions","align":"Alignment","unit_from_entity":"Use unit from entity","precision":"Precision","show_control":"Show control","show_value_on_right":"Show value on right","attr_edit_title":"Attribute editing (service)","attr_edit_enable":"Enable editing for this attribute","attr_edit_hint":"Reads the attribute value and calls the service with {entity_id, [field]: value}. Choose the control type explicitly.","attr_edit_service":"Service (domain.service)","attr_edit_service_field":"Service field","attr_edit_control_type":"Control type","attr_edit_control_slider":"Slider","attr_edit_control_color":"Color slider (hue)","attr_edit_control_color_sat":"Color slider (saturation)","attr_edit_control_switch":"Switch","attr_edit_min":"Min (slider/number)","attr_edit_max":"Max (slider/number)","attr_edit_step":"Step","attr_edit_checked":"Checked value","attr_edit_unchecked":"Unchecked value","attr_edit_color_hint":"Hue slider; calls the service with hs_color=[hue,sat]. Leave paths empty to use the entity's hs_color.","attr_edit_color_sat_hint":"Saturation slider; keeps hue from the entity and sends hs_color=[hue,sat]. Leave paths empty to use hs_color.","attr_edit_color_hue_path":"Hue attribute path (optional)","attr_edit_color_sat_path":"Saturation attribute path (optional)","attr_edit_color_sat_fallback":"Saturation fallback (0-100)","press":"Press","entity_display_label":"Entity display","entity_display_option_value":"Entity/metadata value","entity_display_option_icon":"Entity icon","entity_display_option_icon_value":"Icon and value","background_color":"Background color","content_color":"Content color","text_color":"Text color","text_size":"Text size","text_transform":"Text transform","letter_spacing":"Letter spacing","icon_color":"Icon color","icon_size":"Icon size","add_row":"Add row","add_separator":"Add separator","custom_template":"Custom template","custom_template_hint":"Use any HTML and the tag <fcc row=\"3\" col=\"2\" /> to insert a cell from a table, or <fcc row=\"3\" /> to insert an entire row. If you want to use global CSS, do this: <style>...</style><fcc />.","delete_row":"Delete row","separator_title":"Separator","separator_appearance":"Separator appearance","separator_color":"Separator color","separator_background":"Background color","separator_color_picker":"Color picker","separator_style":"Line style","separator_style_solid":"Solid","separator_style_dashed":"Dashed","separator_style_dotted":"Dotted","separator_thickness":"Thickness (px)","separator_length":"Length / width","separator_align":"Alignment","separator_align_full":"Full width","separator_align_center":"Center","separator_align_left":"Left","separator_align_right":"Right","separator_opacity":"Opacity","separator_margin_top":"Margin top (px)","separator_margin_bottom":"Margin bottom (px)","separator_zero_hint":"If you set the separator thickness to zero it will be invisible but it still divides rows into groups that are used when sorting.","column":"Column","drag_to_reorder":"Drag to reorder","move_left":"Move left","move_right":"Move right","up":"Move up","down":"Move down","toggle":"Collapse/Expand","delete_column":"Delete column","cell_type":"Cell type","entity_label":"Entity","string_label":"Text","icon_label":"Icon","tap_action":"Tap action","hold_action":"Hold action","double_tap_action":"Double-tap action","advanced":"Tap & Hold Actions (cell)","custom_css":"Custom CSS","actions_hint":"If any action is set, the default 'more-info' for an entity will be disabled.","scale_title":"Rescale","scale_in_min":"Input min","scale_in_max":"Input max","scale_out_min":"Output min","scale_out_max":"Output max","scale_hint":"Map a numeric value from one range to another (e.g., 0-255 → 0-100).","dynamic_title":"Dynamic Rules (cell): Color & Content Overrides","dynamic_row_title":"Dynamic Rules (row): Color & Row Hiding","dynamic_hint":"Evaluate rules from top to bottom, the last match wins.","datetime_format":"Date/Time format & Text override","available_tokens":"Available tokens: RAW, YYYY, YY, MM, M, DD, D, HH, H, hh, h, mm, m, ss, s, MMMM, REL (elapsed time), REL_SHORT (short elapsed time), [literals in brackets]","value":"Value"},"placeholder":{"entity":"Select entity","string":"Text to display","icon":"mdi:icon-name","datetime_format":"e.g. H:mm:ss, YYYY-MM-DD H:mm, REL [ago], REL_SHORT [ago] or [Custom text]","attribute_path":"Metadata path (e.g. a.b[0].c)"},"dynamic":{"operator":"Operator","match":"Condition logic","match_all":"All conditions (AND)","match_any":"Any condition (OR)","add_rule":"Add rule","add_condition":"Add condition","delete_rule":"Delete","delete_condition":"Delete condition","op_between":"between","op_contains":"contains","op_not_contains":"does not contain","min":"Min","max":"Max","bg":"Background color","fg":"Content color","overwrite_label":"Overwrite content","overwrite_hide":"Hide","overwrite_text":"Overwrite with text","overwrite_icon":"Overwrite with icon","overwrite_entity_metadata":"Overwrite with entity/metadata","visibility_label":"Visibility","visibility_visible":"Visible","visibility_hidden":"Hidden","text":"Text","icon_optional_text":"Optional text","icon_color":"Icon color"},"align":{"left":"left","center":"center","right":"right"},"precision":{"two":"two decimals","one":"one decimal","int":"integer"},"style":{"bold":"bold","italic":"italic","underline":"underline","strike":"strikethrough"},"card":{"no_rows":"No rows to display."}},"it":{"editor":{"appearance":"Aspetto e stile (cella)","appearance_row":"Aspetto e stile (riga)","card_title":"Configurazione scheda Flex Cells","columns_count":"Colonne","text_size_global":"Dimensione testo (predefinita)","card_padding":"Padding scheda","cell_padding_top":"Padding cella - alto","cell_padding_right":"Padding cella - destra","cell_padding_bottom":"Padding cella - basso","cell_padding_left":"Padding cella - sinistra","widths_label":"Larghezze colonne (px/%/rem/auto), es. \"80px, auto, 25%, 12rem\"","hide_cols_label":"Colonne da nascondere sotto il breakpoint (es. 1,4)","sort_cols_label":"Ordina righe per colonne (es. \"5,2,3\")","sort_desc_label":"Ordine inverso","sort_hide_separators_label":"Nascondi separatori quando l'ordinamento è attivo","sort_hint_grouped":"Se aggiungi un separatore, le righe vengono divise in gruppi. Ogni gruppo viene ordinato in modo indipendente.","breakpoint":"Breakpoint (px)","overflow_x":"Scorrimento orizzontale (overflow-x)","header_from_first":"Usa la prima riga come intestazione","zebra":"Righe alternate (zebra)","zebra_skip_separators":"Salta i separatori nel motivo zebra","row":"Riga","header_suffix":" - intestazione","tab_first":"Colonna 1","merge_all_columns":"Unisci tutte le colonne","copy":"Copia configurazione","paste":"Incolla configurazione","clipboard_empty":"Appunti vuoti","copy_paste_section":"Copia e incolla configurazione (riga e cella)","copy_row_group":"Operazioni riga","copy_cell_group":"Operazioni cella","copy_row":"Copia riga","paste_row":"Incolla riga","copy_row_appearance":"Copia aspetto riga","paste_row_appearance":"Incolla aspetto riga","copy_row_rules":"Copia regole dinamiche riga","paste_row_rules":"Incolla regole dinamiche riga","copy_cell":"Copia cella","paste_cell":"Incolla cella","copy_cell_appearance":"Copia aspetto cella","paste_cell_appearance":"Incolla aspetto cella","copy_cell_rules":"Copia regole dinamiche cella","paste_cell_rules":"Incolla regole dinamiche cella","copy_cell_actions":"Copia azioni tocco/pressione","paste_cell_actions":"Incolla azioni tocco/pressione","copy_multi_cell_group":"Operazioni multi-cella","paste_cell_column":"Incolla cella in tutta la colonna","paste_cell_row":"Incolla cella in tutta la riga","paste_cell_appearance_column":"Incolla aspetto cella in tutta la colonna","paste_cell_appearance_row":"Incolla aspetto cella in tutta la riga","paste_cell_rules_column":"Incolla regole dinamiche cella in tutta la colonna","paste_cell_rules_row":"Incolla regole dinamiche cella in tutta la riga","paste_cell_actions_column":"Incolla azioni tocco/pressione in tutta la colonna","paste_cell_actions_row":"Incolla azioni tocco/pressione in tutta la riga","clipboard_row_label":"Appunti riga","clipboard_cell_label":"Appunti cella","clipboard_scope_full":"Completo","clipboard_scope_appearance":"Aspetto","clipboard_scope_rules":"Regole dinamiche","clipboard_scope_actions":"Azioni tocco/pressione","align":"Allineamento","unit_from_entity":"Usa unità dall'entità","precision":"Precisione","show_control":"Mostra controllo","show_value_on_right":"Mostra valore a destra","attr_edit_title":"Modifica attributo (servizio)","attr_edit_enable":"Abilita modifica per questo attributo","attr_edit_hint":"Legge il valore dell'attributo e chiama il servizio con {entity_id, [campo]: valore}. Scegli esplicitamente il tipo di controllo.","attr_edit_service":"Servizio (dominio.servizio)","attr_edit_service_field":"Campo del servizio","attr_edit_control_type":"Tipo di controllo","attr_edit_control_slider":"Slider","attr_edit_control_color":"Slider colore (tonalità)","attr_edit_control_color_sat":"Slider colore (saturazione)","attr_edit_control_switch":"Interruttore","attr_edit_min":"Min (slider/numero)","attr_edit_max":"Max (slider/numero)","attr_edit_step":"Passo","attr_edit_checked":"Valore selezionato","attr_edit_unchecked":"Valore non selezionato","attr_edit_color_hint":"Slider tonalità; chiama il servizio con hs_color=[tonalità,saturazione]. Lascia vuoti i percorsi per usare hs_color dell'entità.","attr_edit_color_sat_hint":"Slider saturazione; mantiene la tonalità dell'entità e invia hs_color=[tonalità,saturazione]. Lascia vuoti i percorsi per usare hs_color.","attr_edit_color_hue_path":"Percorso attributo tonalità (opzionale)","attr_edit_color_sat_path":"Percorso attributo saturazione (opzionale)","attr_edit_color_sat_fallback":"Valore di fallback saturazione (0-100)","press":"Premi","entity_display_label":"Visualizzazione entità","entity_display_option_value":"Valore entità/metadati","entity_display_option_icon":"Icona entità","entity_display_option_icon_value":"Icona e valore","background_color":"Colore sfondo","content_color":"Colore contenuto","text_color":"Colore testo","text_size":"Dimensione testo","text_transform":"Trasformazione testo","letter_spacing":"Spaziatura lettere","icon_color":"Colore icona","icon_size":"Dimensione icona","add_row":"Aggiungi riga","add_separator":"Aggiungi separatore","custom_template":"Template personalizzato","custom_template_hint":"Usa qualsiasi HTML e il tag <fcc row=\"3\" col=\"2\" /> per inserire una cella da una tabella, oppure <fcc row=\"3\" /> per inserire un'intera riga. Per usare CSS globale: <style>...</style><fcc />.","delete_row":"Elimina riga","separator_title":"Separatore","separator_appearance":"Aspetto separatore","separator_color":"Colore separatore","separator_background":"Colore sfondo","separator_color_picker":"Selettore colore","separator_style":"Stile linea","separator_style_solid":"Solida","separator_style_dashed":"Tratteggiata","separator_style_dotted":"Punteggiata","separator_thickness":"Spessore (px)","separator_length":"Lunghezza / larghezza","separator_align":"Allineamento","separator_align_full":"Larghezza completa","separator_align_center":"Centrato","separator_align_left":"Sinistra","separator_align_right":"Destra","separator_opacity":"Opacità","separator_margin_top":"Margine superiore (px)","separator_margin_bottom":"Margine inferiore (px)","separator_zero_hint":"Se imposti lo spessore del separatore a zero, sarà invisibile ma continuerà a dividere le righe in gruppi usati per l'ordinamento.","column":"Colonna","drag_to_reorder":"Trascina per riordinare","move_left":"Sposta a sinistra","move_right":"Sposta a destra","up":"Sposta su","down":"Sposta giù","toggle":"Comprimi/Espandi","delete_column":"Elimina colonna","cell_type":"Tipo di cella","entity_label":"Entità","string_label":"Testo","icon_label":"Icona","tap_action":"Azione al tocco","hold_action":"Azione alla pressione","double_tap_action":"Azione doppio tocco","advanced":"Azioni tocco e pressione (cella)","custom_css":"CSS personalizzato","actions_hint":"Se è impostata un'azione, l'azione predefinita 'more-info' dell'entità verrà disabilitata.","scale_title":"Ridimensionamento","scale_in_min":"Ingresso minimo","scale_in_max":"Ingresso massimo","scale_out_min":"Uscita minima","scale_out_max":"Uscita massima","scale_hint":"Mappa un valore numerico da un intervallo a un altro (es. 0-255 → 0-100).","dynamic_title":"Regole dinamiche (cella): colore e contenuto","dynamic_row_title":"Regole dinamiche (riga): colore e nascondi riga","dynamic_hint":"Le regole vengono valutate dall'alto verso il basso, l'ultima corrispondenza ha la priorità.","datetime_format":"Formato data/ora e sovrascrittura testo","available_tokens":"Token disponibili: RAW, YYYY, YY, MM, M, DD, D, HH, H, hh, h, mm, m, ss, s, MMMM, REL (tempo trascorso), REL_SHORT (tempo trascorso breve), [testo tra parentesi]","value":"Valore"},"placeholder":{"entity":"Seleziona entità","string":"Testo da visualizzare","icon":"mdi:nome-icona","datetime_format":"es. H:mm:ss, YYYY-MM-DD H:mm, REL [fa], REL_SHORT [fa] o [Testo personalizzato]","attribute_path":"Percorso metadati (es. a.b[0].c)"},"dynamic":{"operator":"Operatore","match":"Logica condizione","match_all":"Tutte le condizioni (AND)","match_any":"Almeno una condizione (OR)","add_rule":"Aggiungi regola","add_condition":"Aggiungi condizione","delete_rule":"Elimina","delete_condition":"Elimina condizione","op_between":"compreso tra","op_contains":"contiene","op_not_contains":"non contiene","min":"Min","max":"Max","bg":"Colore sfondo","fg":"Colore contenuto","overwrite_label":"Sovrascrivi contenuto","overwrite_hide":"Nascondi","overwrite_text":"Sovrascrivi con testo","overwrite_icon":"Sovrascrivi con icona","overwrite_entity_metadata":"Sovrascrivi con entità/metadati","visibility_label":"Visibilità","visibility_visible":"Visibile","visibility_hidden":"Nascosto","text":"Testo","icon_optional_text":"Testo opzionale","icon_color":"Colore icona"},"align":{"left":"sinistra","center":"centro","right":"destra"},"precision":{"two":"due decimali","one":"un decimale","int":"intero"},"style":{"bold":"grassetto","italic":"corsivo","underline":"sottolineato","strike":"barrato"},"card":{"no_rows":"Nessuna riga da visualizzare."}},"pl":{"editor":{"appearance":"Wygląd i styl (komórka)","appearance_row":"Wygląd i styl (wiersz)","card_title":"Konfiguracja karty Flex Cells","columns_count":"Liczba kolumn","text_size_global":"Rozmiar tekstu (domyślny)","card_padding":"Padding karty","cell_padding_top":"Padding komórki - góra","cell_padding_right":"Padding komórki - prawa","cell_padding_bottom":"Padding komórki - dół","cell_padding_left":"Padding komórki - lewa","widths_label":"Szerokości kolumn (px/%/rem/auto), np. \"80px, auto, 25%, 12rem\"","hide_cols_label":"Kolumny do ukrycia poniżej breakpointu (np. 1,4)","sort_cols_label":"Kolumny do sortowania wierszy (np. 5,2,3)","sort_desc_label":"Odwróć sortowanie","sort_hide_separators_label":"Ukryj separatory gdy sortowanie jest włączone","sort_hint_grouped":"Jeśli użyjesz separatora, podzieli on twoje wiersze na grupy. Każda grupa jest sortowana indywidualnie.","breakpoint":"Breakpoint (px)","overflow_x":"Poziomy scroll (overflow-x)","header_from_first":"Użyj pierwszego wiersza jako nagłówka","zebra":"Zebra stripes","zebra_skip_separators":"Nie uwzględniaj separatora","row":"Wiersz","header_suffix":" - nagłówek","tab_first":"Kolumna 1","merge_all_columns":"Scal wszystkie kolumny","copy":"Kopiuj konfigurację","paste":"Wklej konfigurację","clipboard_empty":"Schowek pusty","copy_paste_section":"Kopiuj/Wklej konfigurację (wiersz i komórka)","copy_row_group":"Operacje na wierszu","copy_cell_group":"Operacje na komórce","copy_row":"Kopiuj wiersz","paste_row":"Wklej wiersz","copy_row_appearance":"Kopiuj wygląd wiersza","paste_row_appearance":"Wklej wygląd wiersza","copy_row_rules":"Kopiuj reguły wiersza","paste_row_rules":"Wklej reguły wiersza","copy_cell":"Kopiuj komórkę","paste_cell":"Wklej komórkę","copy_cell_appearance":"Kopiuj wygląd komórki","paste_cell_appearance":"Wklej wygląd komórki","copy_cell_rules":"Kopiuj reguły komórki","paste_cell_rules":"Wklej reguły komórki","copy_cell_actions":"Kopiuj akcje tap/hold","paste_cell_actions":"Wklej akcje tap/hold","copy_multi_cell_group":"Operacje na wielu komórkach","paste_cell_column":"Wklej komórkę dla wszystkich komórek w tej kolumnie","paste_cell_row":"Wklej komórkę dla wszystkich komórek w tym wierszu","paste_cell_appearance_column":"Wklej wygląd komórki dla wszystkich komórek w tej kolumnie","paste_cell_appearance_row":"Wklej wygląd komórki dla wszystkich komórek w tym wierszu","paste_cell_rules_column":"Wklej reguły komórki dla wszystkich komórek w tej kolumnie","paste_cell_rules_row":"Wklej reguły komórki dla wszystkich komórek w tym wierszu","paste_cell_actions_column":"Wklej akcje tap/hold komórki dla wszystkich komórek w tej kolumnie","paste_cell_actions_row":"Wklej akcje tap/hold komórki dla wszystkich komórek w tym wierszu","clipboard_row_label":"Schowek (wiersz)","clipboard_cell_label":"Schowek (komórka)","clipboard_scope_full":"Cała","clipboard_scope_appearance":"Wygląd","clipboard_scope_rules":"Reguły dynamiczne","clipboard_scope_actions":"Akcje tap/hold","align":"Wyrównanie","unit_from_entity":"Jednostka z encji","precision":"Precyzja","show_control":"Pokaż kontrolkę","show_value_on_right":"Pokaż wartość po prawej","attr_edit_title":"Edycja atrybutu (usługa)","attr_edit_enable":"Włącz edycję tego atrybutu","attr_edit_hint":"Odczytuje wartość atrybutu i wywołuje usługę z {entity_id, [pole]: wartość}. Typ kontrolki ustaw ręcznie.","attr_edit_service":"Usługa (domena.usługa)","attr_edit_service_field":"Pole usługi","attr_edit_control_type":"Typ kontrolki","attr_edit_control_slider":"Suwak","attr_edit_control_color":"Suwak koloru (hue)","attr_edit_control_color_sat":"Suwak nasycenia","attr_edit_control_switch":"Przełącznik","attr_edit_min":"Min (suwak/liczba)","attr_edit_max":"Max (suwak/liczba)","attr_edit_step":"Krok","attr_edit_checked":"Wartość dla zaznaczonego","attr_edit_unchecked":"Wartość dla odznaczonego","attr_edit_color_hint":"Suwak ustawia hue; wywołuje usługę z hs_color=[hue,sat]. Puste ścieżki użyją domyślnego hs_color z encji.","attr_edit_color_sat_hint":"Suwak nasycenia; używa hue z encji i wysyła hs_color=[hue,sat]. Puste ścieżki użyją hs_color z encji.","attr_edit_color_hue_path":"Ścieżka atrybutu hue (opcjonalnie)","attr_edit_color_sat_path":"Ścieżka atrybutu nasycenia (opcjonalnie)","attr_edit_color_sat_fallback":"Domyślne nasycenie (0-100)","press":"Wciśnij","entity_display_label":"Wyświetlanie encji","entity_display_option_value":"Wartość encji/metadanych","entity_display_option_icon":"Ikona encji","entity_display_option_icon_value":"Ikona i wartość","background_color":"Kolor tła","content_color":"Kolor zawartości","text_color":"Tekst kolor","text_size":"Tekst rozmiar","text_transform":"Tekst transformacja","letter_spacing":"Odstępy między literami","icon_color":"Ikona kolor","icon_size":"Ikona rozmiar","add_row":"Dodaj wiersz","add_separator":"Dodaj separator","custom_template":"Własny szablon","custom_template_hint":"Użyj dowolnego HTML oraz tagu <fcc row=\"3\" col=\"2\" /> aby wstawić komorkę z tabeli, lub <fcc row=\"3\" /> aby wstawić cały wiersz. Jeśli chcesz użyć globalnego CSS to zrób tak: <style>...</style><fcc />.","delete_row":"Usuń wiersz","separator_title":"Separator","separator_appearance":"Wyglad separatora","separator_color":"Kolor separatora","separator_background":"Kolor tła separatora","separator_color_picker":"Wybierz kolor","separator_style":"Styl linii","separator_style_solid":"Ciągła","separator_style_dashed":"Przerywana","separator_style_dotted":"Kropkowana","separator_thickness":"Grubość (px)","separator_length":"Długość / szerokość","separator_align":"Wyrównanie","separator_align_full":"Pełna szerokość","separator_align_center":"Środek","separator_align_left":"Lewo","separator_align_right":"Prawo","separator_opacity":"Przezroczystość","separator_margin_top":"Margines górny (px)","separator_margin_bottom":"Margines dolny (px)","separator_zero_hint":"Jeśli ustawisz grubość separatora na zero, separator będzie niewidoczny, ale nadal podzieli wiersze na grupy brane pod uwagę przy sortowaniu.","column":"Kolumna","drag_to_reorder":"Przeciągnij, aby zmienić kolejność","move_left":"Przenieś w lewo","move_right":"Przenieś w prawo","up":"Przenieś w górę","down":"Przenieś w dół","toggle":"Zwiń/Rozwiń","delete_column":"Usuń kolumnę","cell_type":"Typ komórki","entity_label":"Encja","string_label":"Tekst","icon_label":"Ikona","tap_action":"Akcja po kliknięciu","hold_action":"Akcja po przytrzymaniu","double_tap_action":"Akcja po dwukliku","advanced":"Akcje dotknięcia i przytrzymania (komórka)","custom_css":"Własny CSS","actions_hint":"Jeśli ustawisz jakąkolwiek akcję, domyślne 'more-info' dla encji zostanie wyłączone.","scale_title":"Przeskalowanie","scale_in_min":"Wejście min","scale_in_max":"Wejście max","scale_out_min":"Wyjście min","scale_out_max":"Wyjście max","scale_hint":"Mapuj wartość z jednego zakresu na inny (np. 0-255 → 0-100).","dynamic_title":"Reguły dynamiczne (komórka): kolor i nadpisywanie treści","dynamic_row_title":"Reguły dynamiczne (wiersz): kolor i ukrywanie wiersza","dynamic_hint":"Reguły sprawdzane są od góry do dołu, ostatnia dopasowana wygrywa.","datetime_format":"Format daty/czasu i nadpisanie tekstu","available_tokens":"Dostępne tokeny: RAW, YYYY, YY, MM, M, DD, D, HH, H, hh, h, mm, m, ss, s, MMMM, REL (czas, który upłynął), REL_SHORT (skrót czasu), [literały w nawiasach]","value":"Wartość"},"placeholder":{"entity":"Wybierz encję","string":"Tekst do wyświetlenia","icon":"mdi:nazwa-ikony","datetime_format":"np. H:mm:ss, YYYY-MM-DD H:mm, REL [temu], REL_SHORT [temu] lub [dowolny tekst]","attribute_path":"Ścieżka metadanych (np. a.b[0].c)"},"dynamic":{"operator":"Operator","match":"Logika warunków","match_all":"Wszystkie (AND)","match_any":"Dowolny (OR)","add_rule":"Dodaj regułę","add_condition":"Dodaj warunek","delete_rule":"Usuń","delete_condition":"Usuń warunek","op_between":"pomiędzy","op_contains":"zawiera","op_not_contains":"nie zawiera","min":"Min","max":"Max","bg":"Kolor tła","fg":"Kolor zawartości","overwrite_label":"Nadpisz zawartość","overwrite_hide":"Ukryj","overwrite_text":"Nadpisz tekstem","overwrite_icon":"Nadpisz ikoną","overwrite_entity_metadata":"Nadpisz encją/metadanymi","visibility_label":"Widoczność","visibility_visible":"Widoczny","visibility_hidden":"Ukryty","text":"Tekst","icon_optional_text":"Opcjonalny tekst","icon_color":"Kolor ikony"},"align":{"left":"lewo","center":"środek","right":"prawo"},"precision":{"two":"dwa miejsca","one":"jedno miejsce","int":"liczba całkowita"},"style":{"bold":"pogrubienie","italic":"kursywa","underline":"podkreślenie","strike":"przekreślenie"},"card":{"no_rows":"Brak wierszy do wyświetlenia."}}};
var ut=(m,t)=>()=>(m&&(t=m(m=0)),t);var Et,Tt,Wt,de,yt,he,vt,pe,Kt,qt=ut(()=>{Et=globalThis,Tt=Et.ShadowRoot&&(Et.ShadyCSS===void 0||Et.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,Wt=Symbol(),de=new WeakMap,yt=class{constructor(t,e,i){if(this._$cssResult$=!0,i!==Wt)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e}get styleSheet(){let t=this.o,e=this.t;if(Tt&&t===void 0){let i=e!==void 0&&e.length===1;i&&(t=de.get(e)),t===void 0&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),i&&de.set(e,t))}return t}toString(){return this.cssText}},he=m=>new yt(typeof m=="string"?m:m+"",void 0,Wt),vt=(m,...t)=>{let e=m.length===1?m[0]:t.reduce((i,s,n)=>i+(r=>{if(r._$cssResult$===!0)return r.cssText;if(typeof r=="number")return r;throw Error("Value passed to 'css' function must be a 'css' function result: "+r+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(s)+m[n+1],m[0]);return new yt(e,m,Wt)},pe=(m,t)=>{if(Tt)m.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(let e of t){let i=document.createElement("style"),s=Et.litNonce;s!==void 0&&i.setAttribute("nonce",s),i.textContent=e.cssText,m.appendChild(i)}},Kt=Tt?m=>m:m=>m instanceof CSSStyleSheet?(t=>{let e="";for(let i of t.cssRules)e+=i.cssText;return he(e)})(m):m});var We,Ke,qe,Ye,Ge,Je,Dt,_e,Xe,Ze,$t,Yt,me,fe,rt,Rt=ut(()=>{qt();qt();({is:We,defineProperty:Ke,getOwnPropertyDescriptor:qe,getOwnPropertyNames:Ye,getOwnPropertySymbols:Ge,getPrototypeOf:Je}=Object),Dt=globalThis,_e=Dt.trustedTypes,Xe=_e?_e.emptyScript:"",Ze=Dt.reactiveElementPolyfillSupport,$t=(m,t)=>m,Yt={toAttribute(m,t){switch(t){case Boolean:m=m?Xe:null;break;case Object:case Array:m=m==null?m:JSON.stringify(m)}return m},fromAttribute(m,t){let e=m;switch(t){case Boolean:e=m!==null;break;case Number:e=m===null?null:Number(m);break;case Object:case Array:try{e=JSON.parse(m)}catch{e=null}}return e}},me=(m,t)=>!We(m,t),fe={attribute:!0,type:String,converter:Yt,reflect:!1,useDefault:!1,hasChanged:me};Symbol.metadata??=Symbol("metadata"),Dt.litPropertyMetadata??=new WeakMap;rt=class extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??=[]).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,e=fe){if(e.state&&(e.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(t)&&((e=Object.create(e)).wrapped=!0),this.elementProperties.set(t,e),!e.noAccessor){let i=Symbol(),s=this.getPropertyDescriptor(t,i,e);s!==void 0&&Ke(this.prototype,t,s)}}static getPropertyDescriptor(t,e,i){let{get:s,set:n}=qe(this.prototype,t)??{get(){return this[e]},set(r){this[e]=r}};return{get:s,set(r){let a=s?.call(this);n?.call(this,r),this.requestUpdate(t,a,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??fe}static _$Ei(){if(this.hasOwnProperty($t("elementProperties")))return;let t=Je(this);t.finalize(),t.l!==void 0&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty($t("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty($t("properties"))){let e=this.properties,i=[...Ye(e),...Ge(e)];for(let s of i)this.createProperty(s,e[s])}let t=this[Symbol.metadata];if(t!==null){let e=litPropertyMetadata.get(t);if(e!==void 0)for(let[i,s]of e)this.elementProperties.set(i,s)}this._$Eh=new Map;for(let[e,i]of this.elementProperties){let s=this._$Eu(e,i);s!==void 0&&this._$Eh.set(s,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){let e=[];if(Array.isArray(t)){let i=new Set(t.flat(1/0).reverse());for(let s of i)e.unshift(Kt(s))}else t!==void 0&&e.push(Kt(t));return e}static _$Eu(t,e){let i=e.attribute;return i===!1?void 0:typeof i=="string"?i:typeof t=="string"?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(t=>t(this))}addController(t){(this._$EO??=new Set).add(t),this.renderRoot!==void 0&&this.isConnected&&t.hostConnected?.()}removeController(t){this._$EO?.delete(t)}_$E_(){let t=new Map,e=this.constructor.elementProperties;for(let i of e.keys())this.hasOwnProperty(i)&&(t.set(i,this[i]),delete this[i]);t.size>0&&(this._$Ep=t)}createRenderRoot(){let t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return pe(t,this.constructor.elementStyles),t}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(t=>t.hostConnected?.())}enableUpdating(t){}disconnectedCallback(){this._$EO?.forEach(t=>t.hostDisconnected?.())}attributeChangedCallback(t,e,i){this._$AK(t,i)}_$ET(t,e){let i=this.constructor.elementProperties.get(t),s=this.constructor._$Eu(t,i);if(s!==void 0&&i.reflect===!0){let n=(i.converter?.toAttribute!==void 0?i.converter:Yt).toAttribute(e,i.type);this._$Em=t,n==null?this.removeAttribute(s):this.setAttribute(s,n),this._$Em=null}}_$AK(t,e){let i=this.constructor,s=i._$Eh.get(t);if(s!==void 0&&this._$Em!==s){let n=i.getPropertyOptions(s),r=typeof n.converter=="function"?{fromAttribute:n.converter}:n.converter?.fromAttribute!==void 0?n.converter:Yt;this._$Em=s;let a=r.fromAttribute(e,n.type);this[s]=a??this._$Ej?.get(s)??a,this._$Em=null}}requestUpdate(t,e,i){if(t!==void 0){let s=this.constructor,n=this[t];if(i??=s.getPropertyOptions(t),!((i.hasChanged??me)(n,e)||i.useDefault&&i.reflect&&n===this._$Ej?.get(t)&&!this.hasAttribute(s._$Eu(t,i))))return;this.C(t,e,i)}this.isUpdatePending===!1&&(this._$ES=this._$EP())}C(t,e,{useDefault:i,reflect:s,wrapped:n},r){i&&!(this._$Ej??=new Map).has(t)&&(this._$Ej.set(t,r??e??this[t]),n!==!0||r!==void 0)||(this._$AL.has(t)||(this.hasUpdated||i||(e=void 0),this._$AL.set(t,e)),s===!0&&this._$Em!==t&&(this._$Eq??=new Set).add(t))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}let t=this.scheduleUpdate();return t!=null&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[s,n]of this._$Ep)this[s]=n;this._$Ep=void 0}let i=this.constructor.elementProperties;if(i.size>0)for(let[s,n]of i){let{wrapped:r}=n,a=this[s];r!==!0||this._$AL.has(s)||a===void 0||this.C(s,void 0,n,a)}}let t=!1,e=this._$AL;try{t=this.shouldUpdate(e),t?(this.willUpdate(e),this._$EO?.forEach(i=>i.hostUpdate?.()),this.update(e)):this._$EM()}catch(i){throw t=!1,this._$EM(),i}t&&this._$AE(e)}willUpdate(t){}_$AE(t){this._$EO?.forEach(e=>e.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Eq&&=this._$Eq.forEach(e=>this._$ET(e,this[e])),this._$EM()}updated(t){}firstUpdated(t){}};rt.elementStyles=[],rt.shadowRootOptions={mode:"open"},rt[$t("elementProperties")]=new Map,rt[$t("finalized")]=new Map,Ze?.({ReactiveElement:rt}),(Dt.reactiveElementVersions??=[]).push("2.1.1")});function Ae(m,t){if(!Qt(m)||!m.hasOwnProperty("raw"))throw Error("invalid template strings array");return ge!==void 0?ge.createHTML(t):t}function _t(m,t,e=m,i){if(t===X)return t;let s=i!==void 0?e._$Co?.[i]:e._$Cl,n=xt(t)?void 0:t._$litDirective$;return s?.constructor!==n&&(s?._$AO?.(!1),n===void 0?s=void 0:(s=new n(m),s._$AT(m,e,i)),i!==void 0?(e._$Co??=[])[i]=s:e._$Cl=s),s!==void 0&&(t=_t(m,s._$AS(m,t.values),s,i)),t}var Jt,Pt,ge,Xt,at,Zt,Qe,pt,Ct,xt,Qt,Ce,Gt,wt,be,ye,dt,ve,$e,xe,It,g,yi,vi,X,N,we,ht,ke,At,Mt,gt,ft,Ft,zt,Lt,Ot,Se,Ie,Ne,mt=ut(()=>{Jt=globalThis,Pt=Jt.trustedTypes,ge=Pt?Pt.createPolicy("lit-html",{createHTML:m=>m}):void 0,Xt="$lit$",at=`lit$${Math.random().toFixed(9).slice(2)}$`,Zt="?"+at,Qe=`<${Zt}>`,pt=document,Ct=()=>pt.createComment(""),xt=m=>m===null||typeof m!="object"&&typeof m!="function",Qt=Array.isArray,Ce=m=>Qt(m)||typeof m?.[Symbol.iterator]=="function",Gt=`[ 	
\f\r]`,wt=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,be=/-->/g,ye=/>/g,dt=RegExp(`>|${Gt}(?:([^\\s"'>=/]+)(${Gt}*=${Gt}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`,"g"),ve=/'/g,$e=/"/g,xe=/^(?:script|style|textarea|title)$/i,It=m=>(t,...e)=>({_$litType$:m,strings:t,values:e}),g=It(1),yi=It(2),vi=It(3),X=Symbol.for("lit-noChange"),N=Symbol.for("lit-nothing"),we=new WeakMap,ht=pt.createTreeWalker(pt,129);ke=(m,t)=>{let e=m.length-1,i=[],s,n=t===2?"<svg>":t===3?"<math>":"",r=wt;for(let a=0;a<e;a++){let o=m[a],l,c,u=-1,h=0;for(;h<o.length&&(r.lastIndex=h,c=r.exec(o),c!==null);)h=r.lastIndex,r===wt?c[1]==="!--"?r=be:c[1]!==void 0?r=ye:c[2]!==void 0?(xe.test(c[2])&&(s=RegExp("</"+c[2],"g")),r=dt):c[3]!==void 0&&(r=dt):r===dt?c[0]===">"?(r=s??wt,u=-1):c[1]===void 0?u=-2:(u=r.lastIndex-c[2].length,l=c[1],r=c[3]===void 0?dt:c[3]==='"'?$e:ve):r===$e||r===ve?r=dt:r===be||r===ye?r=wt:(r=dt,s=void 0);let p=r===dt&&m[a+1].startsWith("/>")?" ":"";n+=r===wt?o+Qe:u>=0?(i.push(l),o.slice(0,u)+Xt+o.slice(u)+at+p):o+at+(u===-2?a:p)}return[Ae(m,n+(m[e]||"<?>")+(t===2?"</svg>":t===3?"</math>":"")),i]},At=class m{constructor({strings:t,_$litType$:e},i){let s;this.parts=[];let n=0,r=0,a=t.length-1,o=this.parts,[l,c]=ke(t,e);if(this.el=m.createElement(l,i),ht.currentNode=this.el.content,e===2||e===3){let u=this.el.content.firstChild;u.replaceWith(...u.childNodes)}for(;(s=ht.nextNode())!==null&&o.length<a;){if(s.nodeType===1){if(s.hasAttributes())for(let u of s.getAttributeNames())if(u.endsWith(Xt)){let h=c[r++],p=s.getAttribute(u).split(at),b=/([.?@])?(.*)/.exec(h);o.push({type:1,index:n,name:b[2],strings:p,ctor:b[1]==="."?Ft:b[1]==="?"?zt:b[1]==="@"?Lt:ft}),s.removeAttribute(u)}else u.startsWith(at)&&(o.push({type:6,index:n}),s.removeAttribute(u));if(xe.test(s.tagName)){let u=s.textContent.split(at),h=u.length-1;if(h>0){s.textContent=Pt?Pt.emptyScript:"";for(let p=0;p<h;p++)s.append(u[p],Ct()),ht.nextNode(),o.push({type:2,index:++n});s.append(u[h],Ct())}}}else if(s.nodeType===8)if(s.data===Zt)o.push({type:2,index:n});else{let u=-1;for(;(u=s.data.indexOf(at,u+1))!==-1;)o.push({type:7,index:n}),u+=at.length-1}n++}}static createElement(t,e){let i=pt.createElement("template");return i.innerHTML=t,i}};Mt=class{constructor(t,e){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){let{el:{content:e},parts:i}=this._$AD,s=(t?.creationScope??pt).importNode(e,!0);ht.currentNode=s;let n=ht.nextNode(),r=0,a=0,o=i[0];for(;o!==void 0;){if(r===o.index){let l;o.type===2?l=new gt(n,n.nextSibling,this,t):o.type===1?l=new o.ctor(n,o.name,o.strings,this,t):o.type===6&&(l=new Ot(n,this,t)),this._$AV.push(l),o=i[++a]}r!==o?.index&&(n=ht.nextNode(),r++)}return ht.currentNode=pt,s}p(t){let e=0;for(let i of this._$AV)i!==void 0&&(i.strings!==void 0?(i._$AI(t,i,e),e+=i.strings.length-2):i._$AI(t[e])),e++}},gt=class m{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,e,i,s){this.type=2,this._$AH=N,this._$AN=void 0,this._$AA=t,this._$AB=e,this._$AM=i,this.options=s,this._$Cv=s?.isConnected??!0}get parentNode(){let t=this._$AA.parentNode,e=this._$AM;return e!==void 0&&t?.nodeType===11&&(t=e.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,e=this){t=_t(this,t,e),xt(t)?t===N||t==null||t===""?(this._$AH!==N&&this._$AR(),this._$AH=N):t!==this._$AH&&t!==X&&this._(t):t._$litType$!==void 0?this.$(t):t.nodeType!==void 0?this.T(t):Ce(t)?this.k(t):this._(t)}O(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.O(t))}_(t){this._$AH!==N&&xt(this._$AH)?this._$AA.nextSibling.data=t:this.T(pt.createTextNode(t)),this._$AH=t}$(t){let{values:e,_$litType$:i}=t,s=typeof i=="number"?this._$AC(t):(i.el===void 0&&(i.el=At.createElement(Ae(i.h,i.h[0]),this.options)),i);if(this._$AH?._$AD===s)this._$AH.p(e);else{let n=new Mt(s,this),r=n.u(this.options);n.p(e),this.T(r),this._$AH=n}}_$AC(t){let e=we.get(t.strings);return e===void 0&&we.set(t.strings,e=new At(t)),e}k(t){Qt(this._$AH)||(this._$AH=[],this._$AR());let e=this._$AH,i,s=0;for(let n of t)s===e.length?e.push(i=new m(this.O(Ct()),this.O(Ct()),this,this.options)):i=e[s],i._$AI(n),s++;s<e.length&&(this._$AR(i&&i._$AB.nextSibling,s),e.length=s)}_$AR(t=this._$AA.nextSibling,e){for(this._$AP?.(!1,!0,e);t!==this._$AB;){let i=t.nextSibling;t.remove(),t=i}}setConnected(t){this._$AM===void 0&&(this._$Cv=t,this._$AP?.(t))}},ft=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,e,i,s,n){this.type=1,this._$AH=N,this._$AN=void 0,this.element=t,this.name=e,this._$AM=s,this.options=n,i.length>2||i[0]!==""||i[1]!==""?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=N}_$AI(t,e=this,i,s){let n=this.strings,r=!1;if(n===void 0)t=_t(this,t,e,0),r=!xt(t)||t!==this._$AH&&t!==X,r&&(this._$AH=t);else{let a=t,o,l;for(t=n[0],o=0;o<n.length-1;o++)l=_t(this,a[i+o],e,o),l===X&&(l=this._$AH[o]),r||=!xt(l)||l!==this._$AH[o],l===N?t=N:t!==N&&(t+=(l??"")+n[o+1]),this._$AH[o]=l}r&&!s&&this.j(t)}j(t){t===N?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}},Ft=class extends ft{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===N?void 0:t}},zt=class extends ft{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==N)}},Lt=class extends ft{constructor(t,e,i,s,n){super(t,e,i,s,n),this.type=5}_$AI(t,e=this){if((t=_t(this,t,e,0)??N)===X)return;let i=this._$AH,s=t===N&&i!==N||t.capture!==i.capture||t.once!==i.once||t.passive!==i.passive,n=t!==N&&(i===N||s);s&&this.element.removeEventListener(this.name,this,i),n&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){typeof this._$AH=="function"?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t)}},Ot=class{constructor(t,e,i){this.element=t,this.type=6,this._$AN=void 0,this._$AM=e,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(t){_t(this,t)}},Se={M:Xt,P:at,A:Zt,C:1,L:ke,R:Mt,D:Ce,V:_t,I:gt,H:ft,N:zt,U:Lt,B:Ft,F:Ot},Ie=Jt.litHtmlPolyfillSupport;Ie?.(At,gt),(Jt.litHtmlVersions??=[]).push("3.3.1");Ne=(m,t,e)=>{let i=e?.renderBefore??t,s=i._$litPart$;if(s===void 0){let n=e?.renderBefore??null;i._$litPart$=s=new gt(t.insertBefore(Ct(),n),n,void 0,e??{})}return s._$AI(m),s}});var te,nt,ti,Ee=ut(()=>{Rt();Rt();mt();mt();te=globalThis,nt=class extends rt{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){let e=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=Ne(e,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return X}};nt._$litElement$=!0,nt.finalized=!0,te.litElementHydrateSupport?.({LitElement:nt});ti=te.litElementPolyfillSupport;ti?.({LitElement:nt});(te.litElementVersions??=[]).push("4.2.1")});var Te=ut(()=>{});var ee=ut(()=>{Rt();mt();Ee();Te()});function d(m,t){let i=(m?.locale?.language||"en").toLowerCase().split("-")[0];Me(i);let s=t.split("."),n=De(kt[i],s);if(n!==void 0&&n!=="")return n;let r=De(kt.en,s);return r!==void 0&&r!==""?r:t}var kt,ie,Re,Vt,Pe,De,Me,se=ut(()=>{kt={},ie=new Set,Re=(m,t)=>m?.[t]??m?.["en"]??m,Vt=globalThis.FCC_LOCALES,Pe=Vt&&typeof Vt=="object"&&Object.keys(Vt).length;if(Pe)for(let[m,t]of Object.entries(Vt))kt[m]=Re(t,m);De=(m,t)=>t.reduce((e,i)=>e?.[i],m),Me=m=>{if(!m||Pe||kt[m]||ie.has(m))return;ie.add(m);let t=new URL(`./lang/${m}.json`,import.meta.url);fetch(t).then(e=>e.ok?e.json():null).then(e=>{e&&(kt[m]=Re(e,m))}).catch(()=>{}).finally(()=>{ie.delete(m),window.dispatchEvent(new CustomEvent("fcc-locales-loaded",{detail:{lang:m}}))})};Me("en")});var ei={};var ne,oe=ut(()=>{ee();se();ne=class extends nt{static properties={config:{},hass:{}};static styles=vt`
    .row { margin-bottom: 16px; }
    ha-textfield, ha-select { width: 100%; box-sizing: border-box; margin-bottom: 8px; }
    input[list], select, .text-input {
      width: 100%; padding: 10px 12px; font-size: 14px;
      border: 1px solid var(--divider-color,#ccc); border-radius: 8px; box-sizing: border-box;
      background: var(--card-background-color, white);
      transition: border 0.2s, box-shadow 0.2s;
    }
    input[list]:focus, select:focus, .text-input:focus {
      border-color: var(--primary-color, #03a9f4);
      outline: none; box-shadow: 0 0 4px rgba(3,169,244,.4);
    }
    .cols3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; }
    .cols2 > * { min-width: 0; }
    .cols2 {
      /* prevent overflow from MWC internals */
       display: grid; grid-template-columns: minmax(0,1fr) minmax(0,1fr); gap: 8px; }
    .cols2 > * { min-width: 0; }
    .option.group .cols1, .option.group .cols2, .option.group .cols3 { width: 100%; }
    .cols1 { display: grid; grid-template-columns: 1fr; gap: 8px; }
    .cols2 > * { min-width: 0; }
    .cols4 {
      display: grid;
      grid-template-columns: 1fr 1fr; /* było: repeat(4, 1fr) */
      gap: 8px;
    }
    .cols21 { display: grid; grid-template-columns: 2fr 1fr; gap: 8px; }
    .cols2 > * { min-width: 0; }

    .cell-grid { display: grid; grid-template-columns: 160px 1fr; gap: 8px; align-items: center; margin-bottom: 8px; }
    .cell-wide { grid-template-columns: 1fr; }

    .flex { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
    .inline { display: inline-flex; align-items: center; gap: 8px; }
    .cols2 > * { min-width: 0; }
    .muted { color: #888; font-size: 12px; margin-top: -4px; margin-bottom: 8px; }
    .rulehdr { color: #888; font-size: 12px; margin: 0 0 4px; }
    .mini { width: 140px; padding: 6px 8px; font-size: 13px; margin: 0; }
    .mini-wide { width: 220px; padding: 6px 8px; font-size: 13px; margin: 0; }
    button { padding: 8px 12px; border-radius: 8px; border: 1px solid var(--divider-color, #ddd); background: var(--card-background-color, #fff); cursor: pointer; }

    .options { display: grid; grid-template-columns: 1fr; gap: 8px; margin: 8px 0; }
    .option {
      display: flex; align-items: center; gap: 10px;
      padding: 10px 12px; border: 1px solid var(--divider-color, #ddd);
      border-radius: 10px; background: var(--card-background-color, #fff);
      cursor: pointer; user-select: none;
    }
    .option input { margin: 0; }
    .option.unit { align-items: center; gap: 12px; }
    .option.unit span.label { flex: 0 0 auto; }
    .option.unit ha-textfield { flex: 1 1 auto; margin: 0; }
    .option.group { display:block; cursor: default; margin-bottom:12px; }
    .option.full { width: 100%; box-sizing: border-box; }
    .option.option-stack { flex-direction: column; align-items: flex-start; gap: 8px; }
    .option.option-stack label { display: flex; align-items: center; gap: 10px; width: 100%; cursor: pointer; }
    .option.option-stack label span { flex: 1 1 auto; }
    .option.option-stack label + label { margin-top: 4px; }
    .copy-section { display: flex; flex-direction: column; gap: 12px; margin-top: 12px; }
    .copy-group {
      border: 1px solid var(--divider-color, #ddd);
      border-radius: 10px;
      background: var(--card-background-color, #fff);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .copy-group-title { font-weight: 600; font-size: 13px; }
    .copy-group-buttons { display: flex; flex-wrap: wrap; gap: 8px; }
    .muted.copy-summary { margin: 0; }

    .tabs { display: flex; gap: 6px; margin: 8px 0 12px; flex-wrap: wrap; }
    .tab {
      padding: 6px 10px; border-radius: 8px; border: 1px solid var(--divider-color,#ddd);
      background: var(--card-background-color,#fff); cursor: pointer; font-size: 13px;
    }
    .tab.active {
      border-color: var(--primary-color,#03a9f4);
      box-shadow: 0 0 0 2px rgba(3,169,244,0.15);
    }

    .rowbox { touch-action: pan-y; border: 1px solid var(--divider-color, #e0e0e0); border-radius: 10px; background: var(--card-background-color, #fff); overflow: unset; }
    .rowhdr { display: grid; grid-template-columns: auto auto auto 1fr auto; gap: 8px; align-items: center; padding: 10px 8px; border-bottom: 1px solid var(--divider-color, #e0e0e0);
      user-select: none; -webkit-user-select: none; -webkit-touch-callout: none;
    }
    .rowhdr.collapsed { border-bottom: none; }

    .handle {
      cursor: grab; padding: 6px 8px; border-radius: 8px;
      border: 1px dashed var(--divider-color, #ddd);
      font-family: system-ui, sans-serif; font-size: 14px; line-height: 1;
      color: var(--primary-text-color, #000);
      touch-action: none; user-select: none; -webkit-user-select: none; -webkit-touch-callout: none;
    }

    .toggle { width: 28px; height: 28px; border-radius: 8px; border: 1px solid var(--divider-color,#ddd); background: var(--card-background-color,#fff); display: inline-flex; align-items: center; justify-content: center; cursor: pointer; font-size: 14px; line-height: 1; }
    .title { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .preview { color: #777; min-width: 120px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .rowtools { display: inline-flex; gap: 6px; margin-left: auto; }
    .rowtools button { padding: 6px 10px; }
    .rowtools button.danger { color: var(--error-color, #d32f2f); }
    .rowbody { padding: 10px; }

    .dragover { outline: 2px dashed var(--primary-color, #03a9f4); outline-offset: 4px; }

    .colbar { border: 1px solid var(--divider-color, #e0e0e0); border-radius: 10px; background: var(--card-background-color, #fff); margin: 8px 0 12px; overflow: hidden; }
    .colstrip { display: flex; gap: 8px; padding: 8px; overflow-x: auto; -webkit-overflow-scrolling: touch; }
    .colchip { display: flex; flex-direction: column; gap: 6px; border: 1px solid var(--divider-color, #e0e0e0); border-radius: 10px; background: var(--card-background-color, #fff); padding: 8px; min-width: 120px; box-sizing: border-box; overflow: hidden; }
    .colchip.is-over { outline: 2px dashed var(--primary-color,#03a9f4); outline-offset: -4px; }

    .chiplabel { font-weight: 600; font-size: 13px; text-align: center; white-space: nowrap; }
    .chiptools { display: flex; gap: 6px; justify-content: center; align-items: center; width: 100%; }
    .chiptools button { display: inline-flex; align-items: center; justify-content: center; padding: 4px 8px; height: 28px; line-height: 1; box-sizing: border-box; flex: 0 0 auto; }
    .chiptools button.danger { color: var(--error-color, #d32f2f); }

    .colhandle {
      margin-top: 4px; height: 24px;
      display: flex; align-items: center; justify-content: center;
      border: 1px dashed var(--divider-color,#ddd); border-radius: 8px;
      background: var(--card-background-color, #fff);
      color: var(--primary-text-color, #000);
      cursor: grab; user-select: none; touch-action: none;
      padding: 0 6px;
    }
    .colhandle:active { cursor: grabbing; }
    .dots {
      display: grid; grid-template-columns: repeat(5, min-content);
      column-gap: 6px; row-gap: 4px; align-items: center; justify-content: center;
    }
    .dot { width: 2px; height: 2px; border-radius: 50%; background: currentColor; }

    .addrow {
      margin: 6px 0 16px;
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      align-items: center;
    }
    .addrow button .btn-icon {
      margin-right: 6px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    .addrow button.secondary .btn-icon {
      color: var(--secondary-text-color, #888);
    }

    .rowhdr.separator {
      grid-template-columns: auto auto 1fr auto;
    }
    .rowhdr.separator .preview {
      display: none;
    }
    .option-group {
      width: 100%;
      box-sizing: border-box;
      padding: 10px 12px;
      border: 1px solid var(--divider-color, #ddd);
      border-radius: 10px;
      background: var(--card-background-color, #fff);
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .option-group label {
      display: flex;
      align-items: center;
      gap: 10px;
      margin: 0;
      cursor: pointer;
    }
    .option-group label.disabled {
      opacity: 0.6;
      cursor: pointer;
    }
    .option-group input {
      margin: 0;
    }
    .service-id-preview {
      display: block;
      margin: 6px 0 10px;
      padding-left: 2px;
      font-size: 12px;
      font-family: "Roboto Mono", monospace;
      letter-spacing: 0.1px;
      color: var(--secondary-text-color, #666);
      opacity: 0.9;
    }
    .service-id-preview::before {
      content: "• ";
      color: var(--primary-text-color, #444);
      opacity: 0.7;
    }
    .attr-edit-toggle { 
      margin-bottom: 10px;
      margin-top: 10px;
    }
    .attr-edit-fields.disabled { opacity: 0.6; pointer-events: none; }
    .simple-check {
      display: flex;
      align-items: center;
      gap: 10px;
      margin: 0;
      padding: 0;
      border: none;
      background: transparent;
      cursor: pointer;
    }
    .simple-check input {
      margin: 0;
    }
    .simple-check span {
      font-size: 14px;
    }

    /* Sekcja przeskalowania: 4 rzędy, 2 kolumny */
    .option.group.scale {
      display: grid;
      grid-template-columns: repeat(2, minmax(140px, 1fr));
      gap: 8px 12px;
      padding: 0 !important;
      border: none;
      border-radius: 12px;
      background: var(--card-background-color, #fff);
      margin: 8px 0 12px; /* odstęp pod ramką przed "Alignment" */
    }

    .option.group.scale .label,
    .option.group.scale .muted {
      grid-column: 1 / -1; /* pierwszy i czwarty wiersz na pełną szerokość */
    }

    .option.group.scale ha-textfield.mini {
      width: 100%;
      margin: 0;
      padding: 0;
    }

    @media (max-width: 680px) {
      .cols3, .cols21 { grid-template-columns: 1fr; }
      .cols4 { grid-template-columns: 1fr 1fr; }
      .rowhdr { gap: 6px; padding: 8px 8px; }
      .handle { padding: 4px 6px; }
      .toggle { width: 28px; height: 28px; }
      .rowtools { gap: 6px; }
      .rowtools button, .chiptools button { padding: 4px 8px; height: 28px; }
      .preview { display: none; }
      .option.group.scale { grid-template-columns: 1fr; }
    }

    .toggle, .rowtools button { display: inline-flex; align-items: center; justify-content: center; line-height: 1; }

    .rowhdr *:not(input):not(textarea):not(select) { user-select: none; -webkit-user-select: none; -webkit-touch-callout: none; }

    /* Mobile scroll + selection fixes */
    .rowbox, .rowhdr, .rowbody,
    .rowhdr > *:not(.handle),
    .rowbody * { touch-action: pan-y; }
    .handle, .colhandle { touch-action: none; }
    .rowbox *:not(input):not(textarea):not(select) {
      user-select: none;
      -webkit-user-select: none;
      -webkit-touch-callout: none;
    }
    .rowtools button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
      color: var(--disabled-text-color, var(--secondary-text-color, #999));
      border-color: var(--divider-color, #ddd);
      box-shadow: none;
    }
    .chiptools button:disabled { opacity:.5; cursor:not-allowed; }
  
    .right { display: flex; justify-content: flex-end; }
    .dyn-hint { margin-top: 6px; }
    .option.group .attr-input { margin-top: 8px; margin-bottom: 8px; }
    .option.group button.danger { margin-top: 8px; }
    .option.group button.danger.mini { width: auto; }

    .option.group .mask-input { margin-top: 8px; }
`;_isSimpleControlEntity(t){let e=t?.value||"";if(!e||t?.attribute)return!1;let i=e.split?e.split(".")[0]:"";return["input_boolean","switch","input_number","number","input_select","select","input_button","button","input_datetime","datetime","date","time","input_text","text"].includes(i)}_cellShowControlChanged(t,e,i){let s=!!i?.target?.checked,n=[...this.config.rows||[]],r={...n[t]||{}},a=[...r.cells||[]],o={...a[e]||{}};s?o.show_control=!0:(delete o.show_control,delete o.show_control_value_right),a[e]=o,n[t]={...r,cells:a},this.config={...this.config,rows:n},this._fireConfigChanged?.()}_cellShowControlValueRightChanged(t,e,i){let s=!!i?.target?.checked,n=[...this.config.rows||[]],r={...n[t]||{}},a=[...r.cells||[]],o={...a[e]||{}};o.show_control_value_right=s,a[e]=o,n[t]={...r,cells:a},this.config={...this.config,rows:n},this._fireConfigChanged?.()}_defaultRowCss(){return`tr {
   background-color: yellow;
   border: 2px dashed red;
}
`}_defaultCellCss(){return`th, td {
   background-color: yellow;
   border: 2px dashed red;
}
`}_toggleRowCustomCss(t,e){let i=!!e?.target?.checked,s=this.config?.rows?.[t]||{},n=typeof s.custom_css=="string"?s.custom_css:"",r=n&&n.trim()?n:this._defaultRowCss();i?this._patchRow(t,{custom_css_enabled:!0,custom_css:r}):this._patchRow(t,{custom_css_enabled:!1})}_updateRowCustomCss(t,e){let i=e?.target?.value??"";this._patchRow(t,{custom_css:i})}_toggleCellCustomCss(t,e,i){let s=!!i?.target?.checked,n=this.config?.rows?.[t]?.cells?.[e]||{},r=typeof n.custom_css=="string"?n.custom_css:"",a=r&&r.trim()?r:this._defaultCellCss();s?this._patchCell(t,e,{custom_css_enabled:!0,custom_css:a}):this._patchCell(t,e,{custom_css_enabled:!1})}_updateCellCustomCss(t,e,i){let s=i?.target?.value??"";this._patchCell(t,e,{custom_css:s})}constructor(){super(),this.config={rows:[],column_count:2,card_padding:"",overflow_x:!0,header_from_first_row:!1,zebra:!1,narrow_breakpoint:"",text_size:"",cell_padding:{top:4,right:0,bottom:4,left:0},custom_template_enabled:!1,custom_template_html:""},this._activeTabs={},this._clipboardCell=this._createClipboardBucket(),this._clipboardRow=this._createClipboardBucket(),this._collapsed=[],this._dragIndex=null,this._dragOverIndex=null,this._fullCells=[],this._colDragFrom=null,this._colDragOver=null,this._colDragActive=!1,this._boundPointerMove=t=>this._onColPointerMove(t),this._boundPointerUp=t=>this._onColPointerUp(t),this._rowDragFrom=null,this._rowDragActive=!1,this._boundRowPointerMove=t=>this._onRowPointerMove(t),this._boundRowPointerUp=t=>this._onRowPointerUp(t),this._isTouchDevice=window.matchMedia&&window.matchMedia("(pointer: coarse)").matches||(navigator.maxTouchPoints||0)>0,this._preventContextMenu=t=>{try{t.preventDefault()}catch{}},this._boundRowPointerCancel=t=>this._onRowPointerCancel?.(t),this._boundColPointerCancel=t=>this._onColPointerCancel?.(t)}_getStateObject(t){if(t)return this.hass?.states?.[t]}_buildEntityValueTree(t){if(!t)return{};let e=t.attributes||{},i={...e,attributes:e,entity_id:t.entity_id,state:t.state,last_changed:t.last_changed,last_updated:t.last_updated};return t.context!==void 0&&(i.context=t.context),i}_resolveEntityValue(t,e){if(!t||!e)return;let i=this._buildEntityValueTree(t);return this._resolvePath(i,e)}_getEntityAttributesObject(t,e){try{let i=this.config?.rows?.[t]?.cells?.[e]?.value,s=this._getStateObject(i);return this._buildEntityValueTree(s)}catch{return{}}}_resolvePath(t,e){if(!t)return;let i=String(e||"").replace(/\[(\d+)\]/g,".$1").split(".").filter(Boolean),s=t;for(let n of i){let r=Array.isArray(s)&&/^\d+$/.test(n)?Number(n):n;if(s==null||!(r in s))return;s=s[r]}return s}_listKeys(t){return t==null?[]:Array.isArray(t)?t.map((e,i)=>String(i)):typeof t=="object"?Object.keys(t):[]}_buildAttrSuggestions(t,e,i){let s=this._getEntityAttributesObject(t,e)||{},n=String(i||"");if(n==="")return Object.keys(s).sort();let r=n.replace(/\[(\d+)\]/g,".$1"),a=r.split("."),l=r.endsWith(".")?"":a[a.length-1],c=a.length>1?a.slice(0,-1).join("."):"",u=s;if(a.length>1&&(u=this._resolvePath(s,a.slice(0,-1).join(".")),u===void 0))return[];let h=this._listKeys(u).sort();return(l?h.filter(b=>b.startsWith(l)):h).map(b=>(c?c+".":"")+b)}_buildAttrSuggestionsForEntity(t,e){let i=this._buildEntityValueTree(this._getStateObject(t)),s=String(e||"");if(s==="")return Object.keys(i||{}).sort();let n=s.replace(/\[(\d+)\]/g,".$1"),r=n.split("."),o=n.endsWith(".")?"":r[r.length-1],l=r.length>1?r.slice(0,-1).join("."):"",c=i;if(r.length>1&&(c=this._resolvePath(i,r.slice(0,-1).join(".")),c===void 0))return[];let u=this._listKeys(c).sort();return(o?u.filter(p=>p.startsWith(o)):u).map(p=>(l?l+".":"")+p)}_listServiceNames(){let t=this.hass?.services||{},e=[];return Object.keys(t).forEach(i=>{let s=t[i];!s||typeof s!="object"||Object.keys(s).forEach(n=>e.push(`${i}.${n}`))}),e.sort()}_listServiceFields(t){let e=typeof t=="string"?t.trim():"";if(!e||!e.includes("."))return[];let[i,s]=e.split(".",2),r=this.hass?.services?.[i]?.[s]?.fields;return!r||typeof r!="object"?[]:Object.keys(r).sort()}async _ensureEntityPickerLoaded(){try{if(!customElements.get("ha-entity-picker")){let t=await(window.loadCardHelpers?window.loadCardHelpers():void 0);if(t){let e=await t.createCardElement({type:"entities",entities:[]});e?.constructor?.getConfigElement&&await e.constructor.getConfigElement()}}}catch{}}async _ensureServicePickerLoaded(){try{if(!customElements.get("ha-service-picker")){let t=await(window.loadCardHelpers?window.loadCardHelpers():void 0);if(t){let e=await t.createCardElement({type:"entities",entities:[]});e?.constructor?.getConfigElement&&await e.constructor.getConfigElement()}}}catch{}}_clone(t){if(t===null||typeof t!="object")return t;if(Array.isArray(t))return t.map(i=>this._clone(i));let e={};return Object.keys(t).forEach(i=>{e[i]=this._clone(t[i])}),e}_createClipboardBucket(){return{full:null,appearance:null,rules:null,actions:null}}_defaultSeparator(){return{color:"#d0d7de",background:"",style:"solid",thickness:1,length:"100%",align:"stretch",opacity:1,margin_top:0,margin_bottom:0}}_firstNonSeparatorRowIndex(){let t=this.config?.rows||[];for(let e=0;e<t.length;e+=1)if((t[e]?.type||"")!=="separator")return e;return-1}_isHeaderRowIndex(t){if(!this.config?.header_from_first_row)return!1;let e=this._firstNonSeparatorRowIndex();return e!==-1&&t===e}_displayRowNumber(t){let e=this.config?.rows||[],i=0;for(let s=0;s<=t;s+=1)(e[s]?.type||"")!=="separator"&&(i+=1);return i}setConfig(t){let e=(()=>{if(!Array.isArray(t.rows))return 1;for(let u of t.rows)if(Array.isArray(u?.cells)&&u.cells.length)return u.cells.length;return 1})(),i=Number.isInteger(t.column_count)&&t.column_count>0?t.column_count:e,n={...{top:4,right:0,bottom:4,left:0},...t.cell_padding||{}},r=(t.rows||[]).map(u=>this._ensureCells(u,i));if(!Array.isArray(this._fullCells)||this._fullCells.length===0)this._fullCells=r.map(u=>u.cells.map(h=>this._clone(h)));else{let u=r.length,h=this._fullCells.length;if(u>h)for(let p=h;p<u;p++)this._fullCells.push((r[p]?.cells||[]).map(b=>this._clone(b)));else u<h&&(this._fullCells.length=u);for(let p=0;p<u;p++){let b=r[p]?.cells||[],$=Array.isArray(this._fullCells[p])?this._fullCells[p]:[],y=Math.max($.length,b.length),E=new Array(y);for(let A=0;A<y;A++)E[A]=$[A]||b[A]&&this._clone(b[A])||void 0;this._fullCells[p]=E}}let a={};r.forEach((u,h)=>a[h]=Math.min(this._activeTabs[h]||0,i-1));let o=this._collapsed;(!Array.isArray(o)||o.length!==r.length)&&(o=Array.from({length:r.length},()=>!0));let l=!!t.custom_template_enabled,c=typeof t.custom_template_html=="string"?t.custom_template_html:"";this.config={...this.config,...t,column_count:i,rows:r,cell_padding:n,custom_template_enabled:l,custom_template_html:c},this._activeTabs=a,this._collapsed=o}getConfig(){return this.config}_fireConfigChanged(){this.dispatchEvent(new CustomEvent("config-changed",{detail:{config:this.config},bubbles:!0,composed:!0}))}_ensureCells(t,e){if((t?.type||"")==="separator"){let s=this._defaultSeparator();return{...t,type:"separator",separator:{...s,...t?.separator||{}},cells:[]}}let i=Array.isArray(t?.cells)?[...t.cells]:[];for(let s=i.length;s<e;s++)i.push({type:"string",value:"",align:"right"});i.length>e&&(i.length=e);for(let s=0;s<i.length;s++){let n=i[s]||{};n.align||(n.align="right"),n.type==="entity"&&n.use_entity_unit===void 0&&(n.use_entity_unit=!0),i[s]=n}return{...t,cells:i}}_upd(t,e){this.config={...this.config,[t]:e},this._fireConfigChanged()}_toggle(t,e){this._upd(t,!!e.target.checked)}_parseCsvList(t){return t.split(",").map(e=>e.trim()).filter(Boolean)}_parseCsvIntList(t){return t.split(",").map(e=>parseInt(e.trim())).filter(e=>Number.isInteger(e)&&e>0)}_inputNumberAllowEmpty(t,e){let i=(e.target.value??"").trim();if(i===""){this._upd(t,"");return}let s=parseInt(i,10);Number.isFinite(s)&&this._upd(t,s)}_updateTextSize(t){let e=(t.target.value||"").trim();this._upd("text_size",e||"")}_updateCardPadding(t){this._inputNumberAllowEmpty("card_padding",t)}_toggleCustomTemplate(t){this.config={...this.config,custom_template_enabled:!!t.target.checked},this._fireConfigChanged()}_updateCustomTemplateHtml(t){let e=t.target?.value??"";this.config={...this.config,custom_template_html:e},this._fireConfigChanged()}_updateColumnCount(t){let e=parseInt(t.target.value,10);if(!Number.isInteger(e)||e<1)return;let s=(this.config.rows||[]).map(r=>this._ensureCells(r,e)).map((r,a)=>{let o=this._fullCells?.[a]||[],l=r.cells.slice(0,e);for(let c=0;c<e;c++)o[c]&&(l[c]=this._clone(o[c]));return{...r,cells:l}}),n={};s.forEach((r,a)=>n[a]=Math.min(this._activeTabs[a]||0,e-1)),this.config={...this.config,column_count:e,rows:s},this._activeTabs=n,this._fireConfigChanged()}_updateCellPadding(t,e){let i=(e.target.value??"").trim(),s={...this.config.cell_padding||{}};if(i==="")s[t]=t==="top"||t==="bottom"?4:0;else{let n=parseInt(i,10);Number.isFinite(n)&&(s[t]=n)}this._upd("cell_padding",s)}_updateBreakpoint(t){this._inputNumberAllowEmpty("narrow_breakpoint",t)}__mapIndexAfterMove(t,e,i){return e===i?t:i>e?t===e?i:t>e&&t<=i?t-1:t:t===e?i:t>=i&&t<e?t+1:t}__reorderColumn(t,e){let i=this.config.column_count||1;if(t===null||e===null||t<0||e<0||t>=i||e>=i||t===e)return;let s=(this.config.rows||[]).map(o=>{let l=[...o.cells||[]],[c]=l.splice(t,1);return l.splice(e,0,c),{...o,cells:l}});Array.isArray(this._fullCells)&&this._fullCells.length===s.length&&(this._fullCells=this._fullCells.map(o=>{let l=[...o],[c]=l.splice(t,1);return l.splice(e,0,c),l}));let n=this.config.column_widths;if(Array.isArray(n)&&n.length){n=[...n];let[o]=n.splice(t,1);n.splice(e,0,o)}let r=this.config.hide_on_narrow;Array.isArray(r)&&r.length&&(r=r.map(o=>this.__mapIndexAfterMove(o-1,t,e)+1).filter((o,l,c)=>c.indexOf(o)===l).sort((o,l)=>o-l));let a={};s.forEach((o,l)=>{let c=this._activeTabs[l]||0;a[l]=this.__mapIndexAfterMove(c,t,e)}),this.config={...this.config,rows:s,column_widths:n,hide_on_narrow:r},this._activeTabs=a,this._fireConfigChanged()}_moveColumn(t,e){this.__reorderColumn(t,t+e)}_deleteColumn(t){let e=this.config.column_count||1;if(e<=1)return;let i=e-1,s=(this.config.rows||[]).map(o=>{let l=[...o.cells];for(l.splice(t,1);l.length<i;)l.push({type:"string",value:"",align:"right"});return{...o,cells:l}});Array.isArray(this._fullCells)&&this._fullCells.length===s.length&&(this._fullCells=this._fullCells.map(o=>{let l=[...o];return l.splice(t,1),l}));let n=this.config.column_widths;Array.isArray(n)&&n.length&&(n=[...n],n.splice(t,1));let r=this.config.hide_on_narrow;Array.isArray(r)&&r.length&&(r=r.filter(o=>o!==t+1).map(o=>o>t+1?o-1:o).filter((o,l,c)=>c.indexOf(o)===l).sort((o,l)=>o-l));let a={};s.forEach((o,l)=>{let c=this._activeTabs[l]||0;a[l]=Math.min(c,i-1)}),this.config={...this.config,rows:s,column_count:i,column_widths:n,hide_on_narrow:r},this._activeTabs=a,this._fireConfigChanged()}_onColDragStart(t,e){this._colDragFrom=t,this._colDragOver=t,this._colDragActive=!0;try{e.dataTransfer.effectAllowed="move",e.dataTransfer.setData("text/plain",String(t))}catch{}this.requestUpdate()}_onColDragOver(t,e){e.preventDefault(),this._colDragOver=t,this.requestUpdate(),this._autoScrollColstrip(e.clientX)}_onColDragLeave(t,e){this._colDragOver===t&&(this._colDragOver=null,this.requestUpdate())}_onColDrop(t,e){e.preventDefault(),this.__reorderColumn(this._colDragFrom,t),this._colDragFrom=null,this._colDragActive=!1,this._colDragOver=null}_onColDragEnd(){this._colDragFrom=null,this._colDragActive=!1,this._colDragOver=null}_onColPointerDown(t,e){if(!(e.pointerType!=="touch"&&e.pointerType!=="pen")){e.preventDefault(),e.stopPropagation(),this._colDragFrom=t,this._colDragOver=t,this._colDragActive=!0;try{e.currentTarget.setPointerCapture(e.pointerId)}catch{}window.addEventListener("pointermove",this._boundPointerMove,{passive:!1}),window.addEventListener("pointerup",this._boundPointerUp,{passive:!1}),this.requestUpdate()}}_onColPointerMove(t){if(!this._colDragActive)return;t.preventDefault();let e=Array.from(this.renderRoot.querySelectorAll(".colstrip .colchip")),i=t.clientX,s=t.clientY,n=null;for(let r=0;r<e.length;r++){let a=e[r].getBoundingClientRect();if(i>=a.left&&i<=a.right&&s>=a.top&&s<=a.bottom){n=r;break}}this._colDragOver=n,this.requestUpdate(),this._autoScrollColstrip(t.clientX)}_onColPointerUp(t){this._colDragActive&&this._colDragFrom!==null&&this._colDragOver!==null&&this.__reorderColumn(this._colDragFrom,this._colDragOver);try{t.currentTarget?.releasePointerCapture?.(t.pointerId)}catch{}this._colDragFrom=null,this._colDragActive=!1,this._colDragOver=null,window.removeEventListener("pointermove",this._boundPointerMove),window.removeEventListener("pointerup",this._boundPointerUp)}_autoScrollColstrip(t){let e=this.renderRoot.querySelector(".colstrip");if(!e)return;let i=e.getBoundingClientRect(),s=24;t<i.left+s?e.scrollLeft-=16:t>i.right-s&&(e.scrollLeft+=16)}__reorderRows(t,e){if(t===null||e===null||t===e)return;let i=[...this.config.rows||[]],s=Array.from(this._collapsed||[]),n=i.map((o,l)=>this._activeTabs[l]||0),r=(o,l,c)=>{let u=o.splice(l,1)[0];o.splice(c,0,u)};r(i,t,e),r(s,t,e),r(n,t,e),Array.isArray(this._fullCells)&&this._fullCells.length&&((l,c,u)=>{let h=l.splice(c,1)[0];l.splice(u,0,h)})(this._fullCells,t,e);let a={};i.forEach((o,l)=>a[l]=Math.min(n[l],(this.config.column_count||1)-1)),this.config={...this.config,rows:i},this._collapsed=s,this._activeTabs=a,this._fireConfigChanged()}_onDragStart(t,e){this._dragIndex=t,this._dragOverIndex=t,e.dataTransfer.effectAllowed="move";try{e.dataTransfer.setData("text/plain",String(t))}catch{}this.requestUpdate()}_onDragOver(t,e){e.preventDefault(),e.dataTransfer.dropEffect="move",this._dragOverIndex=t,this.requestUpdate()}_onDragLeave(t,e){this._dragOverIndex===t&&(this._dragOverIndex=null,this.requestUpdate())}_onDrop(t,e){e.preventDefault(),this.__reorderRows(this._dragIndex,t),this._dragIndex=null,this._dragOverIndex=null,this.requestUpdate()}_onDragEnd(){this._dragIndex=null,this._dragOverIndex=null,this.requestUpdate()}_onRowPointerDown(t,e){if(!(e.pointerType!=="touch"&&e.pointerType!=="pen")){e.preventDefault(),e.stopPropagation(),this._rowDragFrom=t,this._rowDragActive=!0,this._dragOverIndex=t;try{e.currentTarget.setPointerCapture(e.pointerId)}catch{}window.addEventListener("pointermove",this._boundRowPointerMove,{passive:!1}),window.addEventListener("pointerup",this._boundRowPointerUp,{passive:!1}),this.requestUpdate()}}_onRowPointerMove(t){if(!this._rowDragActive)return;t.preventDefault();let e=Array.from(this.renderRoot.querySelectorAll(".rowbox")),i=t.clientX,s=t.clientY,n=null;for(let r=0;r<e.length;r++){let a=e[r].getBoundingClientRect();if(i>=a.left&&i<=a.right&&s>=a.top&&s<=a.bottom){n=r;break}}this._dragOverIndex=n,this.requestUpdate()}_onRowPointerUp(t){this._rowDragActive&&this._rowDragFrom!==null&&this._dragOverIndex!==null&&this.__reorderRows(this._rowDragFrom,this._dragOverIndex);try{t.currentTarget?.releasePointerCapture?.(t.pointerId)}catch{}this._rowDragFrom=null,this._rowDragActive=!1,this._dragOverIndex=null,window.removeEventListener("pointermove",this._boundRowPointerMove),window.removeEventListener("pointerup",this._boundRowPointerUp),this.requestUpdate()}_patchRow(t,e,i=[]){let s=Array.isArray(this.config.rows)?[...this.config.rows]:[];if(t<0||t>=s.length)return;let r={...{...s[t]||{}},...e};i.forEach(a=>{r[a]===void 0&&delete r[a]}),s[t]=r,this.config={...this.config,rows:s},this._fireConfigChanged()}_patchCell(t,e,i){let s=[...this.config.rows],n={...s[t]},r=[...n.cells],o={...{...r[e]||{}},...i};if(r[e]=o,s[t]={...n,cells:r},this.config={...this.config,rows:s},this._fireConfigChanged(),Array.isArray(this._fullCells)&&this._fullCells[t]){let l=[...this._fullCells[t]];if(e>=l.length)for(let c=l.length;c<=e;c++)l[c]={type:"string",value:"",align:"right"};l[e]=this._clone(o),this._fullCells[t]=l}}_patchCellStyle(t,e,i){let s=[...this.config.rows],n={...s[t]},r=[...n.cells],a={...r[e]||{}},o={...a.style||{},...i},l={...a,style:o};if(r[e]=l,s[t]={...n,cells:r},this.config={...this.config,rows:s},this._fireConfigChanged(),Array.isArray(this._fullCells)&&this._fullCells[t]){let c=[...this._fullCells[t]];if(e>=c.length)for(let u=c.length;u<=e;u++)c[u]={type:"string",value:"",align:"right"};c[e]=this._clone(l),this._fullCells[t]=c}}_cellTypeChanged(t,e,i){let s=i.target.value,n={type:s};s==="icon"&&!this.config.rows?.[t]?.cells?.[e]?.value&&(n.value="mdi:information-outline"),s!=="entity"?(n.use_entity_unit=void 0,n.unit=void 0,n.precision=void 0,n.entity_display=void 0):this.config.rows?.[t]?.cells?.[e]?.use_entity_unit===void 0&&(n.use_entity_unit=!0),this._patchCell(t,e,n)}_cellValueChanged(t,e,i){this._patchCell(t,e,{value:i.target.value})}_cellAlignChanged(t,e,i){let s=i?.detail?.value??i?.target?.value;this._patchCell(t,e,{align:s})}_cellUseEntityUnitChanged(t,e,i){let s=!!i.target.checked,n={use_entity_unit:s};s&&this.config?.rows?.[t]?.cells?.[e]?.attribute&&(n.unit=void 0),this._patchCell(t,e,n)}_cellUnitChanged(t,e,i){this._patchCell(t,e,{unit:i.target.value})}_cellAttributeChanged(t,e,i){let n=(i&&i.target&&typeof i.target.value=="string"?i.target.value:"").trim();this._patchCell(t,e,{attribute:n||void 0})}_cellEntityDisplayChanged(t,e,i){let s=i?.detail?.value??i?.target?.value,n=typeof s=="string"&&s.trim()?s.trim():"value",r=n==="value"?void 0:n;this._patchCell(t,e,{entity_display:r})}_cellPrecisionChanged(t,e,i){let s=i?.detail?.value??i?.target?.value,n=s===""?void 0:parseInt(s);this._patchCell(t,e,{precision:n})}_cellScaleChanged(t,e,i,s){let n=(s.target.value??"").trim(),r=n===""?void 0:Number(String(n).replace(",","."));(r===void 0||Number.isFinite(r))&&this._patchCell(t,e,{[i]:r})}_getAttrEditConfig(t){let e=t?.attr_edit&&typeof t.attr_edit=="object"?t.attr_edit:{},i=typeof e.control=="string"?e.control.trim().toLowerCase():"slider",s=i==="switch"?"switch":["color","color-slider","color_hs"].includes(i)?"color":["color_sat","color-sat","color_saturation"].includes(i)?"color_sat":"slider",n=Number(e.min),r=Number(e.max),a=Number(e.step),o=s==="color"||s==="color_sat"?"hs_color":"",l=typeof e.field=="string"?e.field:t?.attribute||o,c=Number(e.sat_fallback);return{enabled:e.enabled===!0,service:typeof e.service=="string"?e.service:"",field:s==="color"||s==="color_sat"?this._stripIndexFromPath(l)||"hs_color":l,control:s,min:s==="color"?void 0:Number.isFinite(n)?n:void 0,max:s==="color"?void 0:Number.isFinite(r)?r:void 0,step:s==="color"?void 0:Number.isFinite(a)&&a>0?a:void 0,checked:e.checked!==void 0?e.checked:!0,unchecked:e.unchecked!==void 0?e.unchecked:!1,hue_path:typeof e.hue_path=="string"?e.hue_path:"",sat_path:typeof e.sat_path=="string"?e.sat_path:"",sat_fallback:Number.isFinite(c)?c:void 0}}_patchAttrEdit(t,e,i){let s=this.config?.rows?.[t]?.cells?.[e]||{},r={...this._getAttrEditConfig(s),...i||{}};this._patchCell(t,e,{attr_edit:r})}_stripIndexFromPath(t){if(typeof t!="string")return"";let e=t.trim();return e?e.replace(/(\.|\[)\d+(\])?$/,""):""}_toggleAttrEditEnabled(t,e,i){let s=!!i?.target?.checked;this._patchAttrEdit(t,e,{enabled:s})}_updateAttrEditText(t,e,i,s){let n=s?.detail?.value??s?.target?.value??"",r=(typeof n=="string"?n:String(n)).trim();this._patchAttrEdit(t,e,{[i]:r})}_updateAttrEditNumber(t,e,i,s){let n=(s?.target?.value??"").trim();if(n===""){let a={...this._getAttrEditConfig(this.config?.rows?.[t]?.cells?.[e])};delete a[i],this._patchCell(t,e,{attr_edit:a});return}let r=Number(String(n).replace(",","."));Number.isFinite(r)&&this._patchAttrEdit(t,e,{[i]:r})}_updateAttrEditLiteral(t,e,i,s){let n=(s?.target?.value??"").trim();if(!n){this._patchAttrEdit(t,e,{[i]:""});return}if(/^(true|false)$/i.test(n)){this._patchAttrEdit(t,e,{[i]:n.toLowerCase()==="true"});return}let r=Number(n);if(Number.isFinite(r)){this._patchAttrEdit(t,e,{[i]:r});return}this._patchAttrEdit(t,e,{[i]:n})}_isEntityNumeric(t){let e=t?.value,i=this._getStateObject(e);if(!i)return!1;let s=t?.attribute?this._resolveEntityValue(i,t.attribute):i.state,n=Number(s);return Number.isFinite(n)}_styleToggle(t,e,i,s){this._patchCellStyle(t,e,{[i]:!!s.target.checked})}_styleValue(t,e,i,s){let n=s?.detail?.value??s?.target?.value;this._patchCellStyle(t,e,{[i]:n})}_ruleTitle(t){return(this.hass?.locale?.language||"en").toLowerCase().startsWith("pl")?`Regu\u0142a ${t+1}`:`Rule ${t+1}`}_normalizeRuleConditions(t){let e={entity:t?.entity||"",attr:t?.attr||"",op:t?.op||"=",val:t?.val??"",val2:t?.val2??"",src:t?.src};return!t||typeof t!="object"?[e]:(Array.isArray(t.conditions)&&t.conditions.length?t.conditions:[e]).map(s=>({entity:s?.entity||"",attr:s?.attr||"",op:s?.op||"=",val:s?.val??"",val2:s?.val2??"",src:s?.src}))}_normalizeRuleMatch(t){let e=(t?.match||t?.condition_match||"").toLowerCase();return e==="any"||e==="or"?"any":"all"}_getCellRules(t,e){try{return(Array.isArray(this.config?.rows?.[t]?.cells?.[e]?.dyn_color)?[...this.config.rows[t].cells[e].dyn_color]:[]).map(s=>({...s,conditions:this._normalizeRuleConditions(s),match:this._normalizeRuleMatch(s)}))}catch{return[]}}_setCellRules(t,e,i){let s=[...this.config.rows||[]],n={...s[t]},r=[...n.cells||[]],a={...r[e],dyn_color:i};if(r[e]=a,s[t]={...n,cells:r},this.config={...this.config,rows:s},Array.isArray(this._fullCells)&&this._fullCells[t]){let o=[...this._fullCells[t]];if(e>=o.length)for(let l=o.length;l<=e;l+=1)o[l]={type:"string",value:"",align:"right"};o[e]=this._clone(a),this._fullCells[t]=o}this._fireConfigChanged()}_addRule(t,e){let i=this._getCellRules(t,e);i.push({conditions:[{entity:"",attr:"",op:"=",val:"",val2:""}],match:"all",bg:"",fg:"",overwrite:"",overwrite_entity:"",overwrite_attr:""}),this._setCellRules(t,e,i)}_removeRule(t,e,i){let s=this._getCellRules(t,e);s.splice(i,1),this._setCellRules(t,e,s)}_addCondition(t,e,i){let s=this._getCellRules(t,e);if(!s[i])return;let n=this._normalizeRuleConditions(s[i]);n.push({entity:s[i].entity||"",attr:"",op:"=",val:"",val2:""}),s[i]={...s[i]||{},conditions:n},this._setCellRules(t,e,s)}_removeCondition(t,e,i,s){let n=this._getCellRules(t,e);if(!n[i])return;let r=this._normalizeRuleConditions(n[i]);r.length<=1||(r.splice(s,1),n[i]={...n[i]||{},conditions:r},this._setCellRules(t,e,n))}_updateCondition(t,e,i,s,n){let r=this._getCellRules(t,e);if(!r[i])return;let a=this._normalizeRuleConditions(r[i]);a[s]={...a[s]||{},...n||{}},r[i]={...r[i]||{},conditions:a},this._setCellRules(t,e,r)}_updateRule(t,e,i,s){let n=this._getCellRules(t,e);n[i]={...n[i]||{},...s||{}},this._setCellRules(t,e,n)}_updateRuleEntityDisplay(t,e,i,s){let n=s?.detail?.value??s?.target?.value,r=typeof n=="string"&&n.trim()?n.trim():"value",a=r==="value"?void 0:r;this._updateRule(t,e,i,{overwrite_entity_display:a})}_updateRuleScale(t,e,i,s,n){let r=(n?.target?.value??"").trim(),a=r===""?void 0:Number(String(r).replace(",","."));(a===void 0||Number.isFinite(a))&&this._updateRule(t,e,i,{[s]:a})}_getRowRules(t){try{return(Array.isArray(this.config?.rows?.[t]?.dyn_row_rules)?[...this.config.rows[t].dyn_row_rules]:[]).map(i=>({...i,conditions:this._normalizeRuleConditions(i),match:this._normalizeRuleMatch(i)}))}catch{return[]}}_setRowRules(t,e){let i=[...this.config.rows||[]];i[t]&&(i[t]={...i[t],dyn_row_rules:e},this.config={...this.config,rows:i},this._fireConfigChanged())}_addRowRule(t){let e=this._getRowRules(t);e.push({conditions:[{entity:"",attr:"",op:"=",val:"",val2:""}],match:"all",bg:"",fg:""}),this._setRowRules(t,e)}_removeRowRule(t,e){let i=this._getRowRules(t);e<0||e>=i.length||(i.splice(e,1),this._setRowRules(t,i))}_addRowCondition(t,e){let i=this._getRowRules(t);if(!i[e])return;let s=this._normalizeRuleConditions(i[e]);s.push({entity:i[e].entity||"",attr:"",op:"=",val:"",val2:""}),i[e]={...i[e]||{},conditions:s},this._setRowRules(t,i)}_removeRowCondition(t,e,i){let s=this._getRowRules(t);if(!s[e])return;let n=this._normalizeRuleConditions(s[e]);n.length<=1||(n.splice(i,1),s[e]={...s[e]||{},conditions:n},this._setRowRules(t,s))}_updateRowCondition(t,e,i,s){let n=this._getRowRules(t);if(!n[e])return;let r=this._normalizeRuleConditions(n[e]);r[i]={...r[i]||{},...s||{}},n[e]={...n[e]||{},conditions:r},this._setRowRules(t,n)}_updateRowRule(t,e,i){let s=this._getRowRules(t);if(e<0||e>=s.length)return;let n={...s[e]||{},...i||{}};n.visibility===void 0&&delete n.visibility,s[e]=n,this._setRowRules(t,s)}_setActiveTab(t,e){this._activeTabs={...this._activeTabs,[t]:e},this.requestUpdate()}_resolveActiveCell(t){let e=this.config.rows?.[t];if(!e||(e?.type||"")==="separator")return null;let i=this.config.column_count||1,n=!!e.merge_columns?0:Math.min(this._activeTabs[t]||0,i-1),r=e.cells?.[n];return{row:e,index:n,cell:r}}_extractCellAppearance(t){return t?{align:t.align,use_entity_unit:t.use_entity_unit,unit:t.unit,precision:t.precision,custom_css_enabled:t.custom_css_enabled,custom_css:t.custom_css,style:t.style?this._clone(t.style):void 0}:null}_applyCellAppearance(t,e,i){if(!i||t===null||t===void 0||e===null||e===void 0)return;let s=r=>Object.prototype.hasOwnProperty.call(i,r),n={};s("align")&&(n.align=i.align),s("use_entity_unit")&&(n.use_entity_unit=i.use_entity_unit),s("unit")&&(n.unit=i.unit),s("precision")&&(n.precision=i.precision),s("custom_css_enabled")&&(n.custom_css_enabled=i.custom_css_enabled),s("custom_css")&&(n.custom_css=i.custom_css),s("style")&&(n.style=i.style?this._clone(i.style):i.style),this._patchCell(t,e,n)}_extractCellActions(t){if(!t)return null;let e=i=>i&&typeof i=="object"?this._clone(i):void 0;return{tap_action:e(t.tap_action),hold_action:e(t.hold_action),double_tap_action:e(t.double_tap_action)}}_applyCellActions(t,e,i){if(!i||t===null||t===void 0||e===null||e===void 0)return;let s={},n=r=>{Object.prototype.hasOwnProperty.call(i,r)&&(s[r]=i[r]?this._clone(i[r]):void 0)};n("tap_action"),n("hold_action"),n("double_tap_action"),this._patchCell(t,e,s)}_clipboardSummary(t){if(!t)return"";let e=[];if(t.full&&e.push("full"),t.appearance&&e.push("appearance"),t.rules&&e.push("rules"),t.actions&&e.push("actions"),!e.length)return d(this.hass,"editor.clipboard_empty");let i=s=>d(this.hass,`editor.clipboard_scope_${s}`);return e.map(s=>i(s)).join(", ")}_copyActiveCell(t){let e=this._resolveActiveCell(t);e?.cell&&(this._clipboardCell.full=this._clone(e.cell),this.requestUpdate())}_copyCellAppearance(t){let e=this._resolveActiveCell(t);e?.cell&&(this._clipboardCell.appearance=this._extractCellAppearance(e.cell),this.requestUpdate())}_copyCellRules(t){let e=this._resolveActiveCell(t);if(!e)return;let i=this._getCellRules(t,e.index);this._clipboardCell.rules=this._clone(i),this.requestUpdate()}_copyCellActions(t){let e=this._resolveActiveCell(t);e?.cell&&(this._clipboardCell.actions=this._extractCellActions(e.cell),this.requestUpdate())}_assignFullCell(t,e,i){if(!i||t===null||t===void 0||e===null||e===void 0)return;let s=Array.isArray(this.config.rows)?[...this.config.rows]:[];if(!s[t]||(s[t]?.type||"")==="separator")return;let n={...s[t]||{}},r=Array.isArray(n.cells)?[...n.cells]:[],a=this._clone(i);r[e]=a,n.cells=r,s[t]=n,this.config={...this.config,rows:s},this._fireConfigChanged(),Array.isArray(this._fullCells)||(this._fullCells=[]),Array.isArray(this._fullCells[t])||(this._fullCells[t]=[]);let o=[...this._fullCells[t]];if(e>=o.length)for(let l=o.length;l<=e;l+=1)o[l]={type:"string",value:"",align:"right"};o[e]=this._clone(a),this._fullCells[t]=o}_applyClipboardCellScope(t,e,i="full"){if(t==null||e===null||e===void 0)return;let s=i==="full"?"full":i,n=this._clipboardCell?.[s];if(n){if(i==="appearance"){this._applyCellAppearance(t,e,n);return}if(i==="rules"){this._setCellRules(t,e,this._clone(n));return}if(i==="actions"){this._applyCellActions(t,e,n);return}this._assignFullCell(t,e,n)}}_pasteToActiveCell(t,e="full"){let i=this._resolveActiveCell(t);i&&this._applyClipboardCellScope(t,i.index,e)}_pasteCellAppearance(t){this._pasteToActiveCell(t,"appearance")}_pasteCellRules(t){this._pasteToActiveCell(t,"rules")}_pasteCellActions(t){this._pasteToActiveCell(t,"actions")}_applyClipboardCellBulk(t,e,i="full"){let s=i==="full"?"full":i;if(!this._clipboardCell?.[s])return;if(e==="column"){let o=this._resolveActiveCell(t);if(!o)return;let l=o.index;(this.config.rows||[]).forEach((c,u)=>{!c||(c.type||"")==="separator"||c.merge_columns&&l>0||this._applyClipboardCellScope(u,l,i)});return}let n=this.config.rows?.[t];if(!n||(n.type||"")==="separator")return;let r=Array.isArray(n.cells)?n.cells.length:0,a=n.merge_columns?1:Math.max(this.config.column_count||1,r||1);for(let o=0;o<a;o+=1)this._applyClipboardCellScope(t,o,i)}_copyRow(t){let e=this.config.rows?.[t];!e||(e?.type||"")==="separator"||(this._clipboardRow.full=this._clone(e),this.requestUpdate())}_pasteRow(t){let e=this._clipboardRow?.full;if(!e)return;let i=[...this.config.rows||[]];if(!i[t]||(i[t]?.type||"")==="separator")return;let s=this._ensureCells(this._clone(e),this.config.column_count||1);i[t]=s,this.config={...this.config,rows:i},Array.isArray(this._fullCells)||(this._fullCells=[]),this._fullCells[t]=s.cells.map(n=>this._clone(n)),this._fireConfigChanged()}_copyRowAppearance(t){let e=this.config.rows?.[t];!e||(e?.type||"")==="separator"||(this._clipboardRow.appearance={custom_css_enabled:e.custom_css_enabled,custom_css:e.custom_css},this.requestUpdate())}_pasteRowAppearance(t){let e=this._clipboardRow?.appearance;if(!e)return;let i={},s=n=>Object.prototype.hasOwnProperty.call(e,n);s("custom_css_enabled")&&(i.custom_css_enabled=e.custom_css_enabled),s("custom_css")&&(i.custom_css=e.custom_css),this._patchRow(t,i)}_copyRowRules(t){let e=this.config.rows?.[t];if(!e||(e?.type||"")==="separator")return;let i=this._getRowRules(t);this._clipboardRow.rules=this._clone(i),this.requestUpdate()}_pasteRowRules(t){let e=this._clipboardRow?.rules;e&&this._setRowRules(t,this._clone(e))}_toggleMergeColumns(t,e){let i=!!e.target.checked;this._patchRow(t,i?{merge_columns:!0}:{merge_columns:void 0},["merge_columns"])}_toggleCollapse(t){let e=Array.from(this._collapsed||[]);e[t]=!e[t],this._collapsed=e,this.requestUpdate()}_moveRow(t,e){let i=t+e;i<0||i>=(this.config.rows||[]).length||this.__reorderRows(t,i)}_rowPreview(t){if((t?.type||"")==="separator")return g``;let e=Array.isArray(t?.cells)?t.cells:[],i=[],s=0;for(let n of e)if(!(!n||!n.value)){if(n.type==="icon"){i.push(g`<ha-icon
          .icon=${n.value}
          style="--mdc-icon-size:18px; margin-right:6px;"
        ></ha-icon>`);continue}if(n.type==="string"){let r=String(n.value);if(!r)continue;s>0&&i.push(g`<span> • </span>`),i.push(g`<span>${r}</span>`),s++;continue}if(n.type==="entity"){let a=this.hass?.states?.[n.value]?.attributes?.friendly_name||n.value;if(!a)continue;s>0&&i.push(g`<span> • </span>`),i.push(g`<span>${a}</span>`),s++;continue}}return i.length?g`${i}`:g`—`}_separatorColorValue(t){let e=(t||"").trim();return/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(e)?e:"#d0d7de"}_renderSeparatorEditor(t,e){let i=this._defaultSeparator(),s={...i,...t?.separator||{}};return g`
      <div class="rowbody">
        <div class="cell-grid cell-wide">
          <div class="inline">
            <ha-textfield
              .label=${d(this.hass,"editor.separator_color")}
              .value=${s.color??""}
              .placeholder=${"#d0d7de | var(--divider-color)"}
              @input=${n=>this._updateSeparator(e,{color:(n.target.value||"").trim()||i.color})}>
            </ha-textfield>
            <button type="button" class="toggle" title=${d(this.hass,"editor.separator_color_picker")} @click=${n=>this._onSeparatorPaletteClick(n,e,"color")}>
              <ha-icon icon="mdi:palette"></ha-icon>
            </button>
          </div>
        </div>

        <div class="cell-grid cell-wide">
          <div class="inline">
            <ha-textfield
              .label=${d(this.hass,"editor.separator_background")}
              .value=${s.background??""}
              .placeholder=${"transparent | #f0f0f0 | var(--color)"}
              @input=${n=>this._updateSeparator(e,{background:(n.target.value||"").trim()||void 0})}>
            </ha-textfield>
            <button type="button" class="toggle" title=${d(this.hass,"editor.separator_color_picker")} @click=${n=>this._onSeparatorPaletteClick(n,e,"background")}>
              <ha-icon icon="mdi:palette"></ha-icon>
            </button>
          </div>
        </div>

        <div class="cols2">
          <div>
            <ha-select
              style="width:100%;"
              .label=${d(this.hass,"editor.separator_style")}
              .value=${s.style||i.style}
              naturalMenuWidth
              fixedMenuPosition
              .options=${[{value:"solid",label:d(this.hass,"editor.separator_style_solid")},{value:"dashed",label:d(this.hass,"editor.separator_style_dashed")},{value:"dotted",label:d(this.hass,"editor.separator_style_dotted")}]}
              @selected=${n=>this._updateSeparator(e,{style:n.detail?.value||n.target?.value||i.style})}
              @closed=${n=>n.stopPropagation()}>
            </ha-select>
          </div>
          <div>
            <ha-textfield
              style="width:100%;"
              .label=${d(this.hass,"editor.separator_thickness")}
              type="number"
              min="0"
              step="0.1"
              .value=${String(s.thickness??"")}
              @input=${n=>this._separatorNumberChanged(e,"thickness",n,{float:!0,min:0})}>
            </ha-textfield>
          </div>
        </div>

        <div class="cols2">
          <div>
            <ha-textfield
              style="width:100%;"
              .label=${d(this.hass,"editor.separator_length")}
              .value=${s.length??""}
              .placeholder=${"100% | 80% | 240px"}
              @input=${n=>this._updateSeparator(e,{length:(n.target.value||"").trim()||i.length})}>
            </ha-textfield>
          </div>
          <div>
            <ha-select
              style="width:100%;"
              .label=${d(this.hass,"editor.separator_align")}
              .value=${s.align||i.align}
              naturalMenuWidth
              fixedMenuPosition
              .options=${[{value:"stretch",label:d(this.hass,"editor.separator_align_full")},{value:"center",label:d(this.hass,"editor.separator_align_center")},{value:"left",label:d(this.hass,"editor.separator_align_left")},{value:"right",label:d(this.hass,"editor.separator_align_right")}]}
              @selected=${n=>this._updateSeparator(e,{align:n.detail?.value||n.target?.value||i.align})}
              @closed=${n=>n.stopPropagation()}>
            </ha-select>
          </div>
        </div>

        <div class="cols2">
          <div>
            <ha-textfield
              style="width:100%;"
              .label=${d(this.hass,"editor.separator_margin_top")}
              type="number"
              step="1"
              .value=${String(s.margin_top??"")}
              @input=${n=>this._separatorNumberChanged(e,"margin_top",n,{float:!0})}>
            </ha-textfield>
          </div>
          <div>
            <ha-textfield
              style="width:100%;"
              .label=${d(this.hass,"editor.separator_margin_bottom")}
              type="number"
              step="1"
              .value=${String(s.margin_bottom??"")}
              @input=${n=>this._separatorNumberChanged(e,"margin_bottom",n,{float:!0})}>
            </ha-textfield>
          </div>
        </div>

        <div class="cell-grid cell-wide">
          <ha-textfield
            .label=${d(this.hass,"editor.separator_opacity")}
            type="number"
            min="0"
            max="1"
            step="0.05"
            .value=${String(s.opacity??"")}
            @input=${n=>this._separatorNumberChanged(e,"opacity",n,{float:!0,min:0,max:1})}>
          </ha-textfield>
        </div>
        <div class="muted" style="margin-top:10px;">${d(this.hass,"editor.separator_zero_hint")}</div>
      </div>
    `}_onSeparatorPaletteClick(t,e,i="color"){t?.preventDefault(),t?.stopPropagation();let s=this._defaultSeparator(),n=this.config?.rows?.[e],r=(i==="background"?s.background||s.color:s[i]??s.color)||s.color,a=n?.separator?.[i],o=this._separatorColorValue(a||r),l=t.currentTarget||t.target,c=l?.getBoundingClientRect?.(),u=c?c.right-8:24,h=c?c.bottom+8:24,p=document.body,b="fixed",$=this.closest?.("ha-dialog");if($?.shadowRoot){let k=$.shadowRoot.querySelector(".mdc-dialog__surface")||$;if(k){let P=k.getBoundingClientRect();u-=P.left,h-=P.top,p=k,b="absolute"}}let y=document.createElement("input");y.type="color",y.value=o,Object.assign(y.style,{position:b,left:`${Math.round(u)}px`,top:`${Math.round(h)}px`,transform:"translate(-10px,-10px)",width:"18px",height:"18px",opacity:"0.001",pointerEvents:"auto",border:"0",padding:"0",margin:"0",zIndex:"2147483647"});let E=l?.parentElement?.querySelector("ha-textfield")||null,A=null,_=0,v=()=>{if(A!=null){let k=A===s.color&&i==="background"&&!a?void 0:A;this._updateSeparator(e,{[i]:k}),A=null}_&&(clearTimeout(_),_=0)},w=()=>{v(),document.removeEventListener("pointerdown",S,!0),y.remove()},x=k=>{A=this._separatorColorValue(k.target.value||s.color),E&&(E.value=A,E.requestUpdate?.()),_||(_=window.setTimeout(()=>{_=0,v()},60))},M=k=>{A=this._separatorColorValue(k.target.value||s.color),v(),w()},V=()=>w(),D=k=>{k.key==="Escape"&&(k.preventDefault(),w())},S=k=>{k.target!==y&&w()};y.addEventListener("input",x),y.addEventListener("change",M,{once:!0}),y.addEventListener("blur",V,{once:!0}),y.addEventListener("keydown",D),p.appendChild(y),document.addEventListener("pointerdown",S,!0),requestAnimationFrame(()=>y.click())}_updateSeparator(t,e){let i=[...this.config.rows||[]];if(!i[t])return;let r={...{...this._defaultSeparator(),...i[t].separator||{}},...e||{}};if(Object.keys(r).forEach(a=>{r[a]===void 0&&delete r[a]}),i[t]={...i[t],type:"separator",separator:r,cells:[]},this.config={...this.config,rows:i},Array.isArray(this._fullCells)&&this._fullCells.length){let a=[...this._fullCells];a[t]=[],this._fullCells=a}this._fireConfigChanged()}_separatorNumberChanged(t,e,i,s={}){let n=(i?.target?.value??"").trim(),r=this._defaultSeparator();if(n===""){let c=r[e];this._updateSeparator(t,{[e]:c});return}let o=!!s.float?parseFloat(n):parseInt(n,10);if(!Number.isFinite(o))return;let l=o;s.min!==void 0&&l<s.min&&(l=s.min),s.max!==void 0&&l>s.max&&(l=s.max),this._updateSeparator(t,{[e]:l})}firstUpdated(){this._ensureEntityPickerLoaded(),this._ensureServicePickerLoaded()}_onEntityPicked(t,e,i){let s=i?.detail?.value??i?.target?.value??"";this._patchCell(t,e,{type:"entity",value:s})}_onTypeSelect(t,e,i){let s=i?.detail?.value??i?.target?.value;this._cellTypeChanged(t,e,{target:{value:s}})}_allowedUiActionsForCellType(t){if(t==="icon"||t==="string")return["navigate","url","assist","perform-action","none"]}_onActionsChanged(t,e,i){let s=i.detail?.value||{},n=this.config?.rows?.[t]?.cells?.[e]?.type,r=n==="icon"||n==="string",a=o=>{if(!o||!o.action)return;let l=JSON.parse(JSON.stringify(o));return l.action==="none"?{action:"none"}:r&&(l.action==="more-info"||l.action==="toggle")?{action:"none"}:(l.service||delete l.service,!l.data&&!l.service_data&&(delete l.data,delete l.service_data),l.target&&!Object.keys(l.target).length&&delete l.target,l.entity||delete l.entity,l)};this._patchCell(t,e,{tap_action:a(s.tap_action),hold_action:a(s.hold_action),double_tap_action:a(s.double_tap_action)})}_computeActionLabel=t=>{switch(t.name){case"tap_action":return d(this.hass,"editor.tap_action");case"hold_action":return d(this.hass,"editor.hold_action");case"double_tap_action":return d(this.hass,"editor.double_tap_action");default:return""}};_onPaletteClick(t,e,i,s="color"){let r=(this.config?.rows?.[e]?.cells?.[i]?.style||{})?.[s]||"#ffffff",a=z=>{let L=String(z||"").trim();if(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(L))return L.length===4?"#"+L.slice(1).split("").map(J=>J+J).join(""):L;let K=L.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);return K?"#"+[K[1],K[2],K[3]].map(J=>(+J).toString(16).padStart(2,"0")).join(""):"#ffffff"},l=(t?.currentTarget||t?.target)?.getBoundingClientRect?.(),c=typeof t?.clientX=="number"?t.clientX:l?l.right-8:24,u=typeof t?.clientY=="number"?t.clientY:l?l.bottom+8:24,h=this.closest?.("ha-dialog"),p=document.body,b="fixed";if(h?.shadowRoot){let z=h.shadowRoot.querySelector(".mdc-dialog__surface")||h.shadowRoot.querySelector(".mdc-dialog")||h.shadowRoot.querySelector(".mdc-dialog__container");if(z){let L=z.getBoundingClientRect();c-=L.left,u-=L.top,p=z,b="absolute"}}let $=document.createElement("input");$.type="color",$.value=a(r),$.tabIndex=-1,Object.assign($.style,{position:b,left:`${Math.round(c)}px`,top:`${Math.round(u)}px`,transform:"translate(-10px, -10px)",width:"18px",height:"18px",opacity:"0.001",pointerEvents:"auto",border:"0",padding:"0",margin:"0",zIndex:"2147483647"});let E=(h||document).querySelector?.("flex-cells-card")||null,A=`--fcc-cell-r${e}-c${i}-${s}`,_=0,v=null,w=z=>{v=z,_||(_=requestAnimationFrame(()=>{_=0,this._patchCellStyle(e,i,{[s]:v})}))},x=z=>{E?E.style.setProperty(A,z):w(z)},M=!1,V=!1,D=()=>{M||(M=!0,$.removeEventListener("input",S),$.removeEventListener("change",k),window.removeEventListener("keydown",P,!0),window.removeEventListener("pointerdown",j,!0),E&&E.style.removeProperty(A),$.remove())},S=z=>x(z.target.value),k=z=>{this._patchCellStyle(e,i,{[s]:z.target.value}),D()},P=z=>{z.key==="Escape"&&D()},j=z=>{V&&z.target!==$&&D()};$.addEventListener("input",S),$.addEventListener("change",k),window.addEventListener("keydown",P,!0),setTimeout(()=>{V=!0,window.addEventListener("pointerdown",j,!0)},250),p.appendChild($),$.offsetWidth;try{$.focus({preventScroll:!0})}catch{}requestAnimationFrame(()=>{try{typeof $.showPicker=="function"?$.showPicker():$.click()}catch{$.click()}}),setTimeout(()=>D(),6e4)}_onRuleColorPicker(t,e,i,s,n){t.stopPropagation();let r=Number.isInteger(i),o=(r?this._getCellRules?.(e,i)||this.config?.rows?.[e]?.cells?.[i]?.dyn_color||[]:this._getRowRules?.(e)||this.config?.rows?.[e]?.dyn_row_rules||[])?.[s]?.[n]||"#ff0000",l=t.currentTarget||t.target,c=l?.getBoundingClientRect?.(),u=c?c.right-8:24,h=c?c.bottom+8:24,p=document.body,b="fixed",$=this.closest?.("ha-dialog");if($?.shadowRoot){let D=$.shadowRoot.querySelector(".mdc-dialog__surface")||$;if(D){let S=D.getBoundingClientRect();u-=S.left,h-=S.top,p=D,b="absolute"}}let y=document.createElement("input");y.type="color",y.value=o,Object.assign(y.style,{position:b,left:`${Math.round(u)}px`,top:`${Math.round(h)}px`,transform:"translate(-10px,-10px)",width:"18px",height:"18px",opacity:"0.001",pointerEvents:"auto",border:"0",padding:"0",margin:"0",zIndex:"2147483647"});let E=l.parentElement?.querySelector("ha-textfield")||null,A=null,_=0,v=()=>{_=0,A!=null&&(r?this._updateRule(e,i,s,{[n]:A}):this._updateRowRule(e,s,{[n]:A}))},w=D=>{A=D.target.value,E&&(E.value=A,E.requestUpdate?.()),_||(_=setTimeout(v,50))},x=D=>{A=D.target.value,clearTimeout(_),v(),V()},M=D=>{D.key==="Escape"&&V()},V=()=>{y.removeEventListener("input",w),y.removeEventListener("change",x),window.removeEventListener("keydown",M,!0),y.remove()};y.addEventListener("input",w),y.addEventListener("change",x),window.addEventListener("keydown",M,!0),p.appendChild(y),y.offsetWidth;try{y.showPicker?.()}catch{y.click()}setTimeout(V,6e4)}render(){if(!this.config||!Array.isArray(this.config.rows))return g`<div>—</div>`;let t=this.config.column_count||1,e=Array.isArray(this.config.column_widths)?this.config.column_widths.join(", "):"",i=Array.isArray(this.config.hide_on_narrow)?this.config.hide_on_narrow.join(","):"",s=Array.isArray(this.config.sort_columns)?this.config.sort_columns.join(","):"",n=this.config.cell_padding||{top:4,right:0,bottom:4,left:0},r=a=>a?JSON.parse(JSON.stringify(a)):void 0;return g`
      <div class="row">
        <h3>${d(this.hass,"editor.card_title")}</h3>

        <div class="cols3">
          <ha-textfield label=${d(this.hass,"editor.columns_count")} type="number" min="1" .value=${t}
            @input=${a=>this._updateColumnCount(a)}></ha-textfield>

          <ha-textfield label=${d(this.hass,"editor.text_size_global")}
            .value=${this.config.text_size||""} placeholder="14px | 1.1rem | 120%"
            @input=${a=>this._updateTextSize(a)}></ha-textfield>

          <ha-textfield label=${d(this.hass,"editor.card_padding")} type="number"
            .value=${this.config.card_padding??""} placeholder="16"
            @input=${a=>this._updateCardPadding(a)}></ha-textfield>
        </div>

        <div class="cols4">
          <ha-textfield label=${d(this.hass,"editor.cell_padding_top")} type="number" .value=${n.top??4}
            @input=${a=>this._updateCellPadding("top",a)}></ha-textfield>
          <ha-textfield label=${d(this.hass,"editor.cell_padding_right")} type="number" .value=${n.right??0}
            @input=${a=>this._updateCellPadding("right",a)}></ha-textfield>
          <ha-textfield label=${d(this.hass,"editor.cell_padding_bottom")} type="number" .value=${n.bottom??4}
            @input=${a=>this._updateCellPadding("bottom",a)}></ha-textfield>
          <ha-textfield label=${d(this.hass,"editor.cell_padding_left")} type="number" .value=${n.left??0}
            @input=${a=>this._updateCellPadding("left",a)}></ha-textfield>
        </div>

        <ha-textfield
          label=${d(this.hass,"editor.widths_label")}
          .value=${e}
          @input=${a=>this._upd("column_widths",this._parseCsvList(a.target.value))}>
        </ha-textfield>

        <div class="cols21">
          <ha-textfield
            label=${d(this.hass,"editor.hide_cols_label")}
            .value=${i}
            @input=${a=>this._upd("hide_on_narrow",this._parseCsvIntList(a.target.value))}>
          </ha-textfield>

          <ha-textfield
            label=${d(this.hass,"editor.breakpoint")} type="number"
            .value=${this.config.narrow_breakpoint??""} placeholder="600"
            @input=${a=>this._updateBreakpoint(a)}>
          </ha-textfield>
        </div>


        <div class="option-group">
          <ha-textfield
            style="width:100%;"
            label=${d(this.hass,"editor.sort_cols_label")}
            .value=${s}
            @input=${a=>this._upd("sort_columns",this._parseCsvIntList(a.target.value))}>
          </ha-textfield>
          <label class="simple-check">
            <input type="checkbox" .checked=${!!this.config.sort_desc} @change=${a=>this._toggle("sort_desc",a)} />
            <span>${d(this.hass,"editor.sort_desc_label")}</span>
          </label>
          <label class="simple-check">
            <input type="checkbox"
              .checked=${!!this.config.hide_separators_on_sort}
              @change=${a=>this._toggle("hide_separators_on_sort",a)} />
            <span>${d(this.hass,"editor.sort_hide_separators_label")}</span>
          </label>
          <div class="muted" style="margin-top:4px;">
            ${d(this.hass,"editor.sort_hint_grouped")}
          </div>
        </div>

        <div class="options">
          <label class="option"><input type="checkbox" .checked=${!!this.config.overflow_x} @change=${a=>this._toggle("overflow_x",a)} /> ${d(this.hass,"editor.overflow_x")}</label>
          <label class="option"><input type="checkbox" .checked=${!!this.config.header_from_first_row} @change=${a=>this._toggle("header_from_first_row",a)} /> ${d(this.hass,"editor.header_from_first")}</label>
          <div class="option-group zebra-option">
            <label>
              <input type="checkbox" .checked=${!!this.config.zebra} @change=${a=>this._toggle("zebra",a)} />
              ${d(this.hass,"editor.zebra")}
            </label>
            ${this.config.zebra?g`
              <label>
                <input type="checkbox"
                  .checked=${!!this.config.zebra_ignore_separators}
                  @change=${a=>this._toggle("zebra_ignore_separators",a)} />
                ${d(this.hass,"editor.zebra_skip_separators")}
              </label>
            `:""}
          </div>
        </div>

        ${t>=2?g`
          <div class="colbar">
            <div class="colstrip">
              ${Array.from({length:t},(a,o)=>g`
                <div class="colchip ${this._colDragOver===o?"is-over":""}"
                     @dragover=${l=>this._onColDragOver(o,l)}
                     @dragleave=${l=>this._onColDragLeave(o,l)}
                     @drop=${l=>this._onColDrop(o,l)}>
                  <div class="chiplabel">${d(this.hass,"editor.column")} ${o+1}</div>
                  <div class="chiptools">
                    <button title=${d(this.hass,"editor.move_left")} ?disabled=${o===0} @click=${()=>this._moveColumn(o,-1)}>◀</button>
                    <button title=${d(this.hass,"editor.move_right")} ?disabled=${o===t-1} @click=${()=>this._moveColumn(o,1)}>▶</button>
                    <button class="danger" title=${d(this.hass,"editor.delete_column")} @click=${()=>this._deleteColumn(o)}>✖</button>
                  </div>
                  <div class="colhandle"
                       role="button"
                       aria-label=${d(this.hass,"editor.drag_to_reorder")}
                       title=${d(this.hass,"editor.drag_to_reorder")}
                       draggable=${!this._isTouchDevice}
                       @contextmenu=${l=>l.preventDefault()}
                       @dragstart=${l=>this._onColDragStart(o,l)}
                       @dragend=${l=>this._onColDragEnd(l)}
                       @pointerdown=${l=>this._onColPointerDown(o,l)}>
                    <div class="dots">${Array.from({length:10},()=>g`<span class="dot"></span>`)}</div>
                  </div>
                </div>
              `)}
            </div>
          </div>
        `:""}
      </div>

      ${(this.config.rows||[]).map((a,o)=>{let l=this.config.column_count||1,c=!!a?.merge_columns,u=c?1:l,h=c?0:Math.min(this._activeTabs[o]||0,l-1),p=(a?.type||"")==="separator",b=!p&&this._isHeaderRowIndex(o),$=p?d(this.hass,"editor.separator_title"):`${d(this.hass,"editor.row")} ${this._displayRowNumber(o)}${b?d(this.hass,"editor.header_suffix"):""}`,y=!!this._collapsed?.[o],E=this._dragOverIndex===o?"dragover":"",A=`${y?"collapsed":""} ${p?"separator":""}`.trim();return g`
          <div class="row">
            <div class="rowbox ${E}"
                 @dragover=${_=>this._onDragOver(o,_)}
                 @dragleave=${_=>this._onDragLeave(o,_)}
                 @drop=${_=>this._onDrop(o,_)}
                 @contextmenu=${_=>_.preventDefault()}>
              <div class="rowhdr ${A}">
                <button class="handle"
                        title=${d(this.hass,"editor.drag_to_reorder")}
                        draggable=${!this._isTouchDevice}
                        @contextmenu=${_=>_.preventDefault()}
                        @dragstart=${_=>this._onDragStart(o,_)}
                        @dragend=${()=>this._onDragEnd()}
                        @pointerdown=${_=>this._onRowPointerDown(o,_)}>
                  ⋮⋮
                </button>

                <button class="toggle" title=${d(this.hass,"editor.toggle")}
                        @click=${()=>this._toggleCollapse(o)}
                        @keydown=${_=>{(_.key==="Enter"||_.key===" ")&&(_.preventDefault(),this._toggleCollapse(o))}}>
                  ${y?"\u25B6":"\u25BC"}
                </button>

                <div class="title">${$}</div>
                <div class="preview">${p?"":this._rowPreview(a)}</div>

                <div class="rowtools">
                  <button title=${d(this.hass,"editor.up")} ?disabled=${o===0} @click=${()=>this._moveRow(o,-1)}>▲</button>
                  <button title=${d(this.hass,"editor.down")} ?disabled=${o===(this.config.rows?.length||0)-1} @click=${()=>this._moveRow(o,1)}>▼</button>
                  <button class="danger" title="${d(this.hass,"editor.delete_row")}" @click=${()=>this._removeRow?.(o)}>❌</button>
                </div>
              </div>

              ${y?"":p?this._renderSeparatorEditor(a,o):g`
                <div class="rowbody">
                  <div class="tabs">
                    ${Array.from({length:u},(_,v)=>g`
                      <button class="tab ${v===h?"active":""}" @click=${()=>this._setActiveTab(o,v)}>
                        ${v===0?d(this.hass,"editor.tab_first"):String(v+1)}
                      </button>
                    `)}
                  </div>
                  <label class="simple-check" style="margin:8px 0 10px;">
                    <input type="checkbox"
                      .checked=${c}
                      @change=${_=>this._toggleMergeColumns(o,_)} />
                    <span>${d(this.hass,"editor.merge_all_columns")}</span>
                  </label>
                  ${(()=>{let _=c?0:h,v=a.cells?.[_]??{type:"string",value:"",align:"right"},w=v.type==="entity",x=v.type==="icon",M=w&&this._isEntityNumeric(v),V=v.entity_display||"value",D=w&&(V==="icon"||V==="icon_value"),S=v.style||{},k=w&&v.value||"",P=k&&k.split?k.split(".")[0]:"",z=(k?this._getStateObject(k):void 0)?.attributes?.mode,L=typeof z=="string"?z.trim().toLowerCase():"",J=(P==="input_number"||P==="number")&&(!L||L==="slider"||L==="auto"),it=v.show_control_value_right!==!1,ot=Array.isArray(a?.dyn_row_rules)?a.dyn_row_rules:[],tt=!!a.custom_css_enabled,B=typeof a.custom_css=="string"&&a.custom_css.trim()?a.custom_css:this._defaultRowCss(),Z=!!v.custom_css_enabled,Y=typeof v.custom_css=="string"&&v.custom_css.trim()?v.custom_css:this._defaultCellCss(),F=this._getAttrEditConfig(v),H=F.enabled===!0,W=F.control||"slider",Q=this._listServiceNames(),et=this._listServiceFields(F.service),R=this._allowedUiActionsForCellType(v.type),U=()=>R?{ui_action:{actions:R,allowed_actions:R}}:{ui_action:{}};return g`
                      <!-- TYP KOMÓRKI -->
                      <div class="cell-grid cell-wide">
                        <ha-select
                          .label=${d(this.hass,"editor.cell_type")}
                          .value=${v.type||"string"}
                          naturalMenuWidth
                          fixedMenuPosition
                          .options=${[{value:"entity",label:d(this.hass,"editor.entity_label")},{value:"string",label:d(this.hass,"editor.string_label")},{value:"icon",label:d(this.hass,"editor.icon_label")}]}
                          @selected=${f=>this._onTypeSelect(o,_,f)}
                          @closed=${f=>f.stopPropagation()}>
                        </ha-select>
                      </div>

                      <!-- WARTOŚĆ -->
                      ${w?g`
                        <div class="cell-grid cell-wide">
                          ${customElements.get("ha-entity-picker")?g`
                            <ha-entity-picker
                              .hass=${this.hass}
                              .value=${v.value||""}
                              allow-custom-entity
                              @value-changed=${f=>this._onEntityPicked(o,_,f)}>
                            </ha-entity-picker>
                          `:g`
                            <input list="entities-list" .value=${v.value||""} placeholder=${d(this.hass,"placeholder.entity")}
                              @input=${f=>this._cellValueChanged(o,_,f)} />
                          `}
                        </div>
                        <div class="cell-grid cell-wide">
                          <input
                            class="text-input mini-wide"
                            list=${`attr-list-${o}-${_}`}
                            .value=${v.attribute||""}
                            placeholder=${d(this.hass,"placeholder.attribute_path")}
                            @input=${f=>{this._cellAttributeChanged(o,_,f)}}
                          />
                          <datalist id=${`attr-list-${o}-${_}`}>
                            ${(this._buildAttrSuggestions(o,_,this.config?.rows?.[o]?.cells?.[_]?.attribute||"")||[]).map(f=>g`<option value="${f}"></option>`)}
                          </datalist>

                          <div class="cell-wide">
                            <ha-textfield
                              .label=${d(this.hass,"editor.datetime_format")}
                              .value=${v.datetime_format||""}
                              .placeholder=${d(this.hass,"placeholder.datetime_format")}
                              @input=${f=>this._patchCell(o,_,{datetime_format:f.target.value||""||void 0})}
                            ></ha-textfield>
                            <div class="muted">${d(this.hass,"editor.available_tokens")}</div>
                          </div>

                        </div>

                        <div class="cell-grid cell-wide">
                          <ha-select
                            .label=${d(this.hass,"editor.entity_display_label")}
                            .value=${v.entity_display||"value"}
                            naturalMenuWidth
                            fixedMenuPosition
                            .options=${[{value:"value",label:d(this.hass,"editor.entity_display_option_value")},{value:"icon",label:d(this.hass,"editor.entity_display_option_icon")},{value:"icon_value",label:d(this.hass,"editor.entity_display_option_icon_value")}]}
                            @selected=${f=>this._cellEntityDisplayChanged(o,_,f)}
                            @closed=${f=>f.stopPropagation()}>
                          </ha-select>
                        </div>

                        ${this._isSimpleControlEntity(v)?g`
                          <div class="cell-grid cell-wide">
                            <div class="option full option-stack">
                              <label>
                                <input type="checkbox"
                                      .checked=${!!v.show_control}
                                      @change=${f=>this._cellShowControlChanged(o,_,f)} />
                                <span>${d(this.hass,"editor.show_control")}</span>
                              </label>
                              ${v.show_control&&J?g`
                                <label>
                                  <input type="checkbox"
                                        .checked=${it}
                                        @change=${f=>this._cellShowControlValueRightChanged(o,_,f)} />
                                  <span>${d(this.hass,"editor.show_value_on_right")}</span>
                                </label>
                              `:N}
                            </div>
                          </div>
                        `:g``}

                        <details style="margin-top:12px;">
                          <summary style="cursor:pointer;font-weight:600;">
                            ${d(this.hass,"editor.attr_edit_title")}
                          </summary>

                          <div class="option-group attr-edit-toggle">
                            <label class=${H?"":"disabled"}>
                              <input type="checkbox"
                                .checked=${H}
                                @change=${f=>this._toggleAttrEditEnabled(o,_,f)} />
                              ${d(this.hass,"editor.attr_edit_enable")}
                            </label>
                            <div class="muted">${d(this.hass,"editor.attr_edit_hint")}</div>
                          </div>

                          <div class=${`cols1 attr-edit-fields ${H?"":"disabled"}`}>
                            <div class="cols1">
                              ${customElements.get("ha-service-picker")?g`
                                <ha-service-picker
                                  .hass=${this.hass}
                                  .value=${F.service||""}
                                  ?disabled=${!H}
                                  @value-changed=${f=>this._updateAttrEditText(o,_,"service",{target:{value:f.detail?.value||f.target?.value||""}})}>
                                </ha-service-picker>
                                ${F.service?g`
                                  <div class="service-id-preview">${F.service}</div>
                                `:g`
                                  <div class="service-id-preview" style="opacity:0.4;">domain.service</div>
                                `}
                              `:g`
                                <input
                                  class="text-input"
                                  list=${`attr-service-list-${o}-${_}`}
                                  .value=${F.service||""}
                                  placeholder=${d(this.hass,"editor.attr_edit_service")}
                                  ?disabled=${!H}
                                  @input=${f=>this._updateAttrEditText(o,_,"service",f)} />
                                <datalist id=${`attr-service-list-${o}-${_}`}>
                                  ${Q.map(f=>g`<option value="${f}"></option>`)}
                                </datalist>
                                ${F.service?g`
                                  <div class="service-id-preview">${F.service}</div>
                                `:g`
                                  <div class="service-id-preview" style="opacity:0.4;">domain.service</div>
                                `}
                              `}
                            </div>

                            <div class="cols1">
                              <input
                                class="text-input"
                                list=${`attr-service-field-${o}-${_}`}
                                .value=${F.field||""}
                                placeholder=${d(this.hass,"editor.attr_edit_service_field")}
                                ?disabled=${!H}
                                @input=${f=>this._updateAttrEditText(o,_,"field",f)} />
                              <datalist id=${`attr-service-field-${o}-${_}`}>
                                ${et.map(f=>g`<option value="${f}"></option>`)}
                              </datalist>
                            </div>

                            <div class="cell-grid cell-wide">
                            <ha-select
                              .label=${d(this.hass,"editor.attr_edit_control_type")}
                              .value=${W}
                              ?disabled=${!H}
                              naturalMenuWidth
                              fixedMenuPosition
                              .options=${[{value:"slider",label:d(this.hass,"editor.attr_edit_control_slider")},{value:"color",label:d(this.hass,"editor.attr_edit_control_color")},{value:"color_sat",label:d(this.hass,"editor.attr_edit_control_color_sat")},{value:"switch",label:d(this.hass,"editor.attr_edit_control_switch")}]}
                              @selected=${f=>this._updateAttrEditText(o,_,"control",f)}
                              @closed=${f=>f.stopPropagation()}>
                            </ha-select>
                          </div>

                            ${W==="slider"||W==="switch"||W==="color"||W==="color_sat"?g`
                              <div class="cell-grid cell-wide">
                                <label class="option full">
                                  <input type="checkbox"
                                    .checked=${it}
                                    ?disabled=${!H}
                                    @change=${f=>this._cellShowControlValueRightChanged(o,_,f)} />
                                  ${d(this.hass,"editor.show_value_on_right")}
                                </label>
                              </div>
                            `:N}

                            ${W==="color"?g`
                              <div class="cell-grid cell-wide muted">${d(this.hass,"editor.attr_edit_color_hint")}</div>
                              <div class="cols1">
                                <ha-textfield
                                  .label=${d(this.hass,"editor.attr_edit_color_hue_path")}
                                  .value=${F.hue_path||""}
                                  ?disabled=${!H}
                                  @input=${f=>this._updateAttrEditText(o,_,"hue_path",f)}>
                                </ha-textfield>
                              </div>
                              <div class="cols1">
                                <ha-textfield
                                  .label=${d(this.hass,"editor.attr_edit_color_sat_path")}
                                  .value=${F.sat_path||""}
                                  ?disabled=${!H}
                                  @input=${f=>this._updateAttrEditText(o,_,"sat_path",f)}>
                                </ha-textfield>
                              </div>
                              <div class="cols1">
                                <ha-textfield
                                  type="number"
                                  .label=${d(this.hass,"editor.attr_edit_color_sat_fallback")}
                                  .value=${F.sat_fallback??""}
                                  ?disabled=${!H}
                                  @input=${f=>this._updateAttrEditNumber(o,_,"sat_fallback",f)}>
                                </ha-textfield>
                              </div>
                            `:W==="color_sat"?g`
                              <div class="cell-grid cell-wide muted">${d(this.hass,"editor.attr_edit_color_sat_hint")}</div>
                              <div class="cols1">
                                <ha-textfield
                                  .label=${d(this.hass,"editor.attr_edit_color_hue_path")}
                                  .value=${F.hue_path||""}
                                  ?disabled=${!H}
                                  @input=${f=>this._updateAttrEditText(o,_,"hue_path",f)}>
                                </ha-textfield>
                              </div>
                              <div class="cols1">
                                <ha-textfield
                                  .label=${d(this.hass,"editor.attr_edit_color_sat_path")}
                                  .value=${F.sat_path||""}
                                  ?disabled=${!H}
                                  @input=${f=>this._updateAttrEditText(o,_,"sat_path",f)}>
                                </ha-textfield>
                              </div>
                            `:N}

                            ${W==="switch"?g`
                              <div class="cols2">
                                <ha-textfield
                                  .label=${d(this.hass,"editor.attr_edit_checked")}
                                  .value=${F.checked??!0}
                                  ?disabled=${!H}
                                  @input=${f=>this._updateAttrEditLiteral(o,_,"checked",f)}>
                                </ha-textfield>
                                <ha-textfield
                                  .label=${d(this.hass,"editor.attr_edit_unchecked")}
                                  .value=${F.unchecked??!1}
                                  ?disabled=${!H}
                                  @input=${f=>this._updateAttrEditLiteral(o,_,"unchecked",f)}>
                                </ha-textfield>
                              </div>
                            `:W==="slider"||W==="color_sat"?g`
                              <div class="cols3">
                                <ha-textfield
                                  type="number"
                                  .label=${d(this.hass,"editor.attr_edit_min")}
                                  .value=${F.min??""}
                                  ?disabled=${!H}
                                  @input=${f=>this._updateAttrEditNumber(o,_,"min",f)}>
                                </ha-textfield>
                                <ha-textfield
                                  type="number"
                                  .label=${d(this.hass,"editor.attr_edit_max")}
                                  .value=${F.max??""}
                                  ?disabled=${!H}
                                  @input=${f=>this._updateAttrEditNumber(o,_,"max",f)}>
                                </ha-textfield>
                                <ha-textfield
                                  type="number"
                                  .label=${d(this.hass,"editor.attr_edit_step")}
                                  .value=${F.step??""}
                                  ?disabled=${!H}
                                  @input=${f=>this._updateAttrEditNumber(o,_,"step",f)}>
                                </ha-textfield>
                              </div>
                            `:g``}
                          </div>
                        </details>
                          
                        <!-- PRZESKALOWANIE -->
                        <details style="margin-top:12px;">
                          <summary style="cursor:pointer;font-weight:600;">
                            ${d(this.hass,"editor.scale_title")}
                          </summary>
                          <div class="muted dyn-hint">${d(this.hass,"editor.scale_hint")}</div>
                          <div class="option group scale full">
                                  <ha-textfield class="mini"
                                    type="number"
                                    .label=${d(this.hass,"editor.scale_in_min")}
                                    .value=${v.scale_in_min??""}
                                    @input=${f=>this._cellScaleChanged(o,_,"scale_in_min",f)}>
                                  </ha-textfield>
                                  <ha-textfield class="mini"
                                    type="number"
                                    .label=${d(this.hass,"editor.scale_in_max")}
                                    .value=${v.scale_in_max??""}
                                    @input=${f=>this._cellScaleChanged(o,_,"scale_in_max",f)}>
                                  </ha-textfield>
                                  <ha-textfield class="mini"
                                    type="number"
                                    .label=${d(this.hass,"editor.scale_out_min")}
                                    .value=${v.scale_out_min??""}
                                    @input=${f=>this._cellScaleChanged(o,_,"scale_out_min",f)}>
                                  </ha-textfield>
                                  <ha-textfield class="mini"
                                    type="number"
                                    .label=${d(this.hass,"editor.scale_out_max")}
                                    .value=${v.scale_out_max??""}
                                    @input=${f=>this._cellScaleChanged(o,_,"scale_out_max",f)}>
                                  </ha-textfield>
                          </div>
                        </details>
                      `:x?g`
                        <div class="cell-grid cell-wide">
                          ${customElements.get("ha-icon-picker")?g`
                            <ha-icon-picker
                              .hass=${this.hass}
                              .label=${d(this.hass,"editor.icon_label")}
                              .value=${v.value||""}
                              @value-changed=${f=>this._cellValueChanged(o,_,{target:{value:f.detail?.value||""}})}>
                            </ha-icon-picker>
                          `:g`
                            <ha-textfield
                              .label=${d(this.hass,"editor.icon_label")}
                              .value=${v.value||""}
                              .placeholder=${d(this.hass,"placeholder.icon")}
                              @input=${f=>this._cellValueChanged(o,_,f)}>
                            </ha-textfield>
                          `}
                        </div>
                      `:g`
                        <div class="cell-grid cell-wide">
                          <ha-textfield
                            .label=${d(this.hass,"editor.string_label")}
                            .value=${v.value||""}
                            .placeholder=${d(this.hass,"placeholder.string")}
                            @input=${f=>this._cellValueChanged(o,_,f)}>
                          </ha-textfield>
                        </div>
                      `}

                      <!-- APPEARANCE SECTION -->
<details style="margin-top:12px;">
  <summary style="cursor:pointer;font-weight:600;">
    ${d(this.hass,"editor.appearance")}
  </summary>
                      <!-- WYRÓWNANIE -->
                      <div class="cell-grid cell-wide" style="margin-top: 10px;">
                        <ha-select
                          .label=${d(this.hass,"editor.align")}
                          .value=${v.align||"right"}
                          .options=${[{value:"left",label:d(this.hass,"align.left")},{value:"center",label:d(this.hass,"align.center")},{value:"right",label:d(this.hass,"align.right")}]}
                          @selected=${f=>this._cellAlignChanged(o,_,f)}
                          @closed=${f=>f.stopPropagation()}>
                        </ha-select>
                      </div>

                      <!-- TRANSFORMACJA -->
                      ${v.type==="string"||v.type==="entity"?g`
                        <div class="cell-grid cell-wide">
                          <ha-select
                            .label=${d(this.hass,"editor.text_transform")}
                            .value=${S.text_transform||""}
                            .options=${[{value:"",label:""},{value:"uppercase",label:"uppercase"},{value:"lowercase",label:"lowercase"},{value:"capitalize",label:"capitalize"}]}
                            @selected=${f=>this._styleValue(o,_,"text_transform",f)}
                            @closed=${f=>f.stopPropagation()}>
                          </ha-select>
                        </div>
                      `:""}

                      ${w?g`
                        <!-- JEDNOSTKA Z ENCJI -->
                        <div class="cell-grid cell-wide">
                          <div class="option unit option-stack">
                            <label>
                              <input type="checkbox"
                                   .checked=${v.use_entity_unit!==!1}
                                   @change=${f=>this._cellUseEntityUnitChanged(o,_,f)} />
                              <span class="label">${d(this.hass,"editor.unit_from_entity")}</span>
                            </label>
                            ${v.use_entity_unit===!1?g`
                              <ha-textfield
                                .label=${""}
                                .placeholder=${"\xB0C"}
                                .value=${v.unit||""}
                                @input=${f=>this._cellUnitChanged(o,_,f)}>
                              </ha-textfield>
                            `:N}
                          </div>
                        </div>

                        ${M?g`
                          <div class="cell-grid cell-wide" style="margin-bottom: 8px;">
                            <ha-select
                              .label=${d(this.hass,"editor.precision")}
                              .value=${(v.precision??"").toString()}
                              .options=${[{value:"",label:""},{value:"2",label:d(this.hass,"precision.two")},{value:"1",label:d(this.hass,"precision.one")},{value:"0",label:d(this.hass,"precision.int")}]}
                              @selected=${f=>this._cellPrecisionChanged(o,_,f)}
                              @closed=${f=>f.stopPropagation()}>
                            </ha-select>
                          </div>
                        `:""}
                      `:""}

                      ${v.type==="string"||v.type==="entity"?g`
                        <!-- TLO -->
                        <div class="cell-grid cell-wide">
                          <div class="inline">
                            <ha-textfield
                            .label=${d(this.hass,"editor.background_color")}
                            .placeholder=${"#ff5722 | red | var(--color)"}
                            .value=${S.background||""}
                            @input=${f=>this._styleValue(o,_,"background",f)}>
                            </ha-textfield>
                            <button class="toggle" title="Palette" @click=${f=>this._onPaletteClick(f,o,_,"background")}>
                              <ha-icon icon="mdi:palette"></ha-icon>
                            </button>
                          </div>
                        </div>

                        <!-- KOLOR -->
                        <div class="cell-grid cell-wide">
                          <div class="inline">
                            <ha-textfield
                            .label=${d(this.hass,"editor.content_color")}
                            .placeholder=${"#ff5722 | red | var(--color)"}
                            .value=${S.color||""}
                            @input=${f=>this._styleValue(o,_,"color",f)}>
                            </ha-textfield>
                            <button class="toggle" title="Palette" @click=${f=>this._onPaletteClick(f,o,_,"color")}>
                              <ha-icon icon="mdi:palette"></ha-icon>
                            </button>

                          </div>
                        </div>
                        ${D?g`
                          <div class="cell-grid cell-wide">
                            <ha-textfield
                              .label=${d(this.hass,"editor.icon_size")}
                              .placeholder=${"24px | 1.4rem"}
                              .value=${S.icon_size||""}
                              @input=${f=>this._styleValue(o,_,"icon_size",f)}>
                            </ha-textfield>
                          </div>
                        `:""}
                        <!-- ROZMIAR -->
                        <div class="cell-grid cell-wide">
                          <ha-textfield
                            .label=${d(this.hass,"editor.text_size")}
                            .placeholder=${"14px | 1.1rem | 120%"}
                            .value=${S.font_size||""}
                            @input=${f=>this._styleValue(o,_,"font_size",f)}>
                          </ha-textfield>
                        </div>

                        <!-- ODSTĘPY MIĘDZY LITERAMI -->
                        <div class="cell-grid cell-wide">
                          <ha-textfield
                            .label=${d(this.hass,"editor.letter_spacing")}
                            .placeholder=${"0.08em | -0.3px"}
                            .value=${S.letter_spacing||""}
                            @input=${f=>this._styleValue(o,_,"letter_spacing",f)}>
                          </ha-textfield>
                        </div>

                        <!-- POJEDYNCZE CHECKBOXY -->
                        <div class="cell-grid cell-wide">
                          <label class="option full">
                            <input type="checkbox" .checked=${!!S.bold} @change=${f=>this._styleToggle(o,_,"bold",f)} />
                            ${d(this.hass,"style.bold")}
                          </label>
                        </div>
                        <div class="cell-grid cell-wide">
                          <label class="option full">
                            <input type="checkbox" .checked=${!!S.italic} @change=${f=>this._styleToggle(o,_,"italic",f)} />
                            ${d(this.hass,"style.italic")}
                          </label>
                        </div>
                        <div class="cell-grid cell-wide">
                          <label class="option full">
                            <input type="checkbox" .checked=${S.underline??!1} @change=${f=>this._styleToggle(o,_,"underline",f)} />
                            ${d(this.hass,"style.underline")}
                          </label>
                        </div>
                        <div class="cell-grid cell-wide">
                          <label class="option full">
                            <input type="checkbox" .checked=${!!S.strike} @change=${f=>this._styleToggle(o,_,"strike",f)} />
                            ${d(this.hass,"style.strike")}
                          </label>
                        </div>
                      `:""}

                      ${x?g`
                        <div class="cell-grid cell-wide">
                          <div class="inline">
                            <ha-textfield
                            .label=${d(this.hass,"editor.background_color")}
                            .placeholder=${"#ff5722 | red | var(--primary-color)"}
                            .value=${S.background||""}
                            @input=${f=>this._styleValue(o,_,"background",f)}>
                            </ha-textfield>
                            <button class="toggle" title="Palette" @click=${f=>this._onPaletteClick(f,o,_,"background")}>
                              <ha-icon icon="mdi:palette"></ha-icon>
                            </button>
                          </div>
                        </div>

                        <div class="cell-grid cell-wide">
                          <div class="inline">
                            <ha-textfield
                            .label=${d(this.hass,"editor.icon_color")}
                            .placeholder=${"#ff5722 | red | var(--primary-color)"},
                            .value=${S.color||""}
                            @input=${f=>this._styleValue(o,_,"color",f)}>
                            </ha-textfield>
                            <button class="toggle" title="Palette" @click=${f=>this._onPaletteClick(f,o,_,"color")}>
                              <ha-icon icon="mdi:palette"></ha-icon>
                            </button>
                          </div>
                        </div>

                        <div class="cell-grid cell-wide">
                          <ha-textfield
                            .label=${d(this.hass,"editor.icon_size")}
                            .placeholder=${"24px | 1.4rem"}
                            .value=${S.icon_size||""}
                            @input=${f=>this._styleValue(o,_,"icon_size",f)}>
                          </ha-textfield>
                        </div>
                      `:""}

                        <div class="cell-grid cell-wide" style="margin-top:8px;">
                          <div class="option full option-stack">
                            <label>
                              <input type="checkbox"
                                     .checked=${Z}
                                     @change=${f=>this._toggleCellCustomCss(o,_,f)} />
                              <span class="label">${d(this.hass,"editor.custom_css")}</span>
                            </label>
                            ${Z?g`
                              <textarea
                                class="text-input"
                                rows="5"
                                style="font-family:monospace; min-height:120px;"
                                .value=${Y}
                                @input=${f=>this._updateCellCustomCss(o,_,f)}>
                              </textarea>
                            `:N}
                          </div>
                        </div>

                      </details>

                      <!-- Tap & Hold Actions -->
                      <details style="margin-top:12px;">
                        <summary style="cursor:pointer;font-weight:600;">
                          ${d(this.hass,"editor.advanced")}
                        </summary>

                        <div class="muted dyn-hint">${d(this.hass,"editor.actions_hint")}</div>


                        <div class="cell-grid cell-wide" style="margin-top:8px;">
                          <ha-form
                            .hass=${this.hass}
                            .data=${{tap_action:r(v.tap_action),hold_action:r(v.hold_action),double_tap_action:r(v.double_tap_action)}}
                            .schema=${[{name:"tap_action",selector:U()},{name:"hold_action",selector:U()},{name:"double_tap_action",selector:U()}]}
                            .computeLabel=${this._computeActionLabel}
                            @value-changed=${f=>this._onActionsChanged(o,_,f)}
                          ></ha-form>
                        </div>

                        
                      </details>
                      <!-- DYNAMIC COLORING -->
                      <details style="margin-top:12px;">
                        <summary style="cursor:pointer;font-weight:600;">
                          ${d(this.hass,"editor.dynamic_title")}
                        </summary>

                        <div class="muted dyn-hint">${d(this.hass,"editor.dynamic_hint")}</div>

                        ${(Array.isArray(v?.dyn_color)?v.dyn_color:[]).map((f,T)=>{let G=this._normalizeRuleConditions(f),I=this._normalizeRuleMatch(f);return g`
                          <div class="option group full">
                            <div class="cols1">
                              <div class="rulehdr">${this._ruleTitle(T)}</div>
                            </div>

                            <div class="cols1">
                              <ha-select
                                .label=${d(this.hass,"dynamic.match")}
                                .value=${I}
                                .options=${[{value:"all",label:d(this.hass,"dynamic.match_all")},{value:"any",label:d(this.hass,"dynamic.match_any")}]}
                              @selected=${C=>this._updateRule(o,_,T,{match:C.detail?.value??C.target?.value})}
                              @closed=${C=>C.stopPropagation()}>
                            </ha-select>
                          </div>

                            ${G.map((C,q)=>g`
                              <div class="option group full" style="margin:6px 0; padding:10px; border:1px dashed var(--divider-color,#ddd);">
                                <div class="cols1">
                                  <ha-entity-picker
                                    .hass=${this.hass}
                                    .value=${C.entity||""}
                                    allow-custom-entity
                                    @value-changed=${O=>this._updateCondition(o,_,T,q,{entity:O.detail?.value||O.target.value})}>
                                  </ha-entity-picker>
                                </div>

                                <div class="cols1">
                                  <input
                                    class="text-input attr-input"
                                    list=${`dynattr-list-${o}-${_}-${T}-${q}`}
                                    .value=${C.attr||""}
                                    placeholder=${d(this.hass,"placeholder.attribute_path")}
                                    @input=${O=>this._updateCondition(o,_,T,q,{attr:O.target.value||""})}
                                  />
                                  <datalist id=${`dynattr-list-${o}-${_}-${T}-${q}`}>
                                    ${(this._buildAttrSuggestionsForEntity(C.entity,C.attr||"")||[]).map(O=>g`<option value="${O}"></option>`)}
                                  </datalist>
                                </div>

                                <div class="cols2">
                                  <ha-select
                                    .label=${d(this.hass,"dynamic.operator")}
                                    .value=${C.op||"="}
                                    .options=${[{value:">",label:">"},{value:">=",label:"\u2265"},{value:"<",label:"<"},{value:"<=",label:"\u2264"},{value:"=",label:"="},{value:"!=",label:"\u2260"},{value:"between",label:d(this.hass,"dynamic.op_between")},{value:"contains",label:d(this.hass,"dynamic.op_contains")},{value:"not_contains",label:d(this.hass,"dynamic.op_not_contains")}]}
                                    @selected=${O=>this._updateCondition(o,_,T,q,{op:O.detail?.value??O.target?.value})}
                                    @closed=${O=>O.stopPropagation()}>
                                  </ha-select>

                                  ${C&&C.op==="between"?g`
                                    <div class="cols2">
                                      <ha-textfield
                                        .label=${d(this.hass,"dynamic.min")}
                                        .value=${C.val||""}
                                        @input=${O=>this._updateCondition(o,_,T,q,{val:O.target.value})}>
                                      </ha-textfield>
                                      <ha-textfield
                                        .label=${d(this.hass,"dynamic.max")}
                                        .value=${C.val2||""}
                                        @input=${O=>this._updateCondition(o,_,T,q,{val2:O.target.value})}>
                                      </ha-textfield>
                                    </div>
                                  `:g`
                                    <ha-textfield
                                      .label=${d(this.hass,"editor.value")}
                                      .value=${C.val||""}
                                      @input=${O=>this._updateCondition(o,_,T,q,{val:O.target.value})}>
                                    </ha-textfield>
                                  `}
                                </div>

                                ${G.length>1?g`
                                  <div class="cols1 right">
                                    <button class="danger mini" @click=${()=>this._removeCondition(o,_,T,q)}>
                                      ${d(this.hass,"dynamic.delete_condition")}
                                    </button>
                                  </div>
                                `:N}
                              </div>
                            `)}

                            <div class="flex" style="margin:4px 0 10px;">
                              <button class="mini" @click=${()=>this._addCondition(o,_,T)}>➕ ${d(this.hass,"dynamic.add_condition")}</button>
                            </div>

                            <!-- Colors row: Background + Content 50/50 with pickers -->
                            <div class="cols2">
                              <div class="inline">
                                <ha-textfield
                                  .label=${d(this.hass,"dynamic.bg")}
                                  .value=${f.bg||""}
                                  .placeholder=${"transparent | #ff5722 | red | var(--color)"}
                                  @input=${C=>this._updateRule(o,_,T,{bg:C.target.value})}>
                                </ha-textfield>
                                <button class="toggle" title="Palette"
                                  @click=${C=>this._onRuleColorPicker(C,o,_,T,"bg")}>
                                  <ha-icon icon="mdi:palette"></ha-icon>
                                </button>
                              </div>

                              <div class="inline">
                                <ha-textfield
                                  .label=${d(this.hass,"dynamic.fg")}
                                  .value=${f.fg||""}
                                  .placeholder=${"transparent | #ff5722 | red | var(--color)"}
                                  @input=${C=>this._updateRule(o,_,T,{fg:C.target.value})}>
                                </ha-textfield>
                                <button class="toggle" title="Palette"
                                  @click=${C=>this._onRuleColorPicker(C,o,_,T,"fg")}>
                                  <ha-icon icon="mdi:palette"></ha-icon>
                                </button>
                              </div>
                            </div>

                            <!-- Overwrite select -->
                            <div class="cols1">
                              <ha-select
                                .label=${d(this.hass,"dynamic.overwrite_label")}
                                .value=${f.overwrite||""}
                                .options=${[{value:"",label:""},{value:"hide",label:d(this.hass,"dynamic.overwrite_hide")},{value:"entity",label:d(this.hass,"dynamic.overwrite_entity_metadata")},{value:"text",label:d(this.hass,"dynamic.overwrite_text")},{value:"icon",label:d(this.hass,"dynamic.overwrite_icon")}]}
                                @selected=${C=>this._updateRule(o,_,T,{overwrite:C.detail?.value??C.target?.value})}
                                @closed=${C=>C.stopPropagation()}>
                              </ha-select>
                            </div>

                            ${(f.overwrite||"")==="entity"?g`
                              <div class="cols1">
                                <ha-entity-picker
                                  .hass=${this.hass}
                                  .value=${f.overwrite_entity||G?.[0]?.entity||""}
                                  allow-custom-entity
                                  @value-changed=${C=>this._updateRule(o,_,T,{overwrite_entity:C.detail?.value||C.target.value})}>
                                </ha-entity-picker>
                              </div>
                              <div class="cols1">
                                <input
                                  class="text-input attr-input"
                                  list=${`dynoverwriteattr-${o}-${_}-${T}`}
                                  .value=${f.overwrite_attr||""}
                                  placeholder=${d(this.hass,"placeholder.attribute_path")}
                                  @input=${C=>this._updateRule(o,_,T,{overwrite_attr:C.target.value||""})}
                                />
                                  <datalist id=${`dynoverwriteattr-${o}-${_}-${T}`}>
                                  ${(this._buildAttrSuggestionsForEntity(f.overwrite_entity||G?.[0]?.entity,f.overwrite_attr||"")||[]).map(C=>g`<option value="${C}"></option>`)}
                                </datalist>
                              </div>
                              <div class="cols1">
                                <ha-textfield class="mask-input"
                                  .label=${d(this.hass,"editor.datetime_format")}
                                  .value=${f.overwrite_datetime_format||""}
                                  .placeholder=${d(this.hass,"placeholder.datetime_format")}
                                  @input=${C=>this._updateRule(o,_,T,{overwrite_datetime_format:(C.target?.value||"").trim()?C.target.value:void 0})}>
                                </ha-textfield>
                                <div class="muted">${d(this.hass,"editor.available_tokens")}</div>
                              </div>
                              <div class="cols1">
                                <ha-select
                                  .label=${d(this.hass,"editor.entity_display_label")}
                                  .value=${f.overwrite_entity_display||"value"}
                                  naturalMenuWidth
                                  fixedMenuPosition
                                  .options=${[{value:"value",label:d(this.hass,"editor.entity_display_option_value")},{value:"icon",label:d(this.hass,"editor.entity_display_option_icon")},{value:"icon_value",label:d(this.hass,"editor.entity_display_option_icon_value")}]}
                                  @selected=${C=>this._updateRuleEntityDisplay(o,_,T,C)}
                                  @closed=${C=>C.stopPropagation()}>
                                </ha-select>
                              </div>
                              <div class="cols1">
                                <details style="margin-top:12px;">
                                  <summary style="cursor:pointer;font-weight:600;">
                                    ${d(this.hass,"editor.scale_title")}
                                  </summary>

                                  <div class="muted dyn-hint">${d(this.hass,"editor.scale_hint")}</div>
                                  <div class="option group scale full">
                                          <ha-textfield class="mini"
                                            type="number"
                                            .label=${d(this.hass,"editor.scale_in_min")}
                                            .value=${f.overwrite_scale_in_min??""}
                                            @input=${C=>this._updateRuleScale(o,_,T,"overwrite_scale_in_min",C)}>
                                          </ha-textfield>
                                          <ha-textfield class="mini"
                                            type="number"
                                            .label=${d(this.hass,"editor.scale_in_max")}
                                            .value=${f.overwrite_scale_in_max??""}
                                            @input=${C=>this._updateRuleScale(o,_,T,"overwrite_scale_in_max",C)}>
                                          </ha-textfield>
                                          <ha-textfield class="mini"
                                            type="number"
                                            .label=${d(this.hass,"editor.scale_out_min")}
                                            .value=${f.overwrite_scale_out_min??""}
                                            @input=${C=>this._updateRuleScale(o,_,T,"overwrite_scale_out_min",C)}>
                                          </ha-textfield>
                                          <ha-textfield class="mini"
                                            type="number"
                                            .label=${d(this.hass,"editor.scale_out_max")}
                                            .value=${f.overwrite_scale_out_max??""}
                                            @input=${C=>this._updateRuleScale(o,_,T,"overwrite_scale_out_max",C)}>
                                          </ha-textfield>
                                  </div>                                  
                                </details>
                              </div>
                            `:g``}

                            ${(f.overwrite||"")==="text"?g`
                              <div class="cols1">
                                <ha-textfield class="mask-input"
                                  .label=${d(this.hass,"dynamic.text")}
                                  .value=${f.text||""}
                                  @input=${C=>this._updateRule(o,_,T,{text:C.target.value})}>
                                </ha-textfield>
                              </div>
                            `:g``}

                            ${(f.overwrite||"")==="icon"?g`
                              <div class="cols1">
                                ${customElements.get("ha-icon-picker")?g`
                                  <ha-icon-picker
                                    .hass=${this.hass}
                                    .label=${d(this.hass,"editor.icon_label")}
                                    .value=${f.icon||""}
                                    @value-changed=${C=>this._updateRule(o,_,T,{icon:C.detail?.value||""})}>
                                  </ha-icon-picker>
                                `:g`
                                  <ha-textfield
                                    .label=${d(this.hass,"editor.icon_label")}
                                    .value=${f.icon||""}
                                    .placeholder=${d(this.hass,"placeholder.icon")}
                                    @input=${C=>this._updateRule(o,_,T,{icon:C.target.value})}>
                                  </ha-textfield>
                                `}
                              </div>
                              <div class="cols1">
                                <ha-textfield class="mask-input"
                                  .label=${d(this.hass,"dynamic.icon_optional_text")}
                                  .value=${f.icon_text||""}
                                  @input=${C=>this._updateRule(o,_,T,{icon_text:C.target.value})}>
                                </ha-textfield>
                              </div>
                              <div class="cols1">
                                <div class="inline">
                                  <ha-textfield
                                    .label=${d(this.hass,"dynamic.icon_color")}
                                    .value=${f.icon_color||""}
                                    .placeholder=${"#ff5722 | red | var(--color)"}
                                    @input=${C=>this._updateRule(o,_,T,{icon_color:C.target.value})}>
                                  </ha-textfield>
                                  <button class="toggle" title="Palette"
                                    @click=${C=>this._onRuleColorPicker(C,o,_,T,"icon_color")}>
                                    <ha-icon icon="mdi:palette"></ha-icon>
                                  </button>
                                </div>
                              </div>
                            `:g``}

                            <div class="cols1 right">
                              <button class="danger mini" @click=${()=>this._removeRule(o,_,T)}>
                                ${d(this.hass,"dynamic.delete_rule")}
                              </button>
                            </div>
                          </div>
                        `})}

                        <div class="flex" style="margin-top:6px;">
                          <button class="mini" @click=${()=>this._addRule(o,_)}>➕ ${d(this.hass,"dynamic.add_rule")}</button>
                        </div>
                      </details>

                      <div style="border-top:1px solid var(--divider-color, #e0e0e0); margin:16px 0 12px;"></div>

                      <details style="margin-top:0;">
                        <summary style="cursor:pointer;font-weight:600;">
                          ${d(this.hass,"editor.dynamic_row_title")}
                        </summary>

                        <div class="muted dyn-hint">${d(this.hass,"editor.dynamic_hint")}</div>

                        ${ot.map((f,T)=>{let G=this._normalizeRuleConditions(f),I=this._normalizeRuleMatch(f);return g`
                          <div class="option group full">
                            <div class="cols1">
                              <div class="rulehdr">${this._ruleTitle(T)}</div>
                            </div>

                            <div class="cols1">
                              <ha-select
                                .label=${d(this.hass,"dynamic.match")}
                                .value=${I}
                                .options=${[{value:"all",label:d(this.hass,"dynamic.match_all")},{value:"any",label:d(this.hass,"dynamic.match_any")}]}
                                @selected=${C=>this._updateRowRule(o,T,{match:C.detail?.value??C.target?.value})}
                                @closed=${C=>C.stopPropagation()}>
                              </ha-select>
                            </div>

                            ${G.map((C,q)=>g`
                              <div class="option group full" style="margin:6px 0; padding:10px; border:1px dashed var(--divider-color,#ddd);">
                                <div class="cols1">
                                  <ha-entity-picker
                                    .hass=${this.hass}
                                    .value=${C?.entity||""}
                                    allow-custom-entity
                                    @value-changed=${O=>this._updateRowCondition(o,T,q,{entity:O.detail?.value||O.target.value})}>
                                  </ha-entity-picker>
                                </div>

                                <div class="cols1">
                                  <input
                                    class="text-input attr-input"
                                    list=${`rowdynattr-list-${o}-${T}-${q}`}
                                    .value=${C?.attr||""}
                                    placeholder=${d(this.hass,"placeholder.attribute_path")}
                                    @input=${O=>this._updateRowCondition(o,T,q,{attr:O.target.value||""})}
                                  />
                                  <datalist id=${`rowdynattr-list-${o}-${T}-${q}`}>
                                    ${(this._buildAttrSuggestionsForEntity(C?.entity,C?.attr||"")||[]).map(O=>g`<option value="${O}"></option>`)}
                                  </datalist>
                                </div>

                                <div class="cols2">
                                  <ha-select
                                    .label=${d(this.hass,"dynamic.operator")}
                                    .value=${C?.op||"="}
                                    .options=${[{value:">",label:">"},{value:">=",label:"\u2265"},{value:"<",label:"<"},{value:"<=",label:"\u2264"},{value:"=",label:"="},{value:"!=",label:"\u2260"},{value:"between",label:d(this.hass,"dynamic.op_between")},{value:"contains",label:d(this.hass,"dynamic.op_contains")},{value:"not_contains",label:d(this.hass,"dynamic.op_not_contains")}]}
                                    @selected=${O=>this._updateRowCondition(o,T,q,{op:O.detail?.value??O.target?.value})}
                                    @closed=${O=>O.stopPropagation()}>
                                  </ha-select>

                                  ${C&&C.op==="between"?g`
                                    <div class="cols2">
                                      <ha-textfield
                                        .label=${d(this.hass,"dynamic.min")}
                                        .value=${C?.val||""}
                                        @input=${O=>this._updateRowCondition(o,T,q,{val:O.target.value})}>
                                      </ha-textfield>
                                      <ha-textfield
                                        .label=${d(this.hass,"dynamic.max")}
                                        .value=${C?.val2||""}
                                        @input=${O=>this._updateRowCondition(o,T,q,{val2:O.target.value})}>
                                      </ha-textfield>
                                    </div>
                                  `:g`
                                    <ha-textfield
                                      .label=${d(this.hass,"editor.value")}
                                      .value=${C?.val||""}
                                      @input=${O=>this._updateRowCondition(o,T,q,{val:O.target.value})}>
                                    </ha-textfield>
                                  `}
                                </div>

                                ${G.length>1?g`
                                  <div class="cols1 right">
                                    <button class="danger mini" @click=${()=>this._removeRowCondition(o,T,q)}>
                                      ${d(this.hass,"dynamic.delete_condition")}
                                    </button>
                                  </div>
                                `:N}
                              </div>
                            `)}

                            <div class="flex" style="margin:4px 0 10px;">
                              <button class="mini" @click=${()=>this._addRowCondition(o,T)}>➕ ${d(this.hass,"dynamic.add_condition")}</button>
                            </div>

                            <div class="cols2">
                              <div class="inline">
                                <ha-textfield
                                  .label=${d(this.hass,"dynamic.bg")}
                                  .value=${f?.bg||""}
                                  .placeholder=${"transparent | #ff5722 | red | var(--color)"}
                                  @input=${C=>this._updateRowRule(o,T,{bg:C.target.value})}>
                                </ha-textfield>
                                <button class="toggle" title="Palette"
                                  @click=${C=>this._onRuleColorPicker(C,o,null,T,"bg")}>
                                  <ha-icon icon="mdi:palette"></ha-icon>
                                </button>
                              </div>

                              <div class="inline">
                                <ha-textfield
                                  .label=${d(this.hass,"dynamic.fg")}
                                  .value=${f?.fg||""}
                                  .placeholder=${"transparent | #ff5722 | red | var(--color)"}
                                  @input=${C=>this._updateRowRule(o,T,{fg:C.target.value})}>
                                </ha-textfield>
                                <button class="toggle" title="Palette"
                                  @click=${C=>this._onRuleColorPicker(C,o,null,T,"fg")}>
                                  <ha-icon icon="mdi:palette"></ha-icon>
                                </button>
                              </div>
                            </div>

                            <div class="cols1">
                              <ha-select
                                .label=${d(this.hass,"dynamic.visibility_label")}
                                .value=${f?.visibility||""}
                                .options=${[{value:"",label:""},{value:"visible",label:d(this.hass,"dynamic.visibility_visible")},{value:"hidden",label:d(this.hass,"dynamic.visibility_hidden")}]}
                                @selected=${C=>this._updateRowRule(o,T,{visibility:(C.detail?.value??C.target?.value)||void 0})}
                                @closed=${C=>C.stopPropagation()}>
                              </ha-select>
                            </div>

                            <div class="cols1 right">
                              <button class="danger mini" @click=${()=>this._removeRowRule(o,T)}>
                                ${d(this.hass,"dynamic.delete_rule")}
                              </button>
                            </div>
                          </div>
                        `})}

                      <div class="flex" style="margin-top:6px;">
                        <button class="mini" @click=${()=>this._addRowRule(o)}>➕ ${d(this.hass,"dynamic.add_rule")}</button>
                      </div>
                    </details>

                      <details style="margin-top:12px;">
                        <summary style="cursor:pointer;font-weight:600;">
                          ${d(this.hass,"editor.appearance_row")}
                        </summary>

                        <div class="cell-grid cell-wide" style="margin-top:10px;">
                          <div class="option full option-stack">
                            <label>
                              <input type="checkbox"
                                     .checked=${tt}
                                     @change=${f=>this._toggleRowCustomCss(o,f)} />
                              <span class="label">${d(this.hass,"editor.custom_css")}</span>
                            </label>
                            ${tt?g`
                              <textarea
                                class="text-input"
                                rows="5"
                                style="font-family:monospace; min-height:120px;"
                                .value=${B}
                                @input=${f=>this._updateRowCustomCss(o,f)}>
                              </textarea>
                            `:N}
                          </div>
                        </div>
                      </details>

                      <div style="border-top:1px solid var(--divider-color, #e0e0e0); margin:16px 0 12px;"></div>

                      <details style="margin-top:0;">
                        <summary style="cursor:pointer;font-weight:600;">
                          ${d(this.hass,"editor.copy_paste_section")}
                        </summary>

                        <div class="copy-section">
                          <div class="copy-group">
                            <div class="copy-group-title">${d(this.hass,"editor.copy_row_group")}</div>
                            <div class="copy-group-buttons">
                              <button class="mini" @click=${()=>this._copyRow(o)}>${d(this.hass,"editor.copy_row")}</button>
                              <button class="mini" ?disabled=${!this._clipboardRow?.full} @click=${()=>this._pasteRow(o)}>${d(this.hass,"editor.paste_row")}</button>
                            </div>
                            <div class="copy-group-buttons">
                              <button class="mini" @click=${()=>this._copyRowAppearance(o)}>${d(this.hass,"editor.copy_row_appearance")}</button>
                              <button class="mini" ?disabled=${!this._clipboardRow?.appearance} @click=${()=>this._pasteRowAppearance(o)}>${d(this.hass,"editor.paste_row_appearance")}</button>
                            </div>
                            <div class="copy-group-buttons">
                              <button class="mini" @click=${()=>this._copyRowRules(o)}>${d(this.hass,"editor.copy_row_rules")}</button>
                              <button class="mini" ?disabled=${!this._clipboardRow?.rules} @click=${()=>this._pasteRowRules(o)}>${d(this.hass,"editor.paste_row_rules")}</button>
                            </div>
                            <div class="muted copy-summary">
                              ${d(this.hass,"editor.clipboard_row_label")}: ${this._clipboardSummary(this._clipboardRow)}
                            </div>
                          </div>

                          <div class="copy-group">
                            <div class="copy-group-title">${d(this.hass,"editor.copy_cell_group")}</div>
                            <div class="copy-group-buttons">
                              <button class="mini" @click=${()=>this._copyActiveCell(o)}>${d(this.hass,"editor.copy_cell")}</button>
                              <button class="mini" ?disabled=${!this._clipboardCell?.full} @click=${()=>this._pasteToActiveCell(o)}>${d(this.hass,"editor.paste_cell")}</button>
                            </div>
                            <div class="copy-group-buttons">
                              <button class="mini" @click=${()=>this._copyCellAppearance(o)}>${d(this.hass,"editor.copy_cell_appearance")}</button>
                              <button class="mini" ?disabled=${!this._clipboardCell?.appearance} @click=${()=>this._pasteCellAppearance(o)}>${d(this.hass,"editor.paste_cell_appearance")}</button>
                            </div>
                            <div class="copy-group-buttons">
                              <button class="mini" @click=${()=>this._copyCellRules(o)}>${d(this.hass,"editor.copy_cell_rules")}</button>
                              <button class="mini" ?disabled=${!this._clipboardCell?.rules} @click=${()=>this._pasteCellRules(o)}>${d(this.hass,"editor.paste_cell_rules")}</button>
                            </div>
                            <div class="copy-group-buttons">
                              <button class="mini" @click=${()=>this._copyCellActions(o)}>${d(this.hass,"editor.copy_cell_actions")}</button>
                              <button class="mini" ?disabled=${!this._clipboardCell?.actions} @click=${()=>this._pasteCellActions(o)}>${d(this.hass,"editor.paste_cell_actions")}</button>
                            </div>
                            <div class="muted copy-summary">
                              ${d(this.hass,"editor.clipboard_cell_label")}: ${this._clipboardSummary(this._clipboardCell)}
                            </div>
                          </div>

                          <div class="copy-group">
                            <div class="copy-group-title">${d(this.hass,"editor.copy_multi_cell_group")}</div>
                            <div class="copy-group-buttons">
                              <button class="mini" ?disabled=${!this._clipboardCell?.full} @click=${()=>this._applyClipboardCellBulk(o,"column","full")}>${d(this.hass,"editor.paste_cell_column")}</button>
                              <button class="mini" ?disabled=${!this._clipboardCell?.full} @click=${()=>this._applyClipboardCellBulk(o,"row","full")}>${d(this.hass,"editor.paste_cell_row")}</button>
                            </div>
                            <div class="copy-group-buttons">
                              <button class="mini" ?disabled=${!this._clipboardCell?.appearance} @click=${()=>this._applyClipboardCellBulk(o,"column","appearance")}>${d(this.hass,"editor.paste_cell_appearance_column")}</button>
                              <button class="mini" ?disabled=${!this._clipboardCell?.appearance} @click=${()=>this._applyClipboardCellBulk(o,"row","appearance")}>${d(this.hass,"editor.paste_cell_appearance_row")}</button>
                            </div>
                            <div class="copy-group-buttons">
                              <button class="mini" ?disabled=${!this._clipboardCell?.rules} @click=${()=>this._applyClipboardCellBulk(o,"column","rules")}>${d(this.hass,"editor.paste_cell_rules_column")}</button>
                              <button class="mini" ?disabled=${!this._clipboardCell?.rules} @click=${()=>this._applyClipboardCellBulk(o,"row","rules")}>${d(this.hass,"editor.paste_cell_rules_row")}</button>
                            </div>
                            <div class="copy-group-buttons">
                              <button class="mini" ?disabled=${!this._clipboardCell?.actions} @click=${()=>this._applyClipboardCellBulk(o,"column","actions")}>${d(this.hass,"editor.paste_cell_actions_column")}</button>
                              <button class="mini" ?disabled=${!this._clipboardCell?.actions} @click=${()=>this._applyClipboardCellBulk(o,"row","actions")}>${d(this.hass,"editor.paste_cell_actions_row")}</button>
                            </div>
                          </div>
                        </div>
                      </details>
                    `})()}
                </div>
              `}
            </div>
          </div>
        `})}

      <div class="addrow">
        <button type="button" @click=${()=>this._addRow?.()}>
          <span class="btn-icon">&#x2795;</span>
          ${d(this.hass,"editor.add_row")}
        </button>
        <button type="button" class="secondary" @click=${()=>this._addSeparator?.()}>
          <span class="btn-icon">&#x2795;</span>
          ${d(this.hass,"editor.add_separator")}
        </button>
      </div>

      <div class="option group">
        <label class="simple-check">
          <input
            type="checkbox"
            .checked=${!!this.config.custom_template_enabled}
            @change=${a=>this._toggleCustomTemplate(a)} />
          <span>${d(this.hass,"editor.custom_template")}</span>
        </label>
        ${this.config.custom_template_enabled?g`
          <textarea
            class="text-input"
            rows="8"
            style="margin-top:12px; min-height:160px;"
            .value=${this.config.custom_template_html||""}
            @input=${a=>this._updateCustomTemplateHtml(a)}>
          </textarea>
          <div class="muted">
            ${d(this.hass,"editor.custom_template_hint")}
          </div>
        `:""}
      </div>

      <datalist id="entities-list">
        ${Object.keys(this.hass?.states||{}).map(a=>g`<option value=${a}></option>`)}
      </datalist>
    `}_addRow(){let t=this.config.column_count||1,e=Array.from({length:t},(s,n)=>({type:"string",value:"",align:n===0?"left":"right"})),i=[...this.config.rows||[],{cells:e}];this.config={...this.config,rows:i},this._fullCells=[...this._fullCells||[],e.map(s=>this._clone(s))],this._collapsed=[...this._collapsed||[],!0],this._activeTabs={...this._activeTabs||{},[i.length-1]:0},this._fireConfigChanged()}_addSeparator(){let t=this._defaultSeparator(),e=[...this.config.rows||[],{type:"separator",separator:t,cells:[]}];this.config={...this.config,rows:e},this._fullCells=[...this._fullCells||[],[]],this._collapsed=[...this._collapsed||[],!0],this._activeTabs={...this._activeTabs||{},[e.length-1]:0},this._fireConfigChanged()}_removeRow(t){let e=[...this.config.rows||[]];if(t<0||t>=e.length)return;if(e.splice(t,1),this.config={...this.config,rows:e},Array.isArray(this._fullCells)&&this._fullCells.length){let s=[...this._fullCells];s.splice(t,1),this._fullCells=s}if(Array.isArray(this._collapsed)&&this._collapsed.length){let s=[...this._collapsed];s.splice(t,1),this._collapsed=s}let i={};Object.keys(this._activeTabs||{}).forEach(s=>{let n=parseInt(s,10);n<t?i[n]=this._activeTabs[n]:n>t&&(i[n-1]=this._activeTabs[n])}),this._activeTabs=i,this._fireConfigChanged()}};customElements.get("flex-cells-card-editor")||customElements.define("flex-cells-card-editor",ne)});ee();se();oe();mt();var lt={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},Ut=m=>(...t)=>({_$litDirective$:m,values:t}),bt=class{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,i){this._$Ct=t,this._$AM=e,this._$Ci=i}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}};var St=class extends bt{constructor(t){if(super(t),this.it=N,t.type!==lt.CHILD)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(t){if(t===N||t==null)return this._t=void 0,this.it=t;if(t===X)return t;if(typeof t!="string")throw Error(this.constructor.directiveName+"() called with a non-string value");if(t===this.it)return this._t;this.it=t;let e=[t];return e.raw=e,this._t={_$litType$:this.constructor.resultType,strings:e,values:[]}}};St.directiveName="unsafeHTML",St.resultType=1;var re=Ut(St);mt();mt();var{I:ji}=Se;var Fe=m=>m.strings===void 0;var ii={},ze=(m,t=ii)=>m._$AH=t;var Le=Ut(class extends bt{constructor(m){if(super(m),m.type!==lt.PROPERTY&&m.type!==lt.ATTRIBUTE&&m.type!==lt.BOOLEAN_ATTRIBUTE)throw Error("The `live` directive is not allowed on child or event bindings");if(!Fe(m))throw Error("`live` bindings can only contain a single expression")}render(m){return m}update(m,[t]){if(t===X||t===N)return t;let e=m.element,i=m.name;if(m.type===lt.PROPERTY){if(t===e[i])return X}else if(m.type===lt.BOOLEAN_ATTRIBUTE){if(!!t===e.hasAttribute(i))return X}else if(m.type===lt.ATTRIBUTE&&e.getAttribute(i)===t+"")return X;return ze(m),t}});var ae={numeric:!0,sensitivity:"base"},ce="unavailable",si="unknown",ni="off",Oe=new Set(["alarm_control_panel","alert","automation","binary_sensor","calendar","camera","climate","cover","device_tracker","fan","group","humidifier","input_boolean","lawn_mower","light","lock","media_player","person","plant","remote","schedule","script","siren","sun","switch","timer","update","vacuum","valve","water_heater"]),Ve={cooling:"cool",defrosting:"heat",drying:"dry",fan:"fan_only",heating:"heat",idle:"off",off:"off",preheating:"heat"},oi=m=>{let t=Number(m);if(!Number.isNaN(t))return t>=70?"--state-sensor-battery-high-color":t>=30?"--state-sensor-battery-medium-color":"--state-sensor-battery-low-color"},ri=m=>Array.isArray(m)?m.slice().reverse().reduce((t,e)=>"var("+e+(t?", "+t:"")+")",void 0):"var("+m+")",ai=(m,t="_")=>m==null?"unknown":String(m).toLowerCase().replace(/\\s+/g,t).replace(/[^a-z0-9_]+/g,t).replace(new RegExp(t+"+","g"),t).replace(new RegExp("^"+t+"|"+t+"$","g"),"")||"unknown",jt=m=>m.split(".")[0],li=m=>{let t=m?.attributes?.entity_id||[],e=[...new Set(t.map(i=>jt(i)))];return e.length===1?e[0]:void 0},ci=m=>m===ce||m===si,Bt={header:[],cells:[{type:"entity",value:"@entity",entity_display:"icon",align:"center"},{type:"string",value:"@friendly_name",align:"left"},{type:"entity",value:"@entity",use_entity_unit:!0}]},Nt=m=>{try{return structuredClone(m)}catch{}return m===void 0?void 0:JSON.parse(JSON.stringify(m))},ui=(m,t)=>{let e=jt(m.entity_id),i=t!==void 0?t:m?.state;if(["button","event","input_button","scene"].includes(e))return i!==ce;if(ci(i)||i===ni&&e!=="alert")return!1;switch(e){case"alarm_control_panel":return i!=="disarmed";case"alert":return i!=="idle";case"cover":return i!=="closed";case"device_tracker":case"person":return i!=="not_home";case"lawn_mower":return["mowing","error"].includes(i);case"lock":return i!=="locked";case"media_player":return i!=="standby";case"vacuum":return!["idle","docked","paused"].includes(i);case"valve":return i!=="closed";case"plant":return i==="problem";case"group":return["on","home","open","locked","problem"].includes(i);case"timer":return i==="active";case"camera":return i==="streaming";default:return!0}},di=(m,t,e,i)=>{let s=[],n=ai(e,"_"),r=i?"active":"inactive";return t&&s.push("--state-"+m+"-"+t+"-"+n+"-color"),s.push("--state-"+m+"-"+n+"-color"),s.push("--state-"+m+"-"+r+"-color"),s.push("--state-"+r+"-color"),s},Ue=(m,t,e)=>di(m,t.attributes?.device_class,e!==void 0?e:t.state,ui(t,e)),hi=(m,t)=>{let e=t!==void 0?t:m?.state,i=jt(m.entity_id),s=m.attributes?.device_class;if(i==="sensor"&&s==="battery"){let n=oi(e);if(n)return[n]}if(i==="group"){let n=li(m);if(n&&Oe.has(n))return Ue(n,m,t)}if(Oe.has(i))return Ue(i,m,t)},Be=(m,t)=>{if((t!==void 0?t:m?.state)===ce)return"var(--state-unavailable-color)";let i=hi(m,t);return i?ri(i):void 0},pi=m=>{let t=m?.attributes?.brightness;return typeof t=="number"&&jt(m.entity_id)!=="plant"?"brightness("+(t+245)/5+"%)":""},Ht={color:"#d0d7de",background:"",style:"solid",thickness:1,length:"100%",align:"stretch",opacity:1,margin_top:0,margin_bottom:0},le=class extends nt{static properties={config:{},hass:{}};static styles=vt`
    .card {
      background: var(--ha-card-background, var(--card-background-color, #fff));
      color: var(--primary-text-color);
      border-radius: var(--ha-card-border-radius, 12px);
      overflow: hidden;
      font-size: 16px;
    }
    .wrap { width: 100%; border-radius: inherit; overflow: hidden; }
    .scroller { width: 100%; display: block; }
    .datatable { width: auto; min-width: 100%; border-collapse: collapse; }
    td, th { padding: 0; vertical-align: middle; white-space: nowrap; }
    thead th {
      font-weight: 700; text-align: left;
      background: color-mix(in srgb, var(--primary-text-color) 6%, transparent);
      border-bottom: 1px solid var(--divider-color, rgba(0,0,0,.12));
    }
    .datatable.zebra tbody tr.fc-zebra-alt td {
      background: color-mix(in srgb, var(--primary-text-color) 6%, transparent);
    }
    .fcc-preview-stack {
      display: grid;
      gap: 16px;
    }
    .fcc-template-card {
      position: relative;
    }
    .fcc-template-cell {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      flex-wrap: nowrap;
    }
    .fcc-template-row {
      display: inline-flex;
      align-items: stretch;
      flex-wrap: nowrap;
    }

    /* === NEW: blokada zaznaczania/kontekstu tylko dla klikanych pól === */
    .clickable, .icon.clickable, td.clickable, th.clickable {
      cursor: pointer;
      user-select: none;
      -webkit-user-select: none;
      -webkit-touch-callout: none;
      /* nie ustawiamy touch-action:none, żeby nie zabić scrolla; to wystarcza */
    }

    .icon ha-icon { color: var(--state-icon-color, var(--primary-text-color)); }
    .celltext { display: inline-block; white-space: nowrap; }
    .datatable td, .datatable th { line-height: 1.15; }
    .fc-separator-row td {
      padding: 0 !important;
      background: transparent;
    }
    .fc-separator-line {
      display: block;
      height: 0;
      border: none;
    }
  
    .icon-mask { display:inline-block; vertical-align:middle; }
    .fc-entity-icon-text {
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }
    /* === Simple HA input controls === */
    .ctrl-wrap { display:inline-flex; align-items:center; gap:8px; touch-action: pan-y; }
    .ctrl-range { width: 160px; vertical-align: middle; touch-action: pan-y !important; }
    .ctrl-range-color {
      width: 160px;
      height: 12px;
      appearance: none;
      -webkit-appearance: none;
      background: linear-gradient(90deg,
        #ff0000 0%,
        #ffcc00 10%,
        #ffff00 16.66%,
        #00ff00 33.33%,
        #00ffff 50%,
        #0000ff 66.66%,
        #ff00ff 83.33%,
        #ff0000 100%);
      border-radius: 999px;
      outline: none;
    }
    .ctrl-range-color::-webkit-slider-runnable-track {
      height: 12px;
      background: transparent;
      border-radius: 999px;
      border: 1px solid var(--divider-color,#ccc);
    }
    .ctrl-range-color::-webkit-slider-thumb {
      -webkit-appearance: none;
      appearance: none;
      width: 18px;
      height: 18px;
      border-radius: 50%;
      border: 2px solid #fff;
      box-shadow: 0 0 0 1px rgba(0,0,0,0.15);
      background: #fff;
      cursor: pointer;
      margin-top: -4px;
    }
    .ctrl-range-color::-moz-range-track {
      height: 12px;
      background: transparent;
      border-radius: 999px;
      border: 1px solid var(--divider-color,#ccc);
    }
    .ctrl-range-color::-moz-range-progress { background: transparent; }
    .ctrl-range-color::-moz-range-thumb {
      width: 18px;
      height: 18px;
      border-radius: 50%;
      border: 2px solid #fff;
      box-shadow: 0 0 0 1px rgba(0,0,0,0.15);
      background: #fff;
      cursor: pointer;
    }
    .ctrl-color-swatch {
      width: 18px;
      height: 18px;
      border-radius: 4px;
      border: 1px solid rgba(0,0,0,0.12);
      box-shadow: inset 0 0 0 1px rgba(255,255,255,0.3);
    }
    .ctrl-select, .ctrl-input { padding: 4px 6px; border: 1px solid var(--divider-color,#ddd); border-radius: 6px; background: var(--card-background-color,#fff); }
    .ctrl-button {
      padding: 6px 10px;
      border-radius: 8px;
      border: 1px solid var(--divider-color,#ddd);
      background: var(--primary-background-color, #f7f7f7);
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }
    .ctrl-button ha-icon {
      --mdc-icon-size: 18px;
    }
    .ctrl-switch { vertical-align: middle; }
    .ctrl-input[type="date"],
    .ctrl-input[type="time"],
    .ctrl-input[type="datetime-local"],
    .ctrl-select {
      width: auto !important;
    }
`;constructor(){super(),this._numberControlDrafts=new Map,this._attrControlDrafts=new Map,this._attrActivePointers=new Set,this._attrDraftTimestamps=new Map,this._customTemplateCache=new Map,this._narrowMedia=null,this._onNarrowMediaChange=null,this._onLocalesLoaded=null}connectedCallback(){super.connectedCallback(),this._onLocalesLoaded||(this._onLocalesLoaded=()=>this.requestUpdate()),window.addEventListener("fcc-locales-loaded",this._onLocalesLoaded)}setConfig(t){this._customTemplateCache=new Map;let e=(()=>{let l=t?.entity_row_template?.cells;return Array.isArray(l)&&l.length?l.length:Array.isArray(Bt.cells)&&Bt.cells.length?Bt.cells.length:1})(),i=(()=>{if(Array.isArray(t.rows)){for(let l of t.rows)if(Array.isArray(l?.cells)&&l.cells.length)return l.cells.length}return Array.isArray(t.entities)&&t.entities.length?e:1})(),s=Number.isInteger(t.column_count)&&t.column_count>0?t.column_count:i,r={...{top:4,right:0,bottom:4,left:0},...t.cell_padding||{}},a=!!t.custom_template_enabled,o=typeof t.custom_template_html=="string"?t.custom_template_html:"";this.config={overflow_x:!0,header_from_first_row:!1,zebra:!1,column_widths:void 0,hide_on_narrow:void 0,cell_padding:r,...t,column_count:s,custom_template_enabled:a,custom_template_html:o},this._setupNarrowMediaListener()}disconnectedCallback(){window.removeEventListener("fcc-locales-loaded",this._onLocalesLoaded),this._teardownNarrowMediaListener(),super.disconnectedCallback()}_normalizeAutoEntity(t){return t?typeof t=="string"?{entity:t}:typeof t=="object"&&t.entity?{...t,entity:t.entity}:null:null}_resolveAutoEntityMeta(t){let e=this._normalizeAutoEntity(t);if(!e?.entity)return null;let i=this.hass?.states?.[e.entity],s={...i?.attributes||{},...e.attributes||{}},n=e.name??s.friendly_name??e.entity,r=e.icon??s.icon??"",a=e.state??i?.state??"";return{entity:e.entity,friendly_name:n,name:n,icon:r,state:a,attributes:s}}_normalizeEntityTemplate(t){let e=t&&typeof t=="object"?t:{},s=(Array.isArray(e.cells)&&e.cells.length?e.cells:Bt.cells).map(o=>{let l=Nt(o)||{};if(l.type||(l.type="string"),!l.align){let c=l.type==="icon"||l.type==="entity"&&l.entity_display==="icon";l.align=c?"center":"left"}return l}),n=s.length||1,a=(Array.isArray(e.header)?e.header.slice(0,n):[]).map(o=>{let l=Nt(o)||{type:"string",value:""};return l.type||(l.type="string"),l.value===void 0&&(l.value=""),l});for(;a.length&&a.length<n;)a.push({type:"string",value:""});return{header:a,cells:s,colCount:n}}_applyTemplateTokens(t,e){if(t==null||typeof t!="string")return t;let i=e?.attributes||{},s=(r,a)=>{let o=i[a];return o==null?"":typeof o=="object"?JSON.stringify(o):String(o)},n=t.replace(/@attr:([a-zA-Z0-9_]+)/g,s);return n=n.replace(/@friendly_name/g,e?.friendly_name??e?.name??""),n=n.replace(/@name/g,e?.name??e?.friendly_name??""),n=n.replace(/@entity/g,e?.entity??""),n=n.replace(/@state/g,e?.state??""),n=n.replace(/@icon/g,e?.icon??""),n}_applyTokensToAction(t,e){if(!t||typeof t!="object")return t;let i=Nt(t)||{};if(i.entity&&(i.entity=this._applyTemplateTokens(i.entity,e)),i.navigation_path&&(i.navigation_path=this._applyTemplateTokens(i.navigation_path,e)),i.url_path&&(i.url_path=this._applyTemplateTokens(i.url_path,e)),i.service&&(i.service=this._applyTemplateTokens(i.service,e)),i.data&&typeof i.data=="object"){let s=Nt(i.data);Object.keys(s||{}).forEach(n=>{s[n]=this._applyTemplateTokens(s[n],e)}),i.data=s}if(i.target&&typeof i.target=="object"){let s={...i.target};s.entity_id&&(s.entity_id=this._applyTemplateTokens(s.entity_id,e)),i.target=s}return i.perform_action&&typeof i.perform_action=="object"&&(i.perform_action=this._applyTokensToAction(i.perform_action,e)),i}_materializeTemplateCell(t,e){let i=Nt(t)||{type:"string",value:""};return i.value=this._applyTemplateTokens(i.value,e),i.attribute!==void 0&&(i.attribute=this._applyTemplateTokens(i.attribute,e)),i.entity!==void 0&&(i.entity=this._applyTemplateTokens(i.entity,e)),i.text!==void 0&&(i.text=this._applyTemplateTokens(i.text,e)),i.tap_action&&(i.tap_action=this._applyTokensToAction(i.tap_action,e)),i.hold_action&&(i.hold_action=this._applyTokensToAction(i.hold_action,e)),i.double_tap_action&&(i.double_tap_action=this._applyTokensToAction(i.double_tap_action,e)),i}_buildRowsFromEntities(t){let e=Array.isArray(t.entities)?t.entities:[];if(!e.length)return null;let i=this._normalizeEntityTemplate(t.entity_row_template),s=[],n=i.header.length>0;n&&s.push({cells:i.header});for(let r of e){let a=this._resolveAutoEntityMeta(r);if(!a?.entity)continue;let o=i.cells.map(l=>this._materializeTemplateCell(l,a));s.push({cells:o})}return{rows:s,colCount:i.colCount||1,hasHeader:n}}_normalizeHideColumns(t,e){let i=Number.isInteger(e)&&e>0?e:0;if(!Array.isArray(t)||!t.length||i===0)return[];let s=new Set,n=[];return t.forEach(r=>{let a=Number(r);if(!Number.isInteger(a)||a<=0)return;let o=a-1;o<0||o>=i||s.has(o)||(s.add(o),n.push(o))}),n.sort((r,a)=>r-a)}_setupNarrowMediaListener(){if(this._teardownNarrowMediaListener(),typeof window>"u"||typeof window.matchMedia!="function")return;let t=this.config||{},e=parseInt(t.narrow_breakpoint,10);if(!(!Number.isFinite(e)||e<=0))try{let i=window.matchMedia(`(max-width: ${e}px)`),s=()=>this.requestUpdate();typeof i.addEventListener=="function"?i.addEventListener("change",s):typeof i.addListener=="function"&&i.addListener(s),this._narrowMedia=i,this._onNarrowMediaChange=s}catch{this._narrowMedia=null,this._onNarrowMediaChange=null}}_teardownNarrowMediaListener(){if(!this._narrowMedia||!this._onNarrowMediaChange){this._narrowMedia=null,this._onNarrowMediaChange=null;return}try{typeof this._narrowMedia.removeEventListener=="function"?this._narrowMedia.removeEventListener("change",this._onNarrowMediaChange):typeof this._narrowMedia.removeListener=="function"&&this._narrowMedia.removeListener(this._onNarrowMediaChange)}catch{}this._narrowMedia=null,this._onNarrowMediaChange=null}_getActiveHiddenColumns(t){let e=this.config||{},i=this._normalizeHideColumns(e.hide_on_narrow,t);if(!i.length)return[];let s=parseInt(e.narrow_breakpoint,10);if(!Number.isFinite(s)||s<=0)return[];if(this._narrowMedia&&typeof this._narrowMedia.matches=="boolean")return this._narrowMedia.matches?i:[];if(typeof window>"u")return[];if(typeof window.matchMedia!="function")return typeof window.innerWidth=="number"&&Number.isFinite(window.innerWidth)?window.innerWidth<=s?i:[]:[];try{return window.matchMedia(`(max-width: ${s}px)`).matches?i:[]}catch{return[]}}updated(t){if(super.updated(t),t.has("hass")&&this._numberControlDrafts&&this._numberControlDrafts.size){let e=this.hass?.states||{},i=!1;for(let[s,n]of[...this._numberControlDrafts.entries()]){if(this._activeNumberInputs&&this._activeNumberInputs.has(s))continue;let r=e[s];if(!r){this._numberControlDrafts.delete(s),i=!0;continue}let a=r.state==null?"":String(r.state);if(n===a){this._numberControlDrafts.delete(s),i=!0;continue}let o=Number(n),l=Number(r.state);Number.isFinite(o)&&Number.isFinite(l)&&Math.abs(o-l)<=Number.EPSILON*100&&(this._numberControlDrafts.delete(s),i=!0)}i&&this.requestUpdate()}if(t.has("hass")&&this._attrControlDrafts&&this._attrControlDrafts.size){let e=this.hass?.states||{},i=!1;for(let[s,n]of[...this._attrControlDrafts.entries()]){if(this._attrActivePointers&&this._attrActivePointers.has(s))continue;let{entityId:r,attrPath:a}=this._parseAttrEditKey(s);if(!r){this._attrControlDrafts.delete(s),i=!0;continue}let o=e[r];if(!o){this._attrControlDrafts.delete(s),i=!0;continue}let l=this._buildEntityValueTree(o),c=a?this._resolveEntityValuePath(o,a,l):void 0;if(c==null){this._attrControlDrafts.delete(s),this._attrDraftTimestamps&&this._attrDraftTimestamps.delete(s),i=!0;continue}let u=n&&typeof n=="object"?n.actual!==void 0?n.actual:n.display:n;if(this._attrValuesEqual(c,u))this._attrControlDrafts.delete(s),this._attrDraftTimestamps&&this._attrDraftTimestamps.delete(s),i=!0;else{let h=this._attrDraftTimestamps?this._attrDraftTimestamps.get(s):null,p=Date.now();h&&p-h>1700&&(this._attrControlDrafts.delete(s),this._attrDraftTimestamps&&this._attrDraftTimestamps.delete(s),i=!0)}}i&&this.requestUpdate()}}_openMoreInfo(t){t&&this.dispatchEvent(new CustomEvent("hass-more-info",{detail:{entityId:t},bubbles:!0,composed:!0}))}_onEntityKeydown(t,e){(t.key==="Enter"||t.key===" ")&&(t.preventDefault(),this._openMoreInfo(e))}_isNumericState(t){let e=Number(t);return Number.isFinite(e)}_getByPath(t,e){if(!t||!e)return;let i=String(e).replace(/\[(\d+)\]/g,".$1").split(".").filter(Boolean),s=t;for(let n of i){let r=Array.isArray(s)&&/^\d+$/.test(n)?Number(n):n;if(s==null||!(r in s))return;s=s[r]}return s}_buildEntityValueTree(t){if(!t)return null;let e=t.attributes||{},i={...e,attributes:e,entity_id:t.entity_id,state:t.state,last_changed:t.last_changed,last_updated:t.last_updated};return t.context!==void 0&&(i.context=t.context),i}_resolveEntityValuePath(t,e,i){if(!t||e===void 0||e===null)return;let s=i||this._buildEntityValueTree(t);if(s)return this._getByPath(s,String(e))}_buildDateForInputDatetime(t){if(!t)return null;let e=t.attributes||{},i=!!e.has_date,s=!!e.has_time,n=typeof t.state=="string"?t.state:"",r=null;if(i||s){let a,o,l;if(i){let p=n.match(/(\d{4})-(\d{2})-(\d{2})/);p&&(a=Number(p[1]),o=Number(p[2]),l=Number(p[3]))}let c=0,u=0,h=0;if(s){let p=n.match(/(\d{2}):(\d{2})(?::(\d{2}))?/);p&&(c=Number(p[1]),u=Number(p[2]),h=Number(p[3]||"0"))}if(i){let p=new Date(a||1970,(o||1)-1,l||1,s?c:0,s?u:0,s?h:0);Number.isNaN(p.getTime())||(r=p)}else if(s){let p=new Date,b=new Date(p.getFullYear(),p.getMonth(),p.getDate(),c,u,h);Number.isNaN(b.getTime())||(r=b)}}return r||this._parseDateLikeValue(n)}_parseDateLikeValue(t){if(t==null)return null;if(t instanceof Date)return Number.isNaN(t.getTime())?null:new Date(t.getTime());if(typeof t=="number"){if(!Number.isFinite(t))return null;let i=Math.abs(t)>=1e12?t:t*1e3,s=new Date(i);return Number.isNaN(s.getTime())?null:s}if(typeof t=="string"){let e=t.trim();if(!e)return null;let i=e.includes("T")?e:e.replace(" ","T"),s=Date.parse(i);if(!Number.isNaN(s))return new Date(s);let n=Number(e);if(Number.isFinite(n))return this._parseDateLikeValue(n)}return null}_formatDateWithPattern(t,e,i=""){if(!e)return null;let s=t instanceof Date&&!Number.isNaN(t.getTime()),n=i==null?"":String(i),r=s?this?.hass?.locale?.language||this?.hass?.language||(typeof navigator<"u"?navigator.language:"en")||"en":void 0,a=["YYYY","MMMM","REL_SHORT","REL","YY","MM","M","DD","D","HH","H","hh","h","mm","m","ss","s","RAW"],o={RAW:n};if(s){let l=t.getHours();Object.assign(o,{YYYY:String(t.getFullYear()),MMMM:new Intl.DateTimeFormat(r,{month:"long"}).format(t),REL_SHORT:this._formatRelativeDurationText(t,r,{short:!0}),REL:this._formatRelativeDurationText(t,r),YY:String(t.getFullYear()).slice(-2).padStart(2,"0"),MM:String(t.getMonth()+1).padStart(2,"0"),M:String(t.getMonth()+1),DD:String(t.getDate()).padStart(2,"0"),D:String(t.getDate()),HH:String(l).padStart(2,"0"),H:String(l),hh:String(l%12||12).padStart(2,"0"),h:String(l%12||12),mm:String(t.getMinutes()).padStart(2,"0"),m:String(t.getMinutes()),ss:String(t.getSeconds()).padStart(2,"0"),s:String(t.getSeconds())})}try{let l=String(e||""),c="";for(let u=0;u<l.length;){let h=l[u];if(h==="["){let b=l.indexOf("]",u+1);if(b===-1){c+="[",u+=1;continue}c+=l.slice(u+1,b),u=b+1;continue}let p=!1;for(let b of a)if(l.startsWith(b,u)&&Object.prototype.hasOwnProperty.call(o,b)){c+=o[b],u+=b.length,p=!0;break}p||(c+=h,u+=1)}return c}catch{return null}}_formatRelativeDurationText(t,e,i={}){if(!(t instanceof Date)||Number.isNaN(t.getTime()))return"";let n=Date.now()-t.getTime();if(!Number.isFinite(n))return"";let r=Math.abs(n),a=!!i?.short;if(r<1e3)try{return new Intl.RelativeTimeFormat(e||void 0,{numeric:"auto"}).format(0,"second")}catch{return"now"}let o=[{unit:"year",ms:365*24*60*60*1e3},{unit:"month",ms:720*60*60*1e3},{unit:"week",ms:10080*60*1e3},{unit:"day",ms:1440*60*1e3},{unit:"hour",ms:3600*1e3},{unit:"minute",ms:60*1e3},{unit:"second",ms:1e3}],l=o.find(b=>r>=b.ms)||o[o.length-1],c=[],u=Math.max(1,Math.floor(r/l.ms)),h=this._formatRelativeDurationUnit(u,l.unit,e,a);h&&c.push(h);let p=r-u*l.ms;for(let b=o.indexOf(l)+1;b<o.length&&c.length<2;b+=1){let $=o[b];if(p>=$.ms){let y=Math.floor(p/$.ms);if(y>0){let E=this._formatRelativeDurationUnit(y,$.unit,e,a);E&&c.push(E),p-=y*$.ms}}}return c.join(" ")}_formatRelativeDurationUnit(t,e,i,s=!1){if(!Number.isFinite(t)||t<=0)return"";try{let n=new Intl.NumberFormat(i||void 0,{style:"unit",unit:e,unitDisplay:s?"narrow":"long",maximumFractionDigits:0}).format(t);return s&&(n=n.replace(/[\s\u00A0\u202F]+/g,"").replace(/[\u2010\u2011\u2012\u2013\u2014-]+/g,"").replace(/\./g,"")),n}catch{if(s){let o={year:"y",month:"mo",week:"w",day:"d",hour:"h",minute:"m",second:"s"}[e]||(e?e[0]:"");return`${t}${o}`}return`${t} ${e}${t===1?"":"s"}`}}_literalizePattern(t){if(!t)return"";let e=String(t),i="";for(let s=0;s<e.length;){let n=e[s];if(n==="["){let r=e.indexOf("]",s+1);if(r===-1){i+=n,s+=1;continue}i+=e.slice(s+1,r),s=r+1;continue}i+=n,s+=1}return i}_formatCellDateValue(t,e,i,s){let n=t?.datetime_format;if(!n)return null;let r=i==null?"":String(i),a=null;if(s||String(t?.value||"").startsWith("input_datetime.")&&(a=this._buildDateForInputDatetime(e)),a||(a=this._parseDateLikeValue(i)),a){let l=this._formatDateWithPattern(a,n,r);if(l!=null)return l}let o=this._formatDateWithPattern(null,n,r);return o??this._literalizePattern(n)}_rescaleIfConfigured(t,e){let i=Number(t?.scale_in_min),s=Number(t?.scale_in_max),n=Number(t?.scale_out_min),r=Number(t?.scale_out_max);if(![i,s,n,r].every(Number.isFinite)||i===s)return e;let a=(e-i)/(s-i);return a=Math.max(0,Math.min(1,a)),n+a*(r-n)}_rescaleOutputToInput(t,e){let i=Number(t?.scale_in_min),s=Number(t?.scale_in_max),n=Number(t?.scale_out_min),r=Number(t?.scale_out_max);if(![i,s,n,r].every(Number.isFinite)||n===r)return e;let a=(Number(e)-n)/(r-n),o=Math.max(0,Math.min(1,a));return i+o*(s-i)}_normalizePrecision(t){if(t==null||t==="")return null;let e=Number(t);return Number.isInteger(e)&&e>=0?e:null}_inferFractionDigits(t){if(!Number.isFinite(t))return 0;let e=Math.abs(t),i=e.toString();if((i.includes("e")||i.includes("E"))&&(i=e.toPrecision(6)),!i.includes("."))return 0;let n=i.split(".")[1].replace(/0+$/,"");return Math.max(0,Math.min(n.length,6))}_normalizeLocaleCode(t){if(typeof t!="string"||!t.length)return;let e=t.trim(),i=e.indexOf("@");i!==-1&&(e=e.slice(0,i));let s=e.indexOf(".");return s!==-1&&(e=e.slice(0,s)),e=e.replace(/_/g,"-"),e||void 0}_resolveNumberLocale(t,e){let i=typeof navigator<"u"&&navigator.language?navigator.language:void 0,s=this._normalizeLocaleCode(this?.hass?.language);switch((e||"language").toLowerCase().replace(/-/g,"_")){case"comma_decimal":return["en-US","en"];case"decimal_comma":return["de","es","it"];case"space_comma":return["fr","sv","cs"];case"system":return;case"language":case"auto":default:return this._normalizeLocaleCode(t?.language)||s||i||void 0}}_formatNumberByLocale(t,e){if(!Number.isFinite(t))return String(t);let i=this.hass?.locale,n=(typeof i?.number_format=="string"?i.number_format:"language").toLowerCase().replace(/-/g,"_"),r=this._normalizePrecision(e);if(n==="none")return r!==null?t.toFixed(r):String(t);let a=r!==null?r:this._inferFractionDigits(t),o=Math.min(Math.max(a,r!==null?r:0),20),l={useGrouping:!0,minimumFractionDigits:r!==null?r:0,maximumFractionDigits:o},c=this._resolveNumberLocale(i,n);try{let u=c||void 0;return new Intl.NumberFormat(u,l).format(t)}catch{return r!==null?t.toFixed(r):String(t)}}_sanitizeSortString(t){return t==null?"":String(t).trim()}_normalizeDynamicEntityDisplay(t){let e=typeof t=="string"?t.trim().toLowerCase():"";return e==="icon"||e==="icon_value"?e:"value"}_resolveDynamicEntityOverwrite(t,e){if(!e||(e.overwrite||"").toLowerCase()!=="entity")return null;let i=t?.type==="entity"?t?.value:"",s=e.overwrite_entity||e.entity||i||"";if(!s)return null;let n=this.hass?.states?.[s];if(!n)return null;let r=e.overwrite_attr!==void 0?e.overwrite_attr:e.attr;(r==null||r==="")&&s===(t?.value||"")&&t?.attribute&&(r=t.attribute);let a={type:"entity",value:s};t?.precision!==void 0&&(a.precision=t.precision),t?.scale!==void 0&&(a.scale=t.scale),e.overwrite_datetime_format!==void 0&&(a.datetime_format=e.overwrite_datetime_format);let o=(u,h)=>{if(h==null||h==="")return;let p=Number(h);Number.isFinite(p)&&(a[u]=p)};o("scale_in_min",e.overwrite_scale_in_min),o("scale_in_max",e.overwrite_scale_in_max),o("scale_out_min",e.overwrite_scale_out_min),o("scale_out_max",e.overwrite_scale_out_max),r!=null&&r!==""&&(a.attribute=String(r),a.use_entity_unit=!1),e.overwrite_unit!==void 0&&(a.unit=e.overwrite_unit);let l=this._normalizeDynamicEntityDisplay(e.overwrite_entity_display);return l!=="value"&&(a.entity_display=l),{display:this._formatEntityCell(a,n),stateObj:n,mode:l}}_getDynamicEntityOverwriteValue(t,e){let i=this._resolveDynamicEntityOverwrite(t,e);return i?i.display:""}_renderDynamicEntityContent(t,e,i){let s=this._resolveDynamicEntityOverwrite(t,e);if(!s)return null;let n=s.mode||"value",r=s.display!=null?String(s.display):"";if(n==="icon"||n==="icon_value"){let a=this._renderEntityIconTemplate(t,s.stateObj,e);if(n==="icon")return a||r;let o=i;if(o===void 0){let u=t?.style||{},h=u.underline===void 0?!1:!!u.underline,p=!!u.strike,b=[];h&&b.push("underline"),p&&b.push("line-through"),o=b.length?b.join(" "):"none"}let l=o&&o!=="none"?`text-decoration:${o}`:"",c=l?g`<span class="celltext" style=${l}>${r}</span>`:g`<span class="celltext">${r}</span>`;return a?g`<span class="fc-entity-icon-text">${a}${c}</span>`:c}return r}_renderIconWithOptionalText(t,e,i,s=null,n=void 0){let a=t!=null&&t!==""?g`<ha-icon style=${this._buildIconStyle(i,e,n)} icon="${t}"></ha-icon>`:null,o=e?.icon_text,l=o!=null?String(o):"",c=l!=="";if(!a&&!c)return"";let u=s&&s!=="none"?`text-decoration:${s}`:"",h=c?u?g`<span class="celltext" style=${u}>${l}</span>`:g`<span class="celltext">${l}</span>`:null;return a&&h?g`<span class="fc-entity-icon-text">${a}${h}</span>`:a||h||""}_resolveDynamicOverwriteContent(t,e,i){if(!e)return null;let s=(e.overwrite||"").toLowerCase();if(s==="icon"){let n=e.icon!=null?String(e.icon):"";return this._renderIconWithOptionalText(n,e,t,i)}if(s==="text")return e.text!=null?e.text:e.mask!=null?e.mask:"";if(s==="entity"){let n=this._renderDynamicEntityContent(t,e,i);return n!=null&&n!==""?n:e.mask!=null?e.mask:""}return s==="hide"||e.hide?e.mask!=null?e.mask:"":null}_resolveDisplayWithDynamics(t,e,i){if(!e)return t??"";let s=(e.overwrite||"").toLowerCase();if(s==="icon")return e.icon_text!==void 0&&e.icon_text!==null&&e.icon_text!==""?String(e.icon_text):e.icon!=null?String(e.icon):"";if(s==="text")return e.text!=null?String(e.text):e.mask!=null?String(e.mask):"";if(s==="entity"){let n=this._getDynamicEntityOverwriteValue(i,e);return n!=null&&n!==""?n:e.mask!=null?String(e.mask):""}return s==="hide"||e.hide?e.mask!=null?String(e.mask):"":t??""}_buildSortKey(t,e){let i=this._sanitizeSortString(t),s=this._sanitizeSortString(e!==void 0?e:i);return{primary:i.toLowerCase(),secondary:i,tertiary:s.toLowerCase()}}_getCellSortKey(t,e){let s=(Array.isArray(t?.cells)?t.cells:[])[e]??{type:"string",value:"",align:"right"},n=s?.type||"string";if(n==="icon"){let l=s?.value!=null?String(s.value):"",c=this._evaluateDynColor(s,n,l),u=this._resolveDisplayWithDynamics(l,c,s);return this._buildSortKey(u)}if(n==="entity"){let l=s?.value!=null?String(s.value):"",c=l?this.hass?.states?.[l]:void 0,u=c?this._formatEntityCell(s,c):"",h=u!=null?String(u):"",p=this._evaluateDynColor(s,n,h),b=this._resolveDisplayWithDynamics(h,p,s);return this._buildSortKey(b)}let r=s?.value!=null?String(s.value):"",a=this._evaluateDynColor(s,n,r),o=this._resolveDisplayWithDynamics(r,a,s);return this._buildSortKey(o)}_compareSortKeys(t,e,i){if(!t||!e)return 0;let s=i?-1:1,n=t.primary.localeCompare(e.primary,void 0,ae);return n!==0||(n=t.secondary.localeCompare(e.secondary,void 0,ae),n!==0)||(n=t.tertiary.localeCompare(e.tertiary,void 0,ae),n!==0)?n*s:0}_sortBodyRows(t,e,i){if(!Array.isArray(t)||!t.length||!Array.isArray(e)||!e.length)return t;let s=a=>{if(!a.length)return[];let o=a.map((l,c)=>({row:l,index:c,keys:e.map(u=>this._getCellSortKey(l,u))}));return o.sort((l,c)=>{for(let u=0;u<e.length;u+=1){let h=this._compareSortKeys(l.keys[u],c.keys[u],i);if(h!==0)return h}return l.index-c.index}),o.map(l=>l.row)},n=[],r=[];return t.forEach(a=>{(a?.type||"")==="separator"?(r.length&&(n.push(...s(r)),r=[]),n.push(a)):r.push(a)}),r.length&&n.push(...s(r)),n}_renderEntityControl(t,e,i){let s=(i||"").split(".")[0];if(s==="input_boolean"||s==="switch"){let n=e?.state==="on";return g`<label class="ctrl-wrap"><input class="ctrl-switch" type="checkbox" .checked=${n}
        @change=${r=>this._onToggleBoolean(i,!!r.target.checked)} /></label>`}if(s==="input_number"||s==="number"){let n=e?.attributes||{},r=Number(n.min),a=Number(n.max),o=Number.isFinite(r)?r:0,l=Number.isFinite(a)?a:100;if(l<o){let w=o;o=l,l=w}let c=n.step,u,h;if(c==="any"||c===void 0||c===null)u="any",h=null;else{let w=Number(c);Number.isFinite(w)&&w>0?(u=w,h=w):(u=1,h=1)}let p=Number.isFinite(h)&&Number.isInteger(h),$=(typeof n.mode=="string"?n.mode.trim().toLowerCase():"")==="box"?"box":"slider",y=this._getNumberDraft(i),E=Number(e?.state),A=Number.isFinite(E)?E:o;if(y!=null&&y!==""){let w=Number(y);Number.isFinite(w)&&(A=w)}if(A=this._clampNumber(A,o,l),$==="box"){let w=y??e?.state??"",x=String(w);if(p&&x&&x.includes(".")){let M=Number(x);Number.isFinite(M)&&Number.isInteger(Math.round(M))&&(x=String(Math.round(M)))}return g`<span class="ctrl-wrap">
          <input class="ctrl-input" type="number" min="${o}" max="${l}" step="${u}"
            .value=${Le(String(x))}
            @focus=${()=>this._onNumberFocus(i)}
            @blur=${()=>this._onNumberBlur(i)}
            @input=${M=>this._onNumberInput(M,i)}
            @change=${M=>this._onNumberChange(M,i,o,l,h)} />
        </span>`}let _=t?.show_control_value_right!==!1,v=e?{...e,state:String(A)}:{state:String(A),attributes:{},entity_id:i};return g`<span class="ctrl-wrap">
        <input class="ctrl-range" type="range" min="${o}" max="${l}" step="${u}"
          .value=${String(A)}
          @focus=${()=>this._onNumberFocus(i)}
          @blur=${()=>this._onNumberBlur(i)}
          @input=${w=>this._onNumberInput(w,i)}
          @change=${w=>this._onNumberChange(w,i,o,l,h)} />
        ${_?g`<span class="ctrl-value">${this._formatEntityCell(t,v)}</span>`:N}
      </span>`}if(s==="input_select"||s==="select"){let n=e?.attributes?.options,r=Array.isArray(n)?n.map(o=>String(o)):[],a=String(e?.state??"");return g`<select class="ctrl-select" .value=${a}
        @change=${o=>this._onSelectOption(i,o.target.value)}>
        ${r.map(o=>g`<option value="${o}" ?selected=${o===a}>${o}</option>`)}
      </select>`}if(s==="input_text"||s==="text"){let n=String(e?.state??"");return g`<input class="ctrl-input" type="text" .value=${n}
    @change=${r=>this._onSetText(i,r.target.value)} />`}if(s==="input_datetime"||s==="datetime"||s==="date"||s==="time"){let n=e?.attributes||{},r=i?.split?.(".")?.[0]||"",a=n.has_date,o=n.has_time,l=a!==void 0?!!a:r==="input_datetime"||r==="datetime"||r==="date",c=o!==void 0?!!o:r==="input_datetime"||r==="datetime"||r==="time",u=String(e?.state??""),h="";if(l&&c){let b=u.replace(" ","T").match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})(?::\d{2})?$/);h=b?`${b[1]}T${b[2]}`:""}else if(l){let p=u.match(/^(\d{4}-\d{2}-\d{2})$/);h=p?p[1]:""}else if(c){let p=u.match(/^(\d{2}:\d{2})(?::\d{2})?$/);h=p?p[1]:""}return l&&c?g`<input class="ctrl-input" type="datetime-local" .value=${h}
      @change=${p=>this._onSetDatetime(i,p.target.value)} />`:l?g`<input class="ctrl-input" type="date" .value=${h}
      @change=${p=>this._onSetDatetime(i,p.target.value)} />`:c?g`<input class="ctrl-input" type="time" .value=${h}
      @change=${p=>this._onSetDatetime(i,p.target.value)} />`:this._formatEntityCell(t,e)}if(s==="input_button"||s==="button"){let n=e?.attributes||{},r=n.friendly_name??n.name,a=r&&String(r)||d(this.hass,"editor.press")||"Press",o=n.icon?String(n.icon):"",l=o?g`<ha-icon icon="${o}"></ha-icon><span>${a}</span>`:a;return this._hasCellActions(t)?g`<button class="ctrl-button"
      @click=${u=>{u.stopPropagation()}}
      @pointerdown=${u=>this._onCellPointerDown(u,t,i)}
      @pointerup=${u=>this._onCellPointerUp(u,t,i)}
      @pointercancel=${u=>this._onCellPointerCancel(u)}
      @mouseleave=${u=>this._onCellPointerCancel(u)}
      @keydown=${u=>this._onCellKeydown(u,t,i)}>${l}</button>`:g`<button class="ctrl-button" @click=${u=>{u.stopPropagation(),u.preventDefault()}}>${l}</button>`}return this._formatEntityCell(t,e)}_renderAttributeEditControl(t,e,i){if(!i?.enabled)return null;let s=t?.value||"",n=this._attrKeyPath(t,i);if(!s||!n)return null;let r=this._attrEditKey(t),a=r?this._getAttrDraft(r):void 0,o=this._buildEntityValueTree(e),l=this._resolveEntityValuePath(e,n,o),c=t?.show_control_value_right!==!1,u=!i.service||!i.field||!s,h=this._attrEffectiveRange(t,i);if(i.control==="switch"){let P=typeof a?.display=="boolean"?a.display:null,j=P!==null?P:this._attrValuesEqual(l,i.checked)||!this._attrValuesEqual(l,i.unchecked)&&!!l,z=a&&a.actual!==void 0?a.actual:l,L=this._formatAttrDisplayValue(z,t);return g`<span class="ctrl-wrap">
        <input class="ctrl-switch" type="checkbox"
          .checked=${!!j}
          ?disabled=${u}
          @change=${K=>this._onAttrSwitchChange(K,t)} />
        ${c?g`<span class="ctrl-value">${L||""}</span>`:N}
      </span>`}let p=Number(l),b=Number.isFinite(p)?this._rescaleIfConfigured(t,p):p,$=a&&a.display!==void 0?a.display:null,y=$??b,E=Number.isFinite(h.min)?h.min:0,A=Number.isFinite(h.max)?h.max:1,_=Number.isFinite(h.step)&&h.step>0?h.step:"any";Number.isFinite(Number(y))||(y=E),y=Math.max(E,Math.min(A,Number(y)));let v=this._formatAttrDisplayValue(y,t),w=i.control==="color"?this._resolveColorSaturation(t,i,e,o,s):i.control==="color_sat"?Number(y):null,x=i.control==="color"?Number(y):i.control==="color_sat"?this._resolveColorHue(t,i,e,o):null,M=(i.control==="color"||i.control==="color_sat")&&c,V=M?g`<span class="ctrl-color-swatch" title="${x??""} / ${w??""}%" style="background: hsl(${x}, ${w}%, 50%);"></span>`:N,D=i.control==="color"||i.control==="color_sat"?"ctrl-range ctrl-range-color":"ctrl-range",k=i.control==="color_sat"?`background: linear-gradient(90deg, hsl(${x||0},0%,50%) 0%, hsl(${x||0},100%,50%) 100%);`:"";return g`<span class="ctrl-wrap">
      <input class=${D} type="range" min="${E}" max="${A}" step="${_}"
        .value=${String(y)}
        ?disabled=${u}
        style=${k}
        @pointerdown=${P=>this._onAttrSliderPointerDown(P,t)}
        @pointermove=${P=>this._onAttrSliderPointerMove(P,t)}
        @pointerup=${P=>this._onAttrSliderPointerUp(P,t)}
        @pointercancel=${P=>this._onAttrSliderPointerUp(P,t)}
        @input=${P=>this._onAttrSliderInput(P,t)}
        @change=${P=>this._onAttrSliderChange(P,t)} />
      ${M?V:c?g`<span class="ctrl-value">${v}</span>`:N}
    </span>`}_onToggleBoolean(t,e){let i=e?"turn_on":"turn_off",n=(t?.split?.(".")[0]||"input_boolean")==="switch"?"switch":"input_boolean";try{this.hass?.callService(n,i,{entity_id:t})}catch{}}_onSetNumber(t,e){if(!t)return;let s=(t?.split?.(".")[0]||"input_number")==="number"?"number":"input_number";try{this.hass?.callService(s,"set_value",{entity_id:t,value:e})}catch{}}_onNumberInput(t,e){if(!t||!e)return;t.stopPropagation?.();let i=t.target;i&&this._setNumberDraft(e,i.value??"")}_onNumberFocus(t){t&&(this._activeNumberInputs||(this._activeNumberInputs=new Set),this._activeNumberInputs.add(t))}_onNumberBlur(t){!t||!this._activeNumberInputs||this._activeNumberInputs.delete(t)}_onNumberChange(t,e,i,s,n){if(!t||!e)return;t.stopPropagation?.();let r=t.target;if(!r)return;let a=r.value??"",o=this._normalizeNumberValue(a,i,s,n);if(o===null){this._clearNumberDraft(e);let u=this.hass?.states?.[e]?.state,h=Number(u);r.value=Number.isFinite(h)?String(h):"";return}let l=Number(this.hass?.states?.[e]?.state);if(Number.isFinite(l)&&Math.abs(l-o)<=Number.EPSILON*100){this._clearNumberDraft(e),r.value=String(o);return}let c=String(o);r.value=c,this._setNumberDraft(e,c),this._onSetNumber(e,o)}_getNumberDraft(t){if(!(!t||!this._numberControlDrafts))return this._numberControlDrafts.get(t)}_setNumberDraft(t,e){t&&(this._numberControlDrafts||(this._numberControlDrafts=new Map),this._numberControlDrafts.get(t)!==e&&(this._numberControlDrafts.set(t,e),this.requestUpdate()))}_clearNumberDraft(t){!t||!this._numberControlDrafts||this._numberControlDrafts.delete(t)&&this.requestUpdate()}_attrEditKey(t){let e=t?.value||"";if(!e)return null;let i=this._normalizeAttrEditConfig(t),s=this._attrKeyPath(t,i);return`${e}||${s}`}_attrKeyPath(t,e){return e?.control==="color"?this._attrHuePath(t,e):e?.control==="color_sat"?this._attrSatPath(t,e):t?.attribute||e?.field||""}_attrHuePath(t,e){let i=e?.control==="color"||e?.control==="color_sat",s=e?.hue_path&&typeof e.hue_path=="string"?e.hue_path:"";if(s)return s;if(t?.attribute)return t.attribute;let n=e?.field||"";return n?i?`${n}.0`:n:""}_attrSatPath(t,e){let i=e?.control==="color"||e?.control==="color_sat",s=e?.sat_path&&typeof e.sat_path=="string"?e.sat_path:"";if(s)return s;if(!i)return"";let n=this._attrHuePath(t,e);if(n&&/(\.\d+|\[\d+\])$/.test(n)){let a=n.match(/(\.|\[)(\d+)(\])?$/);if(a){let[,o,l,c]=a,u=Number(l)+1;return`${n.slice(0,-a[0].length)}${o==="["?"[":"."}${u}${o==="["?"]":c||""}`}}let r=e?.field||"";return r?`${r}.1`:""}_snapSaturation(t){if(!Number.isFinite(t))return t;let e=Math.round(t*1e3)/1e3;return Math.abs(e-100)<=.5?100:Math.abs(e-0)<=.5?0:e}_resolveColorSaturation(t,e,i,s,n){let r=typeof e?.sat_path=="string"?e.sat_path.trim():"",a=r||"",o=a&&i?this._resolveEntityValuePath(i,a,s):void 0,l=Number.isFinite(e?.sat_fallback)?e.sat_fallback:100,c=n||"";if(this._lastSatByEntity||(this._lastSatByEntity=new Map),Number.isFinite(Number(o))){let p=this._snapSaturation(this._clampNumber(Number(o),0,100));return c&&this._lastSatByEntity.set(c,p),p}let u=c?this._lastSatByEntity.get(c):void 0;if(Number.isFinite(Number(u)))return this._snapSaturation(this._clampNumber(Number(u),0,100));let h=this._snapSaturation(this._clampNumber(l,0,100));return c&&this._lastSatByEntity.set(c,h),h}_resolveColorHue(t,e,i,s){let n=this._attrHuePath(t,e),r=n&&i?this._resolveEntityValuePath(i,n,s):void 0,a=t?.value||"";if(this._lastHueByEntity||(this._lastHueByEntity=new Map),Number.isFinite(Number(r))){let l=this._clampNumber(Number(r),0,360);return a&&this._lastHueByEntity.set(a,l),l}let o=a?this._lastHueByEntity.get(a):void 0;return Number.isFinite(Number(o))?this._clampNumber(Number(o),0,360):0}_parseAttrEditKey(t){if(!t)return{entityId:"",attrPath:""};let[e,...i]=String(t).split("||");return{entityId:e||"",attrPath:i.join("||")||""}}_getAttrDraft(t){if(!(!t||!this._attrControlDrafts))return this._attrControlDrafts.get(t)}_setAttrDraft(t,e){t&&(this._attrControlDrafts||(this._attrControlDrafts=new Map),this._attrControlDrafts.set(t,e),this._attrDraftTimestamps||(this._attrDraftTimestamps=new Map),this._attrDraftTimestamps.set(t,Date.now()),this.requestUpdate())}_clearAttrDraft(t){if(!t||!this._attrControlDrafts)return;let e=this._attrControlDrafts.delete(t);this._attrDraftTimestamps&&this._attrDraftTimestamps.delete(t),e&&this.requestUpdate()}_attrValuesEqual(t,e){if(t===e||(t==null||t==="")&&(e==null||e===""))return!0;let i=Number(t),s=Number(e);return Number.isFinite(i)&&Number.isFinite(s)?Math.abs(i-s)<=Number.EPSILON*100:String(t).trim()===String(e).trim()}_normalizeAttrEditConfig(t){let e=t?.attr_edit&&typeof t.attr_edit=="object"?t.attr_edit:{},i=typeof e.control=="string"?e.control.trim().toLowerCase():"slider",s=i==="switch"?"switch":["color","color-slider","color_hs"].includes(i)?"color":["color_sat","color-sat","color_saturation"].includes(i)?"color_sat":"slider",n=Number(e.min),r=Number(e.max),a=Number(e.step),o=s==="color"?void 0:Number.isFinite(n)?n:void 0,l=s==="color"?void 0:Number.isFinite(r)?r:void 0,c=s==="color"?void 0:Number.isFinite(a)&&a>0?a:void 0,u=s==="color"||s==="color_sat"?"hs_color":"",h=typeof e.field=="string"?e.field.trim():t?.attribute||u,p=s==="color"?this._stripIndexFromPath(h)||"hs_color":h,b=typeof e.service=="string"?e.service.trim():"",$=e.checked!==void 0?e.checked:!0,y=e.unchecked!==void 0?e.unchecked:!1,E=typeof e.hue_path=="string"?e.hue_path.trim():"",A=typeof e.sat_path=="string"?e.sat_path.trim():"",_=Number(e.sat_fallback),v=Number.isFinite(_)?_:100;return{enabled:e.enabled===!0,control:s,min:o,max:l>o?l:o,step:c,field:p,service:b,checked:$,unchecked:y,hue_path:E,sat_path:A,sat_fallback:v}}_stripIndexFromPath(t){if(typeof t!="string")return"";let e=t.trim();return e?e.replace(/(\.|\[)\d+(\])?$/,""):""}_normalizeAttrSliderValue(t,e){let i=Number(e?.min),s=Number(e?.max),n=Number(e?.step);return this._normalizeNumberValue(t,Number.isFinite(i)?i:void 0,Number.isFinite(s)?s:void 0,Number.isFinite(n)&&n>0?n:void 0)}_formatAttrDisplayValue(t,e){if(t==null)return"";if(Number.isFinite(Number(t))){let i=Number(t),s=this._formatNumberByLocale(i,e?.precision),n=e?.unit?` ${e.unit}`:"";return`${s}${n}`}return String(t)}_attrEffectiveRange(t,e){let i=Number(t?.scale_out_min),s=Number(t?.scale_out_max),n=Number.isFinite(i)&&Number.isFinite(s)&&i!==s;if(e?.control==="color")return{min:0,max:360,step:1};if(e?.control==="color_sat"){let l=Number.isFinite(e?.min)?Number(e.min):0,c=Number.isFinite(e?.max)?Number(e.max):100;n&&(l=i,c=s),(!Number.isFinite(c)||c===l)&&(c=l+1);let u=Number.isFinite(e?.step)&&e.step>0?Number(e.step):1;return{min:l,max:c,step:u}}let r=Number.isFinite(e?.min)?Number(e.min):void 0,a=Number.isFinite(e?.max)?Number(e.max):void 0;n&&(r=i,a=s),Number.isFinite(r)||(r=0),(!Number.isFinite(a)||a===r)&&(a=r+1);let o=Number.isFinite(e?.step)&&e.step>0?Number(e.step):void 0;if(!Number.isFinite(o)||o<=0){let l=Math.abs(a-r);o=l>0&&Number((l/100).toFixed(4))||.01}return{min:r,max:a,step:o}}_onAttrSliderPointerDown(t,e){let i=this._attrEditKey(e);if(!i)return;let s=this._normalizeAttrEditConfig(e),n=e?.value||"",r=n?this.hass?.states?.[n]:null,a=r?this._buildEntityValueTree(r):null,o=this._attrKeyPath(e,s),l=o&&r?this._resolveEntityValuePath(r,o,a):void 0,c=Number.isFinite(Number(l))?this._rescaleIfConfigured(e,Number(l)):void 0,u=Number.isFinite(c)?c:Number(t?.target?.value);this._setAttrDraft(i,{display:Number.isFinite(u)?u:void 0,actual:Number.isFinite(u)?this._rescaleOutputToInput(e,u):void 0}),this._attrActivePointers||(this._attrActivePointers=new Set),this._attrActivePointers.add(i);let h=Number.isFinite(u)?u:void 0,p={startX:t?.clientX??null,startY:t?.clientY??null,startValue:Number.isFinite(c)?c:h,allow:!1,blocked:!1};t?.target&&p.startValue!==void 0&&(t.target.value=String(p.startValue)),this._attrPointerGuards||(this._attrPointerGuards=new Map),this._attrPointerGuards.set(i,p)}_onAttrSliderPointerUp(t,e){let i=this._attrEditKey(e);!i||!this._attrActivePointers||(this._attrActivePointers.delete(i),this._attrPointerGuards&&this._attrPointerGuards.delete(i))}_onAttrSliderPointerMove(t,e){if(!t)return;let i=this._attrEditKey(e);if(!i||!this._attrPointerGuards)return;let s=this._attrPointerGuards.get(i);if(!s||s.allow)return;let n=t.clientX??0,r=t.clientY??0,a=s.startX!==null&&s.startX!==void 0?n-s.startX:0,o=s.startY!==null&&s.startY!==void 0?r-s.startY:0,l=6;if(Math.abs(o)>Math.abs(a)+l){s.blocked=!0,s.allow=!1,s.startValue!==void 0&&t.target&&(t.target.value=String(s.startValue)),t.stopPropagation?.();return}Math.abs(a)>Math.abs(o)+l&&(s.allow=!0)}_onAttrSliderInput(t,e){if(!t)return;t.stopPropagation?.();let i=this._attrEditKey(e);if(!i)return;let s=this._attrPointerGuards?this._attrPointerGuards.get(i):null;if(s&&s.blocked){s.startValue!==void 0&&t.target&&(t.target.value=String(s.startValue));return}if(s&&!s.allow&&t.pointerType==="touch")return;let n=t.target?.value??"",r=n===""?"":Number(n),a=Number.isFinite(r)?this._rescaleOutputToInput(e,r):r;this._setAttrDraft(i,{display:r,actual:a})}_onAttrSliderChange(t,e){if(!t)return;t.stopPropagation?.();let i=this._attrEditKey(e),s=this._attrPointerGuards?this._attrPointerGuards.get(i):null;if(s&&s.blocked){s.startValue!==void 0&&t.target&&(t.target.value=String(s.startValue)),this._clearAttrDraft(i);return}let n=this._normalizeAttrEditConfig(e);if(!n.enabled||!i)return;let r=t.target;if(!r)return;let a=r.value??"",o=this._attrEffectiveRange(e,n),l=this._normalizeAttrSliderValue(a,o),c=e?.value||"",u=c?this.hass?.states?.[c]:null,h=u?this._buildEntityValueTree(u):null,p=this._attrKeyPath(e,n),b=p&&u?this._resolveEntityValuePath(u,p,h):void 0;if(l===null){this._clearAttrDraft(i);let E=Number(b);r.value=Number.isFinite(E)?String(this._rescaleIfConfigured(e,E)):"";return}let $=Number(l),y=this._rescaleOutputToInput(e,$);r.value=String($),this._setAttrDraft(i,{display:$,actual:y}),this._callAttrEditService(e,y)}_onAttrSwitchChange(t,e){if(!t)return;t.stopPropagation?.();let i=this._attrEditKey(e),s=this._normalizeAttrEditConfig(e);if(!s.enabled||!i)return;let n=!!t.target?.checked,r=n?s.checked:s.unchecked;this._setAttrDraft(i,{display:n,actual:r}),this._callAttrEditService(e,r)}_callAttrEditService(t,e){let i=this._normalizeAttrEditConfig(t);if(!i.enabled)return;let s=i.service||"",[n,r]=s.includes(".")?s.split(".",2):["",""],a=t?.value||"",o=i.field||t?.attribute||"";if(!n||!r||!a||!o)return;let l=e;if(i.control==="color"){let u=this.hass?.states?.[a],h=u?this._buildEntityValueTree(u):null,p=this._resolveColorSaturation(t,i,u,h,a),b=Number.isFinite(i?.min)?Number(i.min):0,$=Number.isFinite(i?.max)?Number(i.max):360,y=this._clampNumber(Number(e),b,$);l=[y,p],this._lastHueByEntity||(this._lastHueByEntity=new Map),a&&this._lastHueByEntity.set(a,y)}else if(i.control==="color_sat"){let u=this.hass?.states?.[a],h=u?this._buildEntityValueTree(u):null,p=this._resolveColorHue(t,i,u,h),b=Number.isFinite(i?.min)?Number(i.min):0,$=Number.isFinite(i?.max)?Number(i.max):100,y=this._snapSaturation(this._clampNumber(Number(e),b,$));l=[p,y],this._lastSatByEntity||(this._lastSatByEntity=new Map),a&&this._lastSatByEntity.set(a,y)}let c={entity_id:a,[o]:l};try{this.hass?.callService(n,r,c)}catch{}}_clampNumber(t,e,i){let s=Number(t);return Number.isFinite(s)?(Number.isFinite(e)&&(s=Math.max(e,s)),Number.isFinite(i)&&(s=Math.min(i,s)),s):Number.isFinite(e)?e:Number.isFinite(i)?i:0}_normalizeNumberValue(t,e,i,s){if(t==null)return null;let n=String(t).trim();if(!n)return null;let r=n.replace(",","."),a=Number(r);if(!Number.isFinite(a))return null;let o=Number(e),l=Number(i);Number.isFinite(o)&&a<o&&(a=o),Number.isFinite(l)&&a>l&&(a=l);let c=Number(s);if(Number.isFinite(c)&&c>0){let u=Number.isFinite(o)?o:0,h=Math.round((a-u)/c);a=u+h*c,Number.isFinite(o)&&a<o&&(a=o),Number.isFinite(l)&&a>l&&(a=l);let p=Math.min(Math.max(this._inferFractionDigits(c),this._inferFractionDigits(u)),6);p>0&&(a=Number(a.toFixed(p))),Number.isFinite(o)&&a<o&&(a=o),Number.isFinite(l)&&a>l&&(a=l)}return Number.isFinite(a)?a:null}_rowCssClass(t){return`fcc-row-css-${t}`}_cellCssClass(t,e){return`fcc-cell-css-${t}-${e}`}_defaultRowCss(){return`tr {
   background-color: yellow;
   border: 2px dashed red;
}
`}_defaultCellCss(){return`th, td {
   background-color: yellow;
   border: 2px dashed red;
}
`}_collectCustomCss(t){let e=[];return Array.isArray(t)&&t.forEach((i,s)=>{if(i?.custom_css_enabled===!0){let r=typeof i.custom_css=="string"&&i.custom_css.trim()?i.custom_css:this._defaultRowCss(),a=this._scopeCss(r,`.${this._rowCssClass(s)}`,"row");a&&e.push(a)}(Array.isArray(i?.cells)?i.cells:[]).forEach((r,a)=>{if(r?.custom_css_enabled===!0){let o=typeof r.custom_css=="string"&&r.custom_css.trim()?r.custom_css:this._defaultCellCss(),l=this._scopeCss(o,`.${this._cellCssClass(s,a)}`,"cell");l&&e.push(l)}})}),e}_scopeCss(t,e,i="row"){let n=(typeof t=="string"?t:"").trim();if(!n)return"";let r=[],a=/([^{}]+)\{([^{}]*)\}/g,o;for(;(o=a.exec(n))!==null;){let l=o[1],c=o[2].trim();if(!l||!c)continue;let u=Array.from(new Set(l.split(",").map(h=>this._applyScopeToSelector(h,e,i)).filter(Boolean)));u.length&&r.push(`${u.join(", ")} { ${c} }`)}return r.join(`
`)}_applyScopeToSelector(t,e,i){if(!t)return"";let s=t.trim();if(!s||s.startsWith("@"))return"";if(s.includes(":host")&&(s=s.replace(/:host/g,e)),s.includes("&")&&(s=s.replace(/&/g,e)),i==="cell"){let n=s.match(/^(th|td)\b/i);if(n){let r=n[0],a=r.toLowerCase(),o=s.slice(n[0].length),l=o.trimStart(),c=/^\s/.test(o),u=l.length>0&&!c&&(l.startsWith(":")||l.startsWith(".")||l.startsWith("[")||l.startsWith("#")),h=$=>l?u?`${$}${l}`:`${$} ${l}`.trim():$,p=new Set;p.add(h(`${r}${e}`));let b=`.fcc-template-cell[data-fcc-origin="${a}"]${e}`;return p.add(h(b)),Array.from(p).filter(Boolean).join(", ")}}if(i==="row"){let n=s.match(/^tr\b/i);if(n){let a=s.slice(n[0].length).trim(),o=(b,$)=>{let y=typeof $=="string"?$.trim():"";if(!y)return b;let E=y[0];return E===":"||E==="."||E==="["||E==="#"?`${b}${y}`:E===">"||E==="+"||E==="~"?`${b} ${y}`:`${b} ${y}`.trim()},l=new Set;l.add(a?o(e,a):e);let u=(b=>b&&b.replace(/\btd\b/gi,'.fcc-template-cell[data-fcc-origin="td"]').replace(/\bth\b/gi,'.fcc-template-cell[data-fcc-origin="th"]'))(a),h=b=>{if(b)if(u&&u.trim()){l.add(o(b,u));let $=u.replace(/\s+(\.fcc-template-cell\b)/g,"$1");$!==u&&l.add(o(b,$))}else l.add(`${b}.fcc-template-row`)};h(e);let p=e.match(/\.fcc-row-css-(\d+)/);return p&&h(`[data-fcc-row-index="${p[1]}"]`),Array.from(l).filter(Boolean).join(", ")}}return s.startsWith(e)?s:`${e} ${s}`.replace(/\s+/g," ").trim()}_onSelectOption(t,e){let s=(t?.split?.(".")[0]||"input_select")==="select"?"select":"input_select";try{this.hass?.callService(s,"select_option",{entity_id:t,option:e})}catch{}}_formatEntityCell(t,e,i=!1){let s=!!t?.attribute,n;if(s){let l=t?.attribute,c=this._buildEntityValueTree(e);n=this._resolveEntityValuePath(e,l,c)}else{let l=String(t?.value||"").split(".")[0];if(l==="input_button"||l==="button"){let c=e?.attributes?.friendly_name??e?.attributes?.name;if(c!==void 0)return String(c)}n=e?.state}let r=n!=null,a;if(!r)a="n/a";else{let l=this._formatCellDateValue(t,e,n,s);if(l!==null)a=l;else if(this._isNumericState(n)){let c=Number(n);c=this._rescaleIfConfigured(t,c),a=this._formatNumberByLocale(c,t?.precision)}else{let c=typeof n=="object"?JSON.stringify(n):String(n);i?s&&this.hass?.formatEntityAttributeValue?a=this.hass.formatEntityAttributeValue(e,t?.attribute,n)??c:!s&&this.hass?.formatEntityState?a=this.hass.formatEntityState(e)??c:a=c:a=c}}let o="";return s?o=t?.unit??"":o=t?.use_entity_unit!==!1?e?.attributes?.unit_of_measurement??"":t?.unit??"",`${a}${o?` ${o}`:""}`}_coerceNumber(t){if(t==null)return NaN;if(typeof t=="number")return Number.isFinite(t)?t:NaN;let e=String(t).trim().replace(",","."),i=Number(e);return Number.isFinite(i)?i:NaN}_evaluateDynColor(t,e,i){let s=Array.isArray(t?.dyn_color)?t.dyn_color:[];if(!s.length)return null;let n={},r=new Map,a=(c,u)=>{if(!c||u===void 0||u===null)return;let h=c.entity_id,p=h?r.get(h):void 0;if(p||(p=this._buildEntityValueTree(c),h&&p&&r.set(h,p)),!!p)return this._resolveEntityValuePath(c,u,p)},o=c=>Array.isArray(c?.conditions)&&c.conditions.length?c.conditions:[{entity:c?.entity,attr:c?.attr,op:c?.op,val:c?.val,val2:c?.val2,src:c?.src}],l=c=>{let u=(c?.match||c?.condition_match||"").toLowerCase();return u==="any"||u==="or"?"any":"all"};for(let c of s){if(!c||typeof c!="object")continue;let u=o(c),h=l(c),p=$=>{let y=$?.op||c.op||"=",E=$?.entity??c.entity,A=$?.attr??c.attr,_=$?.val??c.val,v=$?.val2??c.val2,w=$?.src??c.src,x,M=!1;if(E){let S=this.hass?.states?.[E];x=A?a(S,A):S?.state,M=e==="entity"&&E===t?.value}else if(w){let S=w||"this_display";if(S==="this_display")x=i??t?.value??"";else if(S==="this_state")e==="entity"?x=this.hass?.states?.[t?.value]?.state:x=i??t?.value??"";else if(S==="this_attr"){if(e==="entity"){let k=this.hass?.states?.[t?.value];x=a(k,A)}}else if(S==="other_state")x=this.hass?.states?.[E]?.state;else if(S==="other_attr"){let k=this.hass?.states?.[E];x=a(k,A)}else x=i??t?.value??"";M=e==="entity"&&(S==="this_display"||S==="this_state"||S==="this_attr")}else x=i??t?.value??"",M=e==="entity";let V=y===">"||y===">="||y==="<"||y==="<="||y==="between",D=!1;if(V){let S=this._coerceNumber(x);if(M&&Number.isFinite(S)&&(S=this._rescaleIfConfigured(t,S)),!Number.isFinite(S))D=!1;else if(y==="between"){let k=this._coerceNumber(_),P=this._coerceNumber(v);if(Number.isFinite(k)&&Number.isFinite(P)){let j=Math.min(k,P),z=Math.max(k,P);D=S>=j&&S<=z}else D=!1}else{let k=this._coerceNumber(_);Number.isFinite(k)?y===">"?D=S>k:y===">="?D=S>=k:y==="<"?D=S<k:y==="<="&&(D=S<=k):D=!1}}else if(y==="contains"||y==="not_contains"){let S=String(x??"").toLowerCase(),k=String(_??"").toLowerCase();D=S.includes(k),y==="not_contains"&&(D=!D)}else{let S=this._coerceNumber(x),k=this._coerceNumber(_);if(Number.isFinite(S)&&Number.isFinite(k))D=S===k;else{let P=String(x??"").toLowerCase(),j=String(_??"").toLowerCase();D=P===j}y==="!="&&(D=!D)}return!!D},b=h!=="any";for(let $ of u){let y=p($);if(h==="any"){if(y){b=!0;break}}else if(!y){b=!1;break}}if(b){if(c.bg&&(n.bg=c.bg),c.fg&&(n.fg=c.fg),c.visibility){let y=String(c.visibility).toLowerCase();(y==="visible"||y==="hidden")&&(n.visibility=y)}let $=(c.overwrite||"").toLowerCase();$==="hide"?(n.hide=!0,n.mask="",n.overwrite="hide"):$==="text"?(n.hide=!0,n.mask=c.text||"",n.overwrite="text",n.text=c.text||""):$==="icon"?(n.hide=!0,n.overwrite="icon",n.icon=c.icon||"",c.icon_text!==void 0&&(n.icon_text=c.icon_text),c.icon_color!==void 0&&(n.icon_color=c.icon_color)):$==="entity"?(n.hide=!0,n.overwrite="entity",c.overwrite_entity!==void 0?n.overwrite_entity=c.overwrite_entity:c.entity!==void 0&&(n.overwrite_entity=c.entity),c.overwrite_attr!==void 0?n.overwrite_attr=c.overwrite_attr:c.attr!==void 0&&(n.overwrite_attr=c.attr),c.overwrite_datetime_format!==void 0&&(n.overwrite_datetime_format=c.overwrite_datetime_format),c.overwrite_entity_display!==void 0&&(n.overwrite_entity_display=c.overwrite_entity_display),c.overwrite_scale_in_min!==void 0&&(n.overwrite_scale_in_min=c.overwrite_scale_in_min),c.overwrite_scale_in_max!==void 0&&(n.overwrite_scale_in_max=c.overwrite_scale_in_max),c.overwrite_scale_out_min!==void 0&&(n.overwrite_scale_out_min=c.overwrite_scale_out_min),c.overwrite_scale_out_max!==void 0&&(n.overwrite_scale_out_max=c.overwrite_scale_out_max),c.overwrite_unit!==void 0&&(n.overwrite_unit=c.overwrite_unit)):(c.hide!==void 0&&(n.hide=!!c.hide),c.mask!==void 0&&(n.mask=c.mask))}}return n}_evaluateRowRules(t){let e=Array.isArray(t?.dyn_row_rules)?t.dyn_row_rules:[];if(!e.length)return null;let i={dyn_color:e},s=this._evaluateDynColor(i,"row",void 0);if(!s)return null;let n={};s.bg&&(n.bg=s.bg),s.fg&&(n.fg=s.fg);let r=typeof s.visibility=="string"?s.visibility.toLowerCase():null;return(r==="hidden"||r==="visible")&&(n.visibility=r),Object.keys(n).length?n:null}_buildTextStyle(t,e,i,s,n={}){let r=t?.style||{},a=this.config?.cell_padding||{top:4,right:0,bottom:4,left:0},o=[`padding:${a.top}px ${a.right}px ${a.bottom}px ${a.left}px`,`text-align:${i}`],l=r.underline===void 0?!1:!!r.underline,c=!!r.strike,u=[];l&&u.push("underline"),c&&u.push("line-through");let h=u.length?u.join(" "):"none";n?.skipTextDecoration||o.push(`text-decoration:${h}`),r.bold&&o.push("font-weight:700"),r.italic&&o.push("font-style:italic"),r.background&&o.push(`background:${r.background}`),r.color&&o.push(`color:${r.color}`);let p=this.config?.text_size;return r.font_size?o.push(`font-size:${r.font_size}`):p&&o.push(`font-size:${p}`),r.text_transform&&o.push(`text-transform:${r.text_transform}`),r.letter_spacing&&o.push(`letter-spacing:${r.letter_spacing}`),s&&s.bg&&o.push(`background:${s.bg}`),s&&s.fg&&o.push(`color:${s.fg}`),{style:o.join(";"),textDecoration:h}}_buildIconStyle(t,e,i=void 0){let s=t?.style||{},n=[],r=i?this._computeStateIconVisuals(i):null,a=!1,o=p=>{p&&(a=!0,n.push("color:"+p),n.push("--state-icon-color:"+p),n.push("--icon-color:"+p))},l=e?.icon_color,c=e?.fg,u=s.color;l?o(l):c?o(c):u?o(u):r?.color&&o(r.color),!a&&i&&o("var(--paper-item-icon-color, var(--state-icon-color, #44739e))"),r?.filter&&n.push("filter:"+r.filter);let h=s.icon_size||"";return h&&n.push("--mdc-icon-size:"+h),n.join(";")}_computeStateIconVisuals(t){if(!t)return{};let e=t.attributes||{},i=Be(t);if(Array.isArray(e.rgb_color)&&e.rgb_color.length===3)i=this._rgbToCss(e.rgb_color);else if(Array.isArray(e.hs_color)&&e.hs_color.length>=2){let r=this._hsbToRgb(e.hs_color[0],e.hs_color[1],1);i=this._rgbToCss(r)}let s=e.hvac_action;if(s&&Ve[s]){let r=Be(t,Ve[s]);r&&(i=r)}let n=pi(t)||"";return{color:i,filter:n}}_hsbToRgb(t,e,i){let n=((Number.isFinite(Number(t))?Number(t):0)%360+360)%360,r=Math.max(0,Math.min(1,Number(e)/100)),a=Math.max(0,Math.min(1,Number.isFinite(Number(i))?Number(i):1)),o=a*r,l=o*(1-Math.abs(n/60%2-1)),c=a-o,u=0,h=0,p=0;switch(Math.floor(n/60)){case 0:u=o,h=l,p=0;break;case 1:u=l,h=o,p=0;break;case 2:u=0,h=o,p=l;break;case 3:u=0,h=l,p=o;break;case 4:u=l,h=0,p=o;break;default:u=o,h=0,p=l;break}return[Math.round((u+c)*255),Math.round((h+c)*255),Math.round((p+c)*255)]}_rgbToCss(t,e){if(!Array.isArray(t)||t.length!==3)return"";let i=o=>Math.max(0,Math.min(255,Math.round(Number(o)||0))),[s,n,r]=[i(t[0]),i(t[1]),i(t[2])];if(e===void 0)return`rgb(${s}, ${n}, ${r})`;let a=Math.max(.2,Math.min(1,e));return a>=.999?`rgb(${s}, ${n}, ${r})`:`rgba(${s}, ${n}, ${r}, ${a.toFixed(3)})`}_getEntityDisplayMode(t){let e=t?.entity_display;return e==="icon"||e==="icon_value"?e:"value"}_renderEntityIconTemplate(t,e,i){let s=this._buildIconStyle(t,i,e);if(i?.overwrite==="icon"){let r=i.icon!=null?String(i.icon):"";return r?g`<ha-icon style=${s} icon="${r}"></ha-icon>`:""}if(!e)return"";if(customElements.get("ha-state-icon"))return g`<ha-state-icon style=${s} .hass=${this.hass} .stateObj=${e}></ha-state-icon>`;let n=e?.attributes?.icon;return n?g`<ha-icon style=${s} icon="${n}"></ha-icon>`:""}_buildEntityDisplayContent(t,e,i,s,n,r){let a=r||this._getEntityDisplayMode(t),o=i!=null?String(i):"",l=(s?.overwrite||"").toLowerCase();if(l==="icon"){let h=s?.icon!=null?String(s.icon):"";return this._renderIconWithOptionalText(h,s,t,n,e)}if(l==="text")return s?.text??s?.mask??"";if(l==="entity"){let h=this._renderDynamicEntityContent(t,s,n);return h!=null&&h!==""?h:s?.mask||""}if(l==="hide")return s?.mask||"";if(s?.hide)return s.mask||"";let u=a==="icon"||a==="icon_value"?this._renderEntityIconTemplate(t,e,s):null;if(a==="icon")return u||o;if(a==="icon_value"){let h=n;if(h===void 0){let $=t?.style||{},y=$.underline===void 0?!1:!!$.underline,E=!!$.strike,A=[];y&&A.push("underline"),E&&A.push("line-through"),h=A.length?A.join(" "):"none"}let p=h&&h!=="none"?`text-decoration:${h}`:"",b=p?g`<span class="celltext" style=${p}>${o}</span>`:g`<span class="celltext">${o}</span>`;return u?g`<span class="fc-entity-icon-text">${u}${b}</span>`:b}return o}_hasAction(t){return!!(t&&t.action&&t.action!=="none")}_sanitizeActionForCell(t,e){if(!e)return;let i=(t?.type||"string").toLowerCase(),s=e?.action;if(!((i==="icon"||i==="string")&&(s==="more-info"||s==="toggle")))return e}_getSanitizedActions(t){return{tap:this._sanitizeActionForCell(t,t?.tap_action),hold:this._sanitizeActionForCell(t,t?.hold_action),dbl:this._sanitizeActionForCell(t,t?.double_tap_action)}}_hasCellActions(t){let e=this._getSanitizedActions(t);return this._hasAction(e.tap)||this._hasAction(e.hold)||this._hasAction(e.dbl)}_tapActionIsExplicitNone(t){return t?t?.tap_action?.action==="none":!1}_ensureTarget(t,e){let i={...t||{}};return!i.entity_id&&e&&(i.entity_id=e),Object.keys(i).length?i:void 0}_callService(t,e,i,s){let n=s&&Object.keys(s).length?s:void 0;if(n&&n.entity_id){let a={...i||{}};return a.entity_id===void 0&&(a.entity_id=n.entity_id),this.hass?.callService(t,e,a)}return this.hass?.callService(t,e,i,n)}async _runPerformAction(t,e,i,s){let n=t;typeof t=="string"&&(n={service:t}),n=n||{};let r=n.action,a=this._ensureTarget(n.target||i,e),o=n.data||n.service_data||s||void 0;if(r==="toggle")return this._callService("homeassistant","toggle",void 0,a);if(r==="call_service"||r==="call-service"||n.service){let l=n.service||"",[c,u]=l.split(".",2);return!c||!u?void 0:this._callService(c,u,o,a)}}async _runAction(t={},e){if(t?.action==="perform-action"||t?.action==="perform_action"){let a=t.perform_action||t.performAction||{},o=t.target,l=t.data||t.service_data;return this._runPerformAction(a,e,o,l)}let i=t?.action;if(!i||i==="none")return;let s=t.entity||e,n=this._ensureTarget(t.target,s),r=t.data||t.service_data||void 0;switch(i){case"more-info":this._openMoreInfo(s||n?.entity_id);break;case"toggle":this._callService("homeassistant","toggle",void 0,n);break;case"call-service":{let a=t.service||"",[o,l]=a.split(".",2);if(!o||!l)return;this._callService(o,l,r,n);break}case"navigate":{let a=t.navigation_path||"/";try{window.history.pushState(null,"",a),this.dispatchEvent(new CustomEvent("location-changed",{detail:{replace:!1},bubbles:!0,composed:!0}))}catch{window.location.assign(a)}break}case"url":{let a=t.url_path||"/",o=t.new_tab?"_blank":"_self";window.open(a,o);break}default:break}}_onCellKeydown(t,e,i){if(t.key!=="Enter"&&t.key!==" ")return;t.preventDefault(),t.stopPropagation();let s=this._sanitizeActionForCell(e,e?.tap_action);this._hasAction(s)?this._runAction(s,i):!this._hasCellActions(e)&&!this._tapActionIsExplicitNone(e)&&e?.type==="entity"&&i&&this._openMoreInfo(i)}_onCellPointerDown(t,e,i){t.stopPropagation();try{t.preventDefault()}catch{}let s=t.currentTarget;s.__lastTapTs=s.__lastTapTs||0;let n=this._sanitizeActionForCell(e,e?.hold_action);this._hasAction(n)&&(s.__holdFired=!1,s.__holdTimer=window.setTimeout(()=>{s.__holdFired=!0,s.__tapTimer&&(clearTimeout(s.__tapTimer),s.__tapTimer=null),this._runAction(n,i)},550))}_cancelTimers(t){t&&t.__holdTimer&&(clearTimeout(t.__holdTimer),t.__holdTimer=null)}_onCellPointerCancel(t){t.stopPropagation(),this._cancelTimers(t.currentTarget)}_onCellPointerUp(t,e,i){t.stopPropagation();let s=t.currentTarget;if(s.__holdFired){this._cancelTimers(s);return}this._cancelTimers(s);let n=360,r=t.timeStamp||Date.now(),a=r-(s.__lastTapTs||0),o=this._sanitizeActionForCell(e,e?.double_tap_action),l=this._sanitizeActionForCell(e,e?.tap_action),c=this._hasAction(o),u=this._hasAction(l);if(c&&a>0&&a<n&&s.__tapTimer){clearTimeout(s.__tapTimer),s.__tapTimer=null,s.__lastTapTs=0,this._runAction(o,i);return}if(c){s.__tapTimer&&clearTimeout(s.__tapTimer),s.__lastTapTs=r,s.__tapTimer=window.setTimeout(()=>{s.__tapTimer=null,s.__lastTapTs=0,u?this._runAction(l,i):!this._hasCellActions(e)&&!this._tapActionIsExplicitNone(e)&&e?.type==="entity"&&i&&this._openMoreInfo(i)},n);return}u?this._runAction(l,i):!this._hasCellActions(e)&&!this._tapActionIsExplicitNone(e)&&e?.type==="entity"&&i&&this._openMoreInfo(i)}_renderHeaderCell(t,e=1,i=null,s=null){let n=Number(e),r=Number.isFinite(n)&&n>1?n:1,a=t?.type||"string",o=t?.value??"",l=t?.align||"left",c=i!=null,u=s!=null,h=c&&u?this._cellCssClass(i,s):"";if(a==="icon"){let w=o,x=this._evaluateDynColor(t,a,w),{style:M,textDecoration:V}=this._buildTextStyle(t,a,l,x),D=this._hasCellActions(t),S=this._buildIconStyle(t,x),k;if(x&&x.overwrite==="icon")k=this._renderIconWithOptionalText(x.icon||"",x,t,V);else if(x&&x.overwrite==="entity"){let z=this._renderDynamicEntityContent(t,x);k=z!=null&&z!==""?z:x?.mask?g`<span class="icon-mask">${x.mask}</span>`:""}else x&&x.hide?k=x?.mask?g`<span class="icon-mask">${x.mask}</span>`:"":k=w?g`<ha-icon style=${S} icon="${w}"></ha-icon>`:"";let P=["icon"];D&&P.push("clickable"),h&&P.push(h);let j=P.join(" ");return D?g`
          <th class=${j||N}
              colspan=${r}
              style=${M}
              role="button"
              tabindex="0"
              aria-label=${w||"icon"}
              @pointerdown=${L=>this._onCellPointerDown(L,t)}
              @pointerup=${L=>this._onCellPointerUp(L,t)}
              @pointercancel=${L=>this._onCellPointerCancel(L)}
              @mouseleave=${L=>this._onCellPointerCancel(L)}
              @keydown=${L=>this._onCellKeydown(L,t)}>
            ${k}
          </th>
        `:g`<th class=${j||N} colspan=${r} style=${M}>${k}</th>`}if(a==="entity"){let w=this.hass?.states?.[o],x=o?.split?.(".")?.[0],M=this._normalizeAttrEditConfig(t);if(M.enabled&&w&&(t?.attribute||M.field)){let Y=this._formatEntityCell(t,w,!1),F=this._formatEntityCell(t,w,!0),H=this._evaluateDynColor(t,a,Y),{style:W,textDecoration:Q}=this._buildTextStyle(t,a,l,H),et=this._resolveDynamicOverwriteContent(t,H,Q),R=et??this._renderAttributeEditControl(t,w,M),U=[];h&&U.push(h);let f=U.join(" ");if(R!=null)return g`
            <th class=${f||N}
                colspan=${r}
                style=${W}>
              ${R}
            </th>
          `}if(t?.show_control&&w&&(x==="input_boolean"||x==="switch"||x==="input_number"||x==="number"||x==="input_select"||x==="select"||x==="input_button"||x==="button"||x==="input_datetime"||x==="datetime"||x==="date"||x==="time"||x==="input_text"||x==="text")){let Y=this._formatEntityCell(t,w,!1),F=this._formatEntityCell(t,w,!0),H=this._evaluateDynColor(t,a,Y),{style:W,textDecoration:Q}=this._buildTextStyle(t,a,l,H),et=this._resolveDynamicOverwriteContent(t,H,Q),R=[];h&&R.push(h);let U=R.join(" ");return g`
          <th class=${U||N}
              colspan=${r}
              style=${W}>
            ${et??this._renderEntityControl(t,w,o)}
          </th>
        `}let V=w?this._formatEntityCell(t,w,!1):"n/a",D=w?this._formatEntityCell(t,w,!0):"n/a",S=this._evaluateDynColor(t,a,V),k=this._getEntityDisplayMode(t),j=(S&&S.overwrite==="entity"?this._normalizeDynamicEntityDisplay(S.overwrite_entity_display):null)||k,{style:z,textDecoration:L}=this._buildTextStyle(t,a,l,S,{skipTextDecoration:j==="icon_value"}),K=this._hasCellActions(t),J=this._tapActionIsExplicitNone(t),it=!K&&!J,ot=this._buildEntityDisplayContent(t,w,D,S,L,j),tt=w?`${o}: ${D}`:o,B=[];if(j==="icon"&&B.push("icon"),h&&B.push(h),K){let Y=[...B,"clickable"].join(" ");return g`
          <th class=${Y||N}
              colspan=${r}
              style=${z}
              title=${o}
              role="button"
              tabindex="0"
              aria-label=${tt}
              @pointerdown=${F=>this._onCellPointerDown(F,t,o)}
              @pointerup=${F=>this._onCellPointerUp(F,t,o)}
              @pointercancel=${F=>this._onCellPointerCancel(F)}
              @mouseleave=${F=>this._onCellPointerCancel(F)}
              @keydown=${F=>this._onCellKeydown(F,t)}>
            ${ot}
          </th>
        `}if(it){let Y=[...B,"clickable"].join(" ");return g`
          <th class=${Y||N}
              colspan=${r}
              style=${z}
              title=${o}
              role="button"
              tabindex="0"
              aria-label=${tt}
              @click=${()=>this._openMoreInfo(o)}
              @keydown=${F=>this._onEntityKeydown(F,o)}>
            ${ot}
          </th>
        `}let Z=B.join(" ");return g`<th class=${Z||N} colspan=${r} style=${z} title=${o}>${ot}</th>`}let p=o??"",b=this._evaluateDynColor(t,a,p),{style:$,textDecoration:y}=this._buildTextStyle(t,a,l,b),E=this._hasCellActions(t),A;if(b&&b.overwrite==="icon")A=this._renderIconWithOptionalText(b.icon||"",b,t,y);else if(b&&b.overwrite==="entity"){let w=this._renderDynamicEntityContent(t,b);A=w!=null&&w!==""?w:b?.mask||""}else b&&b.hide?A=b.mask||"":A=o??"";let _=E?["clickable"]:[];h&&_.push(h);let v=_.join(" ");if(E){let w=String(o||"text");return g`
        <th class=${v||N}
            colspan=${r}
            style=${$}
            role="button"
            tabindex="0"
            aria-label=${w}
            @pointerdown=${x=>this._onCellPointerDown(x,t)}
            @pointerup=${x=>this._onCellPointerUp(x,t)}
            @pointercancel=${x=>this._onCellPointerCancel(x)}
            @mouseleave=${x=>this._onCellPointerCancel(x)}
            @keydown=${x=>this._onCellKeydown(x,t)}>
          ${A}
        </th>
      `}return g`<th class=${v||N} colspan=${r} style=${$}>${A}</th>`}_describeBodyCell(t,e=null,i=1){let s=Number(i),n=Number.isFinite(s)&&s>1?s:1,r=t?.type||"string",a=t?.value??"",o=t?.align||"right",l=e?{...e?.bg?{bg:e.bg}:{},...e?.fg?{fg:e.fg}:{}}:null,c=_=>_?{...l||{},..._}:l,u={colSpan:n,className:"",style:"",role:null,tabIndex:null,title:null,ariaLabel:null,onContextMenu:null,onPointerDown:null,onPointerUp:null,onPointerCancel:null,onMouseLeave:null,onKeydown:null,onClick:null,content:"",align:o,type:r,hidden:!1};if(r==="icon"){let _=a,v=this._evaluateDynColor(t,r,_),w=c(v),{style:x,textDecoration:M}=this._buildTextStyle(t,r,o,w),V=this._hasCellActions(t),D=this._buildIconStyle(t,w),S;if(w&&w.overwrite==="icon")S=this._renderIconWithOptionalText(w.icon||"",w,t,M);else if(w&&w.overwrite==="entity"){let k=this._renderDynamicEntityContent(t,w);S=k!=null&&k!==""?k:w?.mask?g`<span class="icon-mask">${w.mask}</span>`:""}else w&&w.hide?S=w?.mask?g`<span class="icon-mask">${w.mask}</span>`:"":S=_?g`<ha-icon style=${D} icon="${_}"></ha-icon>`:"";if(u.className=V?"icon clickable":"icon",u.style=x,u.content=S,w&&w.hide&&!w.mask&&(!w.overwrite||w.overwrite==="hide")&&(u.hidden=!0),V){let k=_||"icon";u.role="button",u.tabIndex=0,u.ariaLabel=k,u.onContextMenu=P=>P.preventDefault(),u.onPointerDown=P=>this._onCellPointerDown(P,t),u.onPointerUp=P=>this._onCellPointerUp(P,t),u.onPointerCancel=P=>this._onCellPointerCancel(P),u.onMouseLeave=P=>this._onCellPointerCancel(P),u.onKeydown=P=>this._onCellKeydown(P,t)}return u}if(r==="entity"){let _=this.hass?.states?.[a],v=a?.split?.(".")?.[0],w=this._normalizeAttrEditConfig(t);if(w.enabled&&_&&(t?.attribute||w.field)){let B=this._formatEntityCell(t,_),Z=this._evaluateDynColor(t,r,B),Y=c(Z),{style:F,textDecoration:H}=this._buildTextStyle(t,r,o,Y);u.style=F;let W=this._resolveDynamicOverwriteContent(t,Y,H);return u.content=W??this._renderAttributeEditControl(t,_,w),Y&&Y.hide&&!Y.mask&&(!Y.overwrite||Y.overwrite==="hide")&&(u.hidden=!0),u}if(t?.show_control&&_&&!t?.attribute&&(v==="input_boolean"||v==="switch"||v==="input_number"||v==="number"||v==="input_select"||v==="select"||v==="input_button"||v==="button"||v==="input_datetime"||v==="datetime"||v==="date"||v==="time"||v==="input_text"||v==="text")){let B=this._formatEntityCell(t,_,!1),Z=this._formatEntityCell(t,_,!0),Y=this._evaluateDynColor(t,r,B),F=c(Y),{style:H,textDecoration:W}=this._buildTextStyle(t,r,o,F);u.style=H;let Q=this._resolveDynamicOverwriteContent(t,F,W);return u.content=Q??this._renderEntityControl(t,_,a),F&&F.hide&&!F.mask&&(!F.overwrite||F.overwrite==="hide")&&(u.hidden=!0),u}let x=_?this._formatEntityCell(t,_,!1):"n/a",M=_?this._formatEntityCell(t,_,!0):"n/a",V=this._evaluateDynColor(t,r,x),D=c(V),S=this._getEntityDisplayMode(t),P=(D&&D.overwrite==="entity"?this._normalizeDynamicEntityDisplay(D.overwrite_entity_display):null)||S,{style:j,textDecoration:z}=this._buildTextStyle(t,r,o,D,{skipTextDecoration:P==="icon_value"}),L=this._hasCellActions(t),K=this._tapActionIsExplicitNone(t),J=!L&&!K,it=this._buildEntityDisplayContent(t,_,M,D,z,P),ot=_?`${a}: ${M}`:a,tt=[];return P==="icon"&&tt.push("icon"),(L||J)&&tt.push("clickable"),u.className=tt.join(" "),u.style=j,u.title=a,u.ariaLabel=ot,u.content=it,D&&D.hide&&!D.mask&&(!D.overwrite||D.overwrite==="hide")&&(u.hidden=!0),(L||J)&&(u.role="button",u.tabIndex=0),L?(u.onContextMenu=B=>B.preventDefault(),u.onPointerDown=B=>this._onCellPointerDown(B,t,a),u.onPointerUp=B=>this._onCellPointerUp(B,t,a),u.onPointerCancel=B=>this._onCellPointerCancel(B),u.onMouseLeave=B=>this._onCellPointerCancel(B),u.onKeydown=B=>this._onCellKeydown(B,t)):J&&(u.onClick=()=>this._openMoreInfo(a),u.onKeydown=B=>this._onEntityKeydown(B,a)),u}let h=a??"",p=this._evaluateDynColor(t,r,h),b=c(p),{style:$,textDecoration:y}=this._buildTextStyle(t,r,o,b),E=this._hasCellActions(t),A;if(b&&b.overwrite==="icon")A=this._renderIconWithOptionalText(b.icon||"",b,t,y);else if(b&&b.overwrite==="entity"){let _=this._renderDynamicEntityContent(t,b);A=_!=null&&_!==""?_:b?.mask||""}else b&&b.hide?A=b.mask||"":A=a??"";if(u.className=E?"clickable":"",u.style=$,u.content=A,b&&b.hide&&!b.mask&&(!b.overwrite||b.overwrite==="hide")&&(u.hidden=!0),E){let _=String(a||"text");u.role="button",u.tabIndex=0,u.ariaLabel=_,u.onContextMenu=v=>v.preventDefault(),u.onPointerDown=v=>this._onCellPointerDown(v,t),u.onPointerUp=v=>this._onCellPointerUp(v,t),u.onPointerCancel=v=>this._onCellPointerCancel(v),u.onMouseLeave=v=>this._onCellPointerCancel(v),u.onKeydown=v=>this._onCellKeydown(v,t)}return u}_renderBodyCell(t,e=null,i=1,s=null,n=null){let r=this._describeBodyCell(t,e,i);if(!r)return g``;let{colSpan:a,className:o,style:l,role:c,tabIndex:u,title:h,ariaLabel:p,onContextMenu:b,onPointerDown:$,onPointerUp:y,onPointerCancel:E,onMouseLeave:A,onKeydown:_,onClick:v,content:w}=r,x=[];o&&x.push(o),s!=null&&n!==null&&n!==void 0&&x.push(this._cellCssClass(s,n));let M=x.length?x.join(" "):N;return g`
      <td
        class=${M}
        colspan=${a}
        style=${l||N}
        role=${c||N}
        title=${h||N}
        aria-label=${p||N}
        tabindex=${u??N}
        @contextmenu=${b||null}
        @pointerdown=${$||null}
        @pointerup=${y||null}
        @pointercancel=${E||null}
        @mouseleave=${A||null}
        @keydown=${_||null}
        @click=${v||null}>
        ${w}
      </td>
    `}_renderStandaloneCell(t,e=null,i=1,s="",n="",r="td",a=null){let o=this._describeBodyCell(t,e,i);if(!o)return g``;if(o.hidden)return g``;let{className:l,style:c,role:u,tabIndex:h,title:p,ariaLabel:b,onContextMenu:$,onPointerDown:y,onPointerUp:E,onPointerCancel:A,onMouseLeave:_,onKeydown:v,onClick:w,content:x,align:M}=o,V=r==="th"||r==="td"?r:"td",D=["fcc-template-cell"];if(l&&D.push(l),n&&typeof n=="string"){let L=n.split(/\s+/).filter(Boolean);L.length&&D.push(...L)}let S=typeof M=="string"?M:"left",k=[];if(c){let L=c.replace(/text-align:[^;]+;?/gi,"");L.trim()&&k.push(L.trim().replace(/;$/,""))}if(k.push("display:inline-flex"),k.push("align-items:center"),S==="right"?(k.push("justify-content:flex-end"),k.push("text-align:right")):S==="center"?(k.push("justify-content:center"),k.push("text-align:center")):(k.push("justify-content:flex-start"),k.push("text-align:left")),k.push("white-space:nowrap"),s&&typeof s=="string"){let L=s.trim().replace(/;+$/,"");L&&k.push(L)}let P=k.join(";"),j=a&&a.rowIndex!==null&&a.rowIndex!==void 0?String(a.rowIndex):N,z=a&&a.rowOrder!==null&&a.rowOrder!==void 0?String(a.rowOrder):N;return g`
      <span
        class=${D.join(" ")||N}
        style=${P||N}
        data-fcc-origin=${V}
        data-fcc-row-index=${j}
        data-fcc-row-order=${z}
        role=${u||N}
        title=${p||N}
        aria-label=${b||N}
        tabindex=${h??N}
        @contextmenu=${$||null}
        @pointerdown=${y||null}
        @pointerup=${E||null}
        @pointercancel=${A||null}
        @mouseleave=${_||null}
        @keydown=${v||null}
        @click=${w||null}>
        ${x}
      </span>
    `}_renderTemplateRow(t,e,i="",s=""){if(!Number.isInteger(e)||e<=0)return g``;let n=t[e-1];if(!n||n.hidden)return g``;let r={rowIndex:n.rowIndex,rowOrder:n.rowOrder,rowClass:n.rowClass,zebraClass:n.zebraClass},a=["fcc-template-row"];if(n.rowClass&&a.push(n.rowClass),n.zebraClass&&a.push(n.zebraClass),s&&typeof s=="string"){let p=s.split(/\s+/).filter(Boolean);p.length&&a.push(...p)}let o="";if(i&&typeof i=="string"){let p=i.trim().replace(/;+$/,"");p&&(o=p)}let l=n.rowIndex!==null&&n.rowIndex!==void 0?String(n.rowIndex):N,c=n.rowOrder!==null&&n.rowOrder!==void 0?String(n.rowOrder):N,u=n.originTag||"td",h;if(n.mergeColumns){let p=n.cells[0]??{type:"string",value:"",align:u==="th"?"left":"right"},b=n.rowIndex!=null?this._cellCssClass(n.rowIndex,0):"";h=this._renderStandaloneCell(p,n.rowDyn,n.colSpan,"",b,u,r)}else h=n.cells.map((p,b)=>{let $=n.rowIndex!=null?this._cellCssClass(n.rowIndex,b):"";return this._renderStandaloneCell(p,n.rowDyn,1,"",$,u,r)});return g`
      <span
        class=${a.join(" ")||N}
        style=${o||N}
        data-fcc-row-index=${l}
        data-fcc-row-order=${c}>
        ${h}
      </span>
    `}_renderTemplateCell(t,e,i,s="",n=""){if(!Number.isInteger(e)||e<=0)return g``;if(!Number.isInteger(i)||i<=0)return this._renderTemplateRow(t,e,s,n);let r=t[e-1];if(!r||r.hidden)return g``;let a={rowIndex:r.rowIndex,rowOrder:r.rowOrder,rowClass:r.rowClass,zebraClass:r.zebraClass},o=r.originTag||"td";if(r.mergeColumns){if(i!==1)return g``;let h=r.cells[0]??{type:"string",value:"",align:"right"},p=[n,r.rowIndex!=null?this._cellCssClass(r.rowIndex,0):""].filter(b=>!!b).join(" ").trim();return this._renderStandaloneCell(h,r.rowDyn,r.colSpan,s,p,o,a)}let l=i-1;if(l<0||l>=r.cells.length)return g``;let c=r.cells[l]??{type:"string",value:"",align:"right"},u=[n,r.rowIndex!=null?this._cellCssClass(r.rowIndex,l):""].filter(h=>!!h).join(" ").trim();return this._renderStandaloneCell(c,r.rowDyn,1,s,u,o,a)}_stringifyTemplateValue(t){return t==null?"":typeof t=="string"?t:typeof t=="number"||typeof t=="boolean"?String(t):""}_extractTemplateCellText(t){if(!t)return"";let e=t?.type||"string";if(e==="entity"){let r=this._stringifyTemplateValue(t?.value);if(!r)return"";let a=this.hass?.states?.[r],o=a?this._formatEntityCell(t,a,!1):"",l=a?this._formatEntityCell(t,a,!0):"",c=this._evaluateDynColor(t,e,o),u=this._resolveDisplayWithDynamics(l,c,t);return this._stringifyTemplateValue(u)}let i=this._stringifyTemplateValue(t?.value),s=this._evaluateDynColor(t,e,i),n=this._resolveDisplayWithDynamics(i,s,t);return this._stringifyTemplateValue(n)}_renderTemplateCellText(t,e,i){if(!Number.isInteger(e)||e<=0||!Number.isInteger(i)||i<=0)return"";let s=t[e-1];if(!s||s.hidden)return"";if(s.mergeColumns){if(i!==1)return"";let a=s.cells[0]??{type:"string",value:""};return this._extractTemplateCellText(a)}let n=i-1;if(n<0||n>=s.cells.length)return"";let r=s.cells[n]??{type:"string",value:""};return this._extractTemplateCellText(r)}_renderCustomTemplate(t,e,i=null){let s=typeof t=="string"?t:"";if(!s)return g``;this._customTemplateCache||(this._customTemplateCache=new Map);let n=this._customTemplateCache.get(s);if(!n){let a=(E,A)=>{if(!E||!A)return null;let _=A.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),v=new RegExp(`(?:^|\\s)${_}\\s*=\\s*"([^"]*)"`,"i"),w=new RegExp(`(?:^|\\s)${_}\\s*=\\s*'([^']*)'`,"i"),x=E.match(v);if(x)return x[1];let M=E.match(w);return M?M[1]:null},o=/<fcc\b([^>]*)\/>/gi,l=[],c=[],u=[],h=0,p;for(;(p=o.exec(s))!==null;){let E=s.slice(h,p.index);l.push(E),c.push(E);let A=p[1]||"",_=A.match(/row\s*=\s*["'](\d+)["']/i),v=A.match(/col\s*=\s*["'](\d+)["']/i),w=A.match(/style\s*=\s*"([^"]*)"/i)||A.match(/style\s*=\s*'([^']*)'/i),x=A.match(/class\s*=\s*"([^"]*)"/i)||A.match(/class\s*=\s*'([^']*)'/i),M=_?parseInt(_[1],10):NaN,V=v?parseInt(v[1],10):NaN,D=Number.isInteger(M)&&M>0,S=!!v,k=Number.isInteger(V)&&V>0,P=w?w[1]:"",j=x?x[1]:"",z=a(A,"mode")??a(A,"as"),L=typeof z=="string"&&z.trim().toLowerCase()==="text"?"text":"node";if(D&&(k||!S)){let K=k?V:null;u.push({rowNumber:M,colNumber:K,styleValue:P,classValue:j,outputMode:L})}else if(!D&&!S)u.push({type:"table",styleValue:P,classValue:j});else{let K=l.length-1;l[K]=l[K]+p[0],c[K]=c[K]+p[0]}h=o.lastIndex}let b=s.slice(h);if(l.push(b),c.push(b),!u.length)return this._customTemplateCache.set(s,{slots:[],templateStrings:null}),g`${re(s)}`;let $=l.slice(0),y=c.slice(0);$.raw=y,Object.freeze(y),Object.freeze($),n={slots:u,templateStrings:$},this._customTemplateCache.set(s,n)}if(!n||!n.slots?.length||!n.templateStrings)return g`${re(s)}`;let r=n.slots.map(a=>{if(a?.type==="table"){let p=i||g``,b=a.classValue?a.classValue.trim():"",$=a.styleValue?a.styleValue.trim():"";return!b&&!$?p:g`<span class=${b||N} style=${$||N}>${p}</span>`}let{rowNumber:o,colNumber:l,styleValue:c,classValue:u,outputMode:h}=a;return(h||"")==="text"?this._renderTemplateCellText(e,o,l):this._renderTemplateCell(e,o,l,c,u)});return g(n.templateStrings,...r)}_isInEditorPreview(){try{return!!this.closest?.("hui-card-preview")}catch{return!1}}_normalizeSeparator(t){let e=t?.separator||{},i={...Ht};e.color!=null&&String(e.color).trim()&&(i.color=String(e.color).trim()),e.background!=null&&String(e.background).trim()&&(i.background=String(e.background).trim());let s=String(e.style||"").toLowerCase();["solid","dashed","dotted"].includes(s)&&(i.style=s);let n=Number(e.thickness);Number.isFinite(n)&&n>=0&&(i.thickness=n),e.length!=null&&String(e.length).trim()&&(i.length=String(e.length).trim());let r=String(e.align||"").toLowerCase();["stretch","center","left","right"].includes(r)&&(i.align=r);let a=Number(e.opacity);Number.isFinite(a)&&(i.opacity=Math.min(Math.max(a,0),1));let o=Number(e.margin_top);Number.isFinite(o)&&(i.margin_top=o);let l=Number(e.margin_bottom);return Number.isFinite(l)&&(i.margin_bottom=l),i}_renderSeparatorRow(t,e){let i=this._normalizeSeparator(t),s=Math.max(0,Number(i.thickness)),n=Number.isFinite(i.opacity)?i.opacity:Ht.opacity,r=Number.isFinite(i.margin_top)?i.margin_top:Ht.margin_top,a=Number.isFinite(i.margin_bottom)?i.margin_bottom:Ht.margin_bottom,o=Math.max(1,e||1),l=(i.background||"").trim(),c=i.length||"100%",u="auto",h="auto";switch(i.align){case"stretch":c="100%",u="0",h="0";break;case"left":u="0",h="auto";break;case"right":u="auto",h="0";break;default:u="auto",h="auto";break}let p=[s>0?`border-top:${s}px ${i.style} ${i.color}`:"border-top:none",`width:${c}`,`margin-top:${r}px`,`margin-bottom:${a}px`,`margin-left:${u}`,`margin-right:${h}`,`opacity:${n}`,"height:0","box-sizing:border-box"];return g`
      <tr class="fc-separator-row">
        <td colspan=${o} style=${l?`background:${l};`:""}>
          <div class="fc-separator-line" style=${p.join(";")}></div>
        </td>
      </tr>
    `}_resolveCardPadding(){let t=this.config?.card_padding;if(t===""||t===void 0||t===null)return 16;let e=parseInt(t,10);return Number.isFinite(e)?e:16}render(){let t=this.config||{},e=this._buildRowsFromEntities(t),i=e?.rows&&e.rows.length?e.rows:Array.isArray(t.rows)?t.rows:[],s=(()=>{let R=Number.isInteger(t.column_count)&&t.column_count>0?t.column_count:null;return R||(e?.colCount?e.colCount:t.column_count??1)})(),n=this._resolveCardPadding(),r=!!t.custom_template_enabled,a=typeof t.custom_template_html=="string"?t.custom_template_html:"",o=r&&a.trim()!=="",l=this._collectCustomCss(i),c=l.length?g`<style>${l.join(`
`)}</style>`:N;if(!i.length){let R=g`<ha-card class="card" style="padding:${n}px;">${d(this.hass,"card.no_rows")}</ha-card>`;if(!o)return g`${c}${R}`;let U=g`
        <ha-card class="card fcc-template-card" style="padding:${n}px;">
          ${this._renderCustomTemplate(a,[],null)}
        </ha-card>
      `,f=this._isInEditorPreview()?g`<div class="fcc-preview-stack">${R}${U}</div>`:U;return g`${c}${f}`}let h=(e?.hasHeader?!0:!!t.header_from_first_row)?i.findIndex(R=>(R?.type||"")!=="separator"):-1,p=h>=0?i[h]:null,b=!!p,$=b?i.filter((R,U)=>U!==h):i,y=Array.isArray(t.column_widths)?t.column_widths:null,E=!!y&&y.length>0,A=["datatable"];t.zebra&&A.push("zebra");let _=this._getActiveHiddenColumns(s),v=Math.max(1,s-_.length),w=new Set(_),x=(()=>{for(let R=0;R<s;R+=1)if(!w.has(R))return R;return 0})(),M=this._normalizeHideColumns(t.hide_on_narrow,s),V=parseInt(t.narrow_breakpoint,10),D=Number.isFinite(V)&&V>0,S=!_.length&&M.length&&D?`
      @media (max-width: ${V}px) {
        ${M.map(R=>{let U=R+1;return`
          colgroup col:nth-child(${U}) { display: none; }
          thead th:nth-child(${U}) { display: none; }
          tbody tr:not(.fc-separator-row) td:nth-child(${U}) { display: none; }
        `}).join(`
`)}
      }`:"",k=E?"table-layout: fixed;":"",z=(Array.isArray(t.sort_columns)?t.sort_columns.filter(R=>Number.isInteger(R)&&R>0):[]).map(R=>R-1).filter(R=>R>=0&&R<s).filter((R,U,f)=>f.indexOf(R)===U),L=!!t.sort_desc,K=z.length>0,J=K?this._sortBodyRows($,z,L):$,it=0,ot=!!t.zebra_ignore_separators,tt=K&&!!t.hide_separators_on_sort,B=[],Z=0;if(b&&p){let R=Array.isArray(p?.cells)?p.cells:[],U=h>=0?h:null,f=U!==null?this._rowCssClass(U):"";if(p?.merge_columns){let T=R[0]??{type:"string",value:"",align:"left",style:{bold:!0}},G=T.style?.bold===void 0?{...T,style:{...T.style||{},bold:!0}}:T;B.push({row:p,rowIndex:U,rowClass:f,zebraClass:"",rowOrder:++Z,rowDyn:null,mergeColumns:!0,cells:[G],colSpan:Math.max(1,v),originTag:"th"})}else{let T=Array.from({length:s},(G,I)=>{let C=R[I]??{type:"string",value:"",align:"left",style:{bold:!0}};return C.style?.bold===void 0?{...C,style:{...C.style||{},bold:!0}}:C});B.push({row:p,rowIndex:U,rowClass:f,zebraClass:"",rowOrder:++Z,rowDyn:null,mergeColumns:!1,cells:T,colSpan:1,originTag:"th"})}}let Y=J.map(R=>{if((R?.type||"")==="separator"){t.zebra&&!ot&&(it+=1);let st=tt?{...R,separator:{...R?.separator||{},thickness:0,margin_top:0,margin_bottom:0}}:R;return this._renderSeparatorRow(st,v)}let f=this._evaluateRowRules(R);if(f?.visibility==="hidden"){let st=i.indexOf(R),ct=st>=0?st:null,je=ct!==null?this._rowCssClass(ct):"";return B.push({row:R,rowIndex:ct,rowClass:je,zebraClass:"",rowOrder:++Z,rowDyn:f,mergeColumns:!1,cells:Array.isArray(R?.cells)?R.cells:[],colSpan:1,originTag:"td",hidden:!0}),g``}t.zebra&&(it+=1);let T=t.zebra&&it%2===0?"fc-zebra-alt":"",G=i.indexOf(R),I=G>=0?G:null,C=I!==null?this._rowCssClass(I):"",q=[T,C].filter(Boolean).join(" "),O=Array.isArray(R?.cells)?R.cells:[];if(R?.merge_columns){let st=O[0]??{type:"string",value:"",align:"right"};return B.push({row:R,rowIndex:I,rowClass:C,zebraClass:T,rowOrder:++Z,rowDyn:f,mergeColumns:!0,cells:[st],colSpan:Math.max(1,v),originTag:"td"}),g`<tr class=${q||N}>${this._renderBodyCell(st,f,Math.max(1,v),I,x)}</tr>`}let ue=Array.from({length:s},(st,ct)=>O[ct]??{type:"string",value:"",align:"right"});B.push({row:R,rowIndex:I,rowClass:C,zebraClass:T,rowOrder:++Z,rowDyn:f,mergeColumns:!1,cells:ue,colSpan:1,originTag:"td"});let He=ue.map((st,ct)=>w.has(ct)?N:this._renderBodyCell(st,f,1,I,ct));return g`<tr class=${q||N}>${He}</tr>`}),F=g`
      <style>${S}</style>
      <table class=${A.join(" ")} style=${k} cellpadding="0" cellspacing="0" border="0">
        ${y?g`
          <colgroup>
            ${Array.from({length:s},(R,U)=>w.has(U)?N:g`<col style="width:${y[U]||"auto"}">`)}
          </colgroup>
        `:""}

        ${b?g`
          <thead>
            <tr class=${h>=0?this._rowCssClass(h):N}>
              ${(()=>{let R=Array.isArray(p?.cells)?p.cells:[];if(p?.merge_columns){let U=R[0]??{type:"string",value:"",align:"left",style:{bold:!0}},f=U.style?.bold===void 0?{...U,style:{...U.style||{},bold:!0}}:U;return this._renderHeaderCell(f,Math.max(1,v),h,x)}return Array.from({length:s},(U,f)=>{if(w.has(f))return N;let T=R[f]??{type:"string",value:"",align:"left",style:{bold:!0}},G=T.style?.bold===void 0?{...T,style:{...T.style||{},bold:!0}}:T;return this._renderHeaderCell(G,1,h,f)})})()}
            </tr>
          </thead>
        `:""}

        <tbody>
          ${Y}
        </tbody>
      </table>
    `,H=t.overflow_x?g`<div class="wrap"><div class="scroller" style="overflow-x:auto; overflow-y:hidden">${F}</div></div>`:g`<div class="wrap">${F}</div>`,W=g`
      <ha-card class="card" style="padding:${n}px;">
        ${H}
      </ha-card>
    `;if(!o)return g`${c}${W}`;let Q=g`
      <ha-card class="card fcc-template-card" style="padding:${n}px;">
        ${this._renderCustomTemplate(a,B,H)}
      </ha-card>
    `,et=this._isInEditorPreview()?g`<div class="fcc-preview-stack">${W}${Q}</div>`:Q;return g`${c}${et}`}static async getConfigElement(){if(!customElements.get("flex-cells-card-editor"))try{await Promise.resolve().then(()=>(oe(),ei))}catch{}return document.createElement("flex-cells-card-editor")}_onSetText(t,e){try{let s=(t?.split?.(".")[0]||"input_text")==="text"?"text":"input_text";this.hass?.callService(s,"set_value",{entity_id:t,value:e??""})}catch{}}_onSetDatetime(t,e){try{let s=this.hass?.states?.[t]?.attributes||{},n=t?.split?.(".")[0]||"input_datetime",r=s.has_date,a=s.has_time,o=r!==void 0?!!r:n==="input_datetime"||n==="datetime"||n==="date",l=a!==void 0?!!a:n==="input_datetime"||n==="datetime"||n==="time",c=String(e||"").trim(),u="",h="";if(o&&l){let E=c.replace(" ","T").match(/^([0-9]{4}-[0-9]{2}-[0-9]{2})[T ]([0-9]{2}:[0-9]{2})(?::([0-9]{2}))?$/);if(E){u=E[1];let A=E[3]??"00";h=`${E[2]}:${A}`}}else if(o){let y=c.match(/^([0-9]{4}-[0-9]{2}-[0-9]{2})$/);y&&(u=y[1])}else if(l){let y=c;/^[0-9]{2}:[0-9]{2}$/.test(y)&&(y+=":00"),/^[0-9]{2}:[0-9]{2}:[0-9]{2}$/.test(y)&&(h=y)}let p=n==="datetime"||n==="date"||n==="time"?n:"input_datetime";if(p==="input_datetime"){let y={entity_id:t};u&&(y.date=u),h&&(y.time=h),this.hass?.callService("input_datetime","set_datetime",y);return}let b={entity_id:t},$=!1;p==="datetime"?u&&h?(b.datetime=`${u} ${h}`,$=!0):u?(b.datetime=`${u} 00:00:00`,$=!0):h&&(b.datetime=`1970-01-01 ${h}`,$=!0):p==="date"?u&&(b.date=u,$=!0):p==="time"&&h&&(b.time=h,$=!0),!$&&c&&(b.value=c),this.hass?.callService(p,"set_value",b)}catch{}}_onPressButton(t){try{let i=(t?.split?.(".")[0]||"input_button")==="button"?"button":"input_button";this.hass?.callService(i,"press",{entity_id:t})}catch{}}};customElements.get("flex-cells-card")||customElements.define("flex-cells-card",le);window.customCards=window.customCards||[];window.customCards.push({type:"flex-cells-card",name:"Flex Cells Card",description:"A Lovelace card for Home Assistant that lets you add icons, text, entities, attributes, or input controls in flexible cell layouts - fully configurable from a visual editor, so no documentation is required to get started."});
/*! Bundled license information:

@lit/reactive-element/css-tag.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/reactive-element.js:
lit-html/lit-html.js:
lit-element/lit-element.js:
lit-html/directive.js:
lit-html/directives/unsafe-html.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/is-server.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/directive-helpers.js:
lit-html/directives/live.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
