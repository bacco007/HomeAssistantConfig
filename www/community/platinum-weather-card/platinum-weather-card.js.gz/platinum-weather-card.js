export{W as WeatherCard}from"./platinum-weather-card-bffb42e3.js";
