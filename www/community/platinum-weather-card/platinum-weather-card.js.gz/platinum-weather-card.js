export{P as PlatinumWeatherCard}from"./platinum-weather-card-3b029d56.js";
