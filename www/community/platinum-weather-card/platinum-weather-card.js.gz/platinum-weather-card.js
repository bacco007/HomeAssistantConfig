export{P as PlatinumWeatherCard}from"./platinum-weather-card-1a364899.js";
